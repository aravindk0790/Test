* 03d2e86 - (HEAD -> release/v1.0.0) fix:Added missing STAGE role ARN (7 seconds ago) <Gordon Harwood>
* b490f8f - (origin/release/v1.0.0) chore:Updated change log (16 hours ago) <Gordon Harwood>
* c2e11fc - feat: updated aws tags for AMI (16 hours ago) <Gordon Harwood>
* 8b1d9fc - (origin/feature/win2019, feature/win2019) chore: formated code to packer standards (13 days ago) <Gordon Harwood>
* b9e2396 - feat: updated user_data for win_rm config (13 days ago) <Gordon Harwood>
* f353554 - fix: removed NTLM line and formatted code (5 weeks ago) <Gordon Harwood>
* cf2d644 - feat: added new windows 2019 server config (5 weeks ago) <Gordon Harwood>
* 0487e3a - (origin/feature/zpamactemplate, feature/zpamactemplate) Update .gitlab-ci.yml (6 weeks ago) <Gordon Harwood>
* 3d309e3 - Update .gitlab-ci.yml (6 weeks ago) <Gordon Harwood>
* f08c53b - feat: initial pipeline config (6 weeks ago) <Gordon Harwood>
* 386d9b0 - (origin/master) feat: initial pipeline config (6 weeks ago) <Gordon Harwood>
* 5fc898d - (origin/main, origin/HEAD, main) Initial commit (7 weeks ago) <Gordon Harwood>