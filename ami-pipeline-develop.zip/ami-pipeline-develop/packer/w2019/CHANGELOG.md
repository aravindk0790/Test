* c2e11fc - (HEAD -> release/v1.0.0) feat: updated aws tags for AMI (7 seconds ago) <Gordon Harwood>
* 8b1d9fc - (origin/feature/win2019, feature/win2019) chore: formated code to packer standards (12 days ago) <Gordon Harwood>
* b9e2396 - feat: updated user_data for win_rm config (12 days ago) <Gordon Harwood>
* f353554 - fix: removed NTLM line and formatted code (5 weeks ago) <Gordon Harwood>
* cf2d644 - feat: added new windows 2019 server config (5 weeks ago) <Gordon Harwood>
* 0487e3a - (origin/feature/zpamactemplate, feature/zpamactemplate) Update .gitlab-ci.yml (6 weeks ago) <Gordon Harwood>
* 3d309e3 - Update .gitlab-ci.yml (6 weeks ago) <Gordon Harwood>
* f08c53b - feat: initial pipeline config (6 weeks ago) <Gordon Harwood>
* 386d9b0 - (origin/master) feat: initial pipeline config (6 weeks ago) <Gordon Harwood>
* 5fc898d - (origin/main, origin/HEAD, main) Initial commit (7 weeks ago) <Gordon Harwood>