* 6b9cab5 - (HEAD -> release/v1.0.1, origin/feature/etl, feature/etl) feat:added golden image build (2 hours ago) <Gordon Harwood>
* 8c29556 - feat:added config for elt connector server, using hcs image (4 hours ago) <Gordon Harwood>
* 9c86f1c - (origin/feature/zimperium, feature/zimperium) refactor:added in additional aws cli checks for permission issues (6 weeks ago) <Gordon Harwood>
* 9a3ee02 - refactor:added in additional aws cli checks for permission issues (6 weeks ago) <Gordon Harwood>
* 4a094db - refactor:added in additional aws cli checks for permission issues (6 weeks ago) <Gordon Harwood>
* c12f149 - fix:added in for loop for binaries (6 weeks ago) <Gordon Harwood>
* 21627b2 - fix:added in for look p for binaries (6 weeks ago) <Gordon Harwood>
* 6d54e01 - fix:updated bucket region to us-west-2 (6 weeks ago) <Gordon Harwood>
* cbed650 - feat:forced use of wget in install-worker.sh (6 weeks ago) <Gordon Harwood>
* 1dc9514 - fix:added placeholder vars for access key shizzle (6 weeks ago) <Gordon Harwood>
* b747dc6 - chore:updated formatting (6 weeks ago) <Gordon Harwood>
* bb80bbf - fix:updated broken script block (6 weeks ago) <Gordon Harwood>
* ced8b58 - feat:added additional vars (6 weeks ago) <Gordon Harwood>
* 1a2893b - feat:added additional var checks to install-worker.sh (6 weeks ago) <Gordon Harwood>
* 7bd0b50 - fix:added missing vars (6 weeks ago) <Gordon Harwood>
* e257d9b - fix:added missing vars (6 weeks ago) <Gordon Harwood>
* d9afaec - fix:added missing vars (6 weeks ago) <Gordon Harwood>
* e94e228 - fix:shell provisioner reboot handler (6 weeks ago) <Gordon Harwood>
* 5b648c6 - fix:shell provisioner reboot handler (6 weeks ago) <Gordon Harwood>
* d1cfef4 - fix:shell provisioner (6 weeks ago) <Gordon Harwood>
* 30101bd - fix:shell provisioner (6 weeks ago) <Gordon Harwood>
* 599b62e - fix:shell provisioner (6 weeks ago) <Gordon Harwood>
* 31f647d - fix:shell provisioner (6 weeks ago) <Gordon Harwood>
* 93dceb4 - fix:shell provisioner (6 weeks ago) <Gordon Harwood>
* 628c918 - fix:shell provisioner (6 weeks ago) <Gordon Harwood>
* 29903cd - fix:shell provisioner (6 weeks ago) <Gordon Harwood>
* a4de7da - fix:shell provisioner (6 weeks ago) <Gordon Harwood>
* 791cac1 - fix:shell provisioner (6 weeks ago) <Gordon Harwood>
* ab94f50 - fix:shell provisioner (6 weeks ago) <Gordon Harwood>
* abcd6b7 - chore:formatted code to packer standards (6 weeks ago) <Gordon Harwood>
* 6415ce2 - fix:updated post-processor manifest block (6 weeks ago) <Gordon Harwood>
* bcb8985 - feat:Added Zimperium Shell Provisioners (6 weeks ago) <Gordon Harwood>
* b054242 - feat:Added Zimperium AMI (6 weeks ago) <Gordon Harwood>
* 40bc09e - (origin/release/v1.0.0, origin/feature/win2019v2, release/v1.0.0, feature/win2019v2) chore:Updated changelog (5 months ago) <Gordon Harwood>
* 0306175 - feat:Updated userdata to install AWSCLI as part of AMI creation (5 months ago) <Gordon Harwood>
* 166a7cf - chore:Updated Changelog (5 months ago) <Gordon Harwood>
* 03d2e86 - fix:Added missing STAGE role ARN (5 months ago) <Gordon Harwood>
* b490f8f - chore:Updated change log (5 months ago) <Gordon Harwood>
* c2e11fc - feat: updated aws tags for AMI (5 months ago) <Gordon Harwood>
* 8b1d9fc - (origin/feature/win2019, feature/win2019) chore: formated code to packer standards (6 months ago) <Gordon Harwood>
* b9e2396 - feat: updated user_data for win_rm config (6 months ago) <Gordon Harwood>
* f353554 - fix: removed NTLM line and formatted code (6 months ago) <Gordon Harwood>
* cf2d644 - feat: added new windows 2019 server config (6 months ago) <Gordon Harwood>
* 0487e3a - (origin/feature/zpamactemplate, feature/zpamactemplate) Update .gitlab-ci.yml (7 months ago) <Gordon Harwood>
* 3d309e3 - Update .gitlab-ci.yml (7 months ago) <Gordon Harwood>
* f08c53b - feat: initial pipeline config (7 months ago) <Gordon Harwood>
* 386d9b0 - feat: initial pipeline config (7 months ago) <Gordon Harwood>
* 5fc898d - (origin/main, origin/HEAD, main) Initial commit (7 months ago) <Gordon Harwood>