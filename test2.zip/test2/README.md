# drue-alpha - Check in for my appointment at a job centre


## CONTENTS
1. [What is  it](#1-what-is-it)
2. [Application Architecture](#2-application-architecture)
3. [Prerequisite Software](#3-prerequisite-software)
4. [Configuration](#4-configuration)
5. [Running the Application](#5-running-the-application)
6. [Testing the Application](#6-testing-the-application)
7. [Maintaining the Application](#7-maintaining-the-application)
8. [Application Versioning and Release Management](#8-application-versioning-and-release-management)
9. [Useful Links](#9-useful-links)
10. [Troubleshooting and FAQ](#10-troubleshooting-and-faq)

## 1. WHAT IS IT
The DRUE check-in alpha system.

A digital tool to enable customers to check-in for their appointment at a job centre.


## 2. APPLICATION ARCHITECTURE
The DRUE check-in alpha system is split into two main components.

1. The Web Service
2. The API Service


### The web service
The web application is responsible for handling requests from the browser and responding with HTML pages
for display to the users.  

#### Technologies
* Javascript
* Redis for session management
* Express web framework
* Nunjucks templating engine
* Jasmine/chai/mocha for testing
* nyc for code coverage


### The API Service
The API is responsible for

* Authenticating & authorising users
* Long term storage of application data
* Exposing an interface allowing the web service to manipulate application data
* Data consistency and integrity
* Holding a journal of user access and actions

#### Technologies
* Java 
* Postgres
* Spring-boot
* Tomcat embedded
* Liquibase
* Swagger
* Spring-boot test
* Junit & Mockito


## 3. PREREQUISITE SOFTWARE
The projects depend on the following items being installed

### Software
- [Node & NPM](https://nodejs.org/en/)
- [Java](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
- [Maven](https://maven.apache.org/)
- [PostgreSQL](https://www.postgresql.org/)
- [Awscli](https://docs.aws.amazon.com/cli/latest/userguide/installing.html)
- [Redis](https://redis.io/)
- [openssl](https://www.openssl.org/)

## 4. CONFIGURATION

### The Web Service config

## Config settings

Set the following evironment variables to control the configurtation of the service.

#### PORT
The web site
default: 3000

#### PORT_HEALTH
Health check http service. Also does metrics and version info
default: 4000

#### CACHE_SALT
default: 'CHANGE-ME'

#### SESSION_SECRET
default: 'CHANGE-ME'

#### NODE_ENV
default: production
set to 'development' for dev mode.

#### CERTIFICATE_PATH
default: '.'

#### SERVER_KEY
default: 'server_key.pem'

#### SERVER_CERTIFICATE
default: 'server_cert.pem'

#### SERVER_CA_BUNDLE
default: ''

#### CLIENT_CA_BUNDLE
default: 'client_cabundle.pem'

#### DATA_API_DOMAIN
default: 'localhost'

#### DATA_API_PORT
default: 3100

#### DATA_API_PROTOCOL 
default: 'https'

#### ADMIN_USER_NAME
default: 'admin@dwp.gov.uk'

#### ADMIN_USER_PASSWORD
default: 'changethis1066'

#### CHECKIN_USER_NAME
default: 'checkin@dwp.gov.uk'

#### CHECKIN_USER_PASSWORD
default: 'notsecure1970'

### Health Information

The following urls are provided on the health port

http://localhost:4200/healthz
Health check, used to auto scaling groups and load balancers

http://localhost:4200/infoz
Useful for devops to determine which version of the service is running

http://localhost:4200/metricsz
Metrics in Prometheus format



## 5. RUNNING THE APPLICATION

How to actually run up the application, including any pre-run processes to ensure modules and libraries are updated, or any data that needs to be pre-populated in the database beforehand. This could also be different depending on which environment is involved.


## 6. TESTING THE APPLICATION

### Usage analytics

The checkin UI contains a number of screens that together 
form a finite state machine. Each screen is identified by
a single character code. 

A user journey can be described by combining the page codes
into a string. e.g. TFLCI. represents the user checking in 
and clicking on the final finish button.



| Code | Page            | Description  |
| ---- | --------------- | ----- |
| w    | What            | What are you here for today? |
| m    | Computers       |   |
| o    | Other           |   |
| T    | Time            | What time is your appointment?  |
| F    | First name      | What is the first letter of your first name?   | L    | Last name       | What is the first letter of your last name?  |
| C    | Confirmation    | Show user their full name  |
| E    | Early           | Identified OK, but user is too early  |
| A    | Late            | Identified OK, but user is too late  |
| I    | Checked In      | Identified OK at the right time  |
| X    | Not identified  | Failed to identify user   |
| D    | Don't know time | User selected Don't Know on Appt time  |
| .    | Finish          | User clicked a finish button  |
| $    | Timed out       | User did not interact for 30 seconds  |


For each completed journey a line will be logged containing the following data:

```
USER-JOURNEY; startTime; lastPage; endState; journeyDuration; journeyPages; journeyPagesDurations; numIdAttempts; earlyDuration; earlyDurationMins;
```

This is an example of a happy path journey.

```
2019-08-30T11:44:28.935+01:00 INFO USER-JOURNEY; 2019-08-30 11:44am; I; .; 18858; TFLCI.; 11640,1375,2034,1896,1913; 0; 950 15.8
```


### Api Service Tests

to run the api service tests run the following command.

`mvn clean test -Dspring.profiles.active=test`

### Web Service Tests

#### Unit Tests
`npm test`

#### Integration Tests

`npm run integration-test`

A set of integration tests that use the API Service to perform an admin user journey that creates
all the items needed to test the functionality of the system.

#### Load Tests

### SonarQube

The project uses SonarQube as a continuous code quality check.  The resulting code coverage percentage is built from both the Web and Api Service's results as an overall coverage.


### OWASP - Dependency Check


## 7. Maintaining the application

### Swagger - API Service

Swagger can only be used when the API service is running to identify endpoints and payloads for those endpoints.

To view swagger navigate to http://<host-name>/drue/swagger-ui.html. In development http://localhost:8080/drue/swagger-ui.html

### Logging

#### Api Service

#### Web Service

## 8. Application Versioning and Release Management

### Creating a Liquibase update file

## 10. Troubleshooting and FAQ


# End of ReadMe
