/* eslint-disable-next-line import/no-extraneous-dependencies */
module.exports = require('@dwp/commitlint-config-base');
