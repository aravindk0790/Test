// DRUE Checkin js

var selectedItem = null;
var transitionStarted = false;

function cancelPrevSelection() {
  if ((selectedItem) && (!transitionStarted)) {
    selectedItem.removeClass('checkinButtonSelected');
    selectedItem = null;
  }
}

function checkinTransition(e) {
  e.preventDefault();
  if (!transitionStarted) {
    cancelPrevSelection();
    transitionStarted = true;
    selectedItem = $(this);
    $('.button-checkin').addClass('checkinButtonNotSelected')
    $(this).removeClass('checkinButtonNotSelected');
    $(this).addClass('checkinButtonSelected');
    var self = this; 
    transitionStarted = true;  
    setTimeout(function() {
        window.location.href = self.href;
    }, 4000);
  
  }
}

function checkinCancel(e) {
  cancelPrevSelection();
}


function checkinLink(e) {
  e.preventDefault();
  var self = this; 
  transitionStarted = true;  
  setTimeout(function() {
      window.location.href = self.href;
  }, 250);
}

function checkinClick(e) {
  e.preventDefault();
}

function clickWelcomePage() {
  // alert('xxx');
  window.location.href = './what-are-you-here-for/';
}

function resetJourney() {
  if ( $('body.startScreen').length == 0 ) {
    window.location.href = '../timed-out/';
  }
}

$(function() {
  $('body.welcomeBody').on('click', clickWelcomePage);
  $('.button-checkin').on('pointerdown', checkinTransition);
  $('.button-checkin').on('click', checkinLink);
  $().on('pointercancel', checkinCancel);

  window.oncontextmenu = function(event) {
    event.preventDefault();
    event.stopPropagation();
    return false;
  };  

  setTimeout(resetJourney, 120000 );

});


