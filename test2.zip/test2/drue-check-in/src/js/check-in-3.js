// DRUE Checkin js

var selectedItem = null;
var transitionStarted = false;

function cancelPrevSelection() {
  if ((selectedItem) && (!transitionStarted)) {
    selectedItem.removeClass('checkinButtonSelected');
    selectedItem = null;
  }
}

function checkinTransition(e) {
  e.preventDefault();
  if (!transitionStarted) {
    cancelPrevSelection();
    transitionStarted = true;
    selectedItem = $(this);
    $('.button-checkin').addClass('checkinButtonNotSelected')
    $(this).removeClass('checkinButtonNotSelected');
    $(this).addClass('checkinButtonSelected');
    var self = this; 
    transitionStarted = true;  
    setTimeout(function() {
        window.location.href = self.href;
    }, 4000);
  
  }
}

function checkinCancel(e) {
  cancelPrevSelection();
}


function checkinLink(e) {
  e.preventDefault();
  var self = this; 
  transitionStarted = true;  
  setTimeout(function() {
      window.location.href = self.href;
  }, 250);
}

function checkinClick(e) {
  e.preventDefault();
}

$(function() {
  $('.button-checkin').on('pointerdown', checkinTransition);
  $('.button-checkin').on('click', checkinLink);
  $().on('pointercancel', checkinCancel);

  window.oncontextmenu = function(event) {
    event.preventDefault();
    event.stopPropagation();
    return false;
  };  
});


