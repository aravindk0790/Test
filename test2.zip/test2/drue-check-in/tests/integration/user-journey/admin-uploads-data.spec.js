
const moment = require('moment-timezone');
const Chance = require('chance');
const ApiFacadeService = require('../../../app/services/apifacadeservice');


const sharedServices = require('../../../shared-services/shared-services');
const TimeService = require('../../../app/services/timeservice');

adminUserName = 'admin.user@example.com';
adminPassword = 'password12345!';
standardPassword = 'Password12345!';
let chance = null;
const executionData = {};
let jobCentreName = null;

const timeService = new TimeService();
const apiFacadeService = new ApiFacadeService(sharedServices.config, timeService, sharedServices.logger);


function login(userName, password) {
  return Promise.resolve({ accessToken: 'DummyAPIAccessToken' });
  // enable this when we impliment oauth
//  return apiFacadeService.callLogin(userName, password);
}

jsonStringifyIfPossible = (error) => {
  const jsonVersion = JSON.stringify(error, null, 2);
  return jsonVersion === '{}' ? error : jsonVersion;
};


describe('Job centre appointment upload test', () => {
  beforeAll((done) => {
    chance = new Chance();
    jobCentreName = chance.city();
    login(adminUserName, adminPassword)
      .then((loginResponse) => {
        executionData.accessToken = loginResponse.accessToken;
        done();
      }).catch((error) => {
        fail(`Error setting up test data:${jsonStringifyIfPossible(error)}`);
        done();
      });
  });

  it(`Create a job centre: ${jobCentreName}`, (done) => {
    const jobCentre = {
      id: 0,
      name: jobCentreName,
    };
    apiFacadeService.post('/drue/api/jobcentre', executionData.accessToken, jobCentre)
      .then((response) => {
        done();
      }).catch((error) => {
        fail(`Creating job centre failed:${jsonStringifyIfPossible(error)}`);
        done();
      });
  });

  it(`Find the job centre: ${jobCentreName}`, (done) => {
    const jobCentre = {
      id: 0,
      name: jobCentreName,
    };
    apiFacadeService.get(`/drue/api/jobcentre/${jobCentreName}/find`, executionData.accessToken)
      .then((response) => {
        expect(response.name).toEqual(jobCentreName);
        done();
      }).catch((error) => {
        fail(`Finding a job centre failed:${jsonStringifyIfPossible(error)}`);
        done();
      });
  });

  xit(`Find an unknown job centre: ${jobCentreName}`, (done) => {
    const jobCentre = {
      id: 0,
      name: jobCentreName,
    };
    apiFacadeService.get('/drue/api/jobcentre/notfound/find', executionData.accessToken)
      .then((response) => {
        expect(response.name).toEqual(jobCentreName);
        done();
      }).catch((error) => {
        fail(`Finding a job centre failed:${jsonStringifyIfPossible(error)}`);
        done();
      });
  });
});
