const path = require('path');

const BasicMonteCarloIterations = 3000000;
const CustomerMistakesMonteCarloDaysSimulated = 10 * 365;

const SimulatedAppointmentsModelBuilder = require('../../../../app/model_builders/simapptmodelbuilder');

jasmine.DEFAULT_TIMEOUT_INTERVAL = 60000;

function makeinitialiseDuplicateCounts() {

}

function countDupliates(model, results) {

}


function testLookup(model) {
  const timeSlot = model.timeSlots[model.params.chance.integer({ min: 0, max: model.timeSlots.length - 1 })];
  const firstInitial = model.params.chance.letter({ casing: 'upper' });
  const lastInitial = model.params.chance.letter({ casing: 'upper' });

  const rv = timeSlot.appointments.find(app => app.customerFirstInitial === firstInitial
    && app.customerLastInitial === lastInitial);

  return rv;
}

function outputSimpleResults(model, resultsParam) {
  const results = resultsParam;
  results.percentage = (results.hits / results.total) * 100;
  results.percentageRounded = Math.round((results.percentage) * 10000) / 10000;
  console.log(`Random hit test: appts: ${model.params.derivedParams.numCustomersWithAppts} Hits: ${results.hits}/${results.total} => ${results.percentageRounded}% = ${results.percentage}%`);
}

function testReportStep(value) {
  if (
  // (value < 100 && value % 10 === 0) ||
    (value < 1000 && value % 100 === 0)
  || (value < 10000 && value % 1000 === 0)
  || (value < 1000000 && value % 100000 === 0)
  || (value % 1000000 === 0)) {
    return true;
  }

  return false;
}

function testMonteCarloBasic(model) {
  const total = BasicMonteCarloIterations;

  const results = {
    hits: 0,
    misses: 0,
    total: 0,
  };

  const avapp = model.appointments.length / model.timeSlots.length;

  console.log(`Starting Random hit test: slots:${model.timeSlots.length} appts:${model.appointments.length} av appt per slot:${avapp}`);


  for (let i = 0; i < total; i++) {
    if (testLookup(model)) {
      results.hits += 1;
    } else {
      results.misses += 1;
    }
    results.total += 1;

    if (testReportStep(results.total)) {
      outputSimpleResults(model, results);
    }
  }

  outputSimpleResults(model, results);

  return results.percentage;
}

function testCustomerMistake(model, attempt) {
  if (model.params.chance.floating({ min: 0, max: 1 }) > model.params.baseParams.probabilityCustomerMistake) {
    // not one of customers making a mistake
    return false;
  }

  //
  const customerOffset = attempt % model.appointments.length;
  const customer = model.appointments[customerOffset];

  let firstInitial = customer.customerFirstInitial;
  let lastInitial = customer.customerLastInitial;
  let { timeSlotOffset } = customer;

  let randomFirstName = false;
  let randomLastName = false;
  let randomTimeSlot = false;
  let reverseNames = false;

  const categoryOfError = model.params.chance.integer({ min: 1, max: 8 });

  // categoryOfError = 7;

  switch (categoryOfError) {
  case 1:
    randomFirstName = true;
    break;

  case 2:
    randomLastName = true;
    break;

  case 3:
    reverseNames = true;
    break;

  case 4:
    randomTimeSlot = true;
    break;

  case 5:
    randomTimeSlot = true;
    randomFirstName = true;
    break;

  case 6:
    randomTimeSlot = true;
    randomLastName = true;
    break;

  case 7:
    randomTimeSlot = true;
    reverseNames = true;
    break;

  default:
    randomFirstName = true;
    randomLastName = true;
    randomTimeSlot = true;
    break;
  }

  if (randomFirstName) {
    firstInitial = model.params.chance.letter({ casing: 'upper' });
  }
  if (randomLastName) {
    lastInitial = model.params.chance.letter({ casing: 'upper' });
  }
  if (reverseNames) {
    const tInitial = firstInitial;
    firstInitial = lastInitial;
    lastInitial = tInitial;
  }

  if (randomTimeSlot) {
    let diff = 0;

    while ((diff === 0) || (timeSlotOffset < 0) || (timeSlotOffset >= model.timeSlots.length)) {
      diff = model.params.chance.integer({ min: 1, max: 6 })
        + model.params.chance.integer({ min: 1, max: 6 })
        + model.params.chance.integer({ min: 1, max: 6 }) - 9;
      timeSlotOffset = customer.timeSlotOffset + diff;
    }
  }

  const rv = model.appointments.find(app => app.customerFirstInitial === firstInitial
    && app.customerLastInitial === lastInitial
    && app.timeSlotOffset === timeSlotOffset
    && app.id !== customer.id);

  /*
  if (rv) {
    console.log('x');
  }
  */


  return rv;
}

function outputCustomerMistakesResults(model, totalCustomerMistakes, totalDays, totalTests, fullStats = false) {
  const avFalsePositivesPerDay = totalCustomerMistakes / totalDays;
  const avFalsePositivesPerWeek = avFalsePositivesPerDay * 5;
  const avFalsePositivesPerMonth = avFalsePositivesPerDay * 22;
  const avFalsePositivesPerYear = avFalsePositivesPerMonth * 12;

  const avFalsePositivesPerDayRounded = Math.round((avFalsePositivesPerDay) * 10000) / 10000;
  console.log(`Average Customer Mistakes: appts: ${model.params.derivedParams.numCustomersWithAppts}, mistake chance: ${model.params.baseParams.probabilityCustomerMistake * 100}%; ${totalCustomerMistakes}/${totalDays} => day: ${avFalsePositivesPerDayRounded} = ${avFalsePositivesPerDay}; tests: ${totalTests}`);


  if (fullStats) {
    console.log(`Per day: ${avFalsePositivesPerDay}`);
    console.log(`Per week: ${avFalsePositivesPerWeek}`);
    console.log(`Per month: ${avFalsePositivesPerMonth}`);
    console.log(`Per year: ${avFalsePositivesPerYear}`);
  }

  return avFalsePositivesPerDay;
}


function testMonteCarloCustomerMistakes(modelParams, appointmentsModelBuilder) {
  const totalDays = CustomerMistakesMonteCarloDaysSimulated;
  let totalCustomerMistakes = 0;
  let totalTests = 0;

  let model = appointmentsModelBuilder.buildModel(modelParams);

  console.log(`Starting customer mistake test: slots:${model.timeSlots.length} appts:${model.appointments.length} mistake rate:${model.params.baseParams.probabilityCustomerMistake}`);

  const numCust = model.appointments.length;

  let totalAppts = 0;
  let totalDuplicatesInDay = 0;
  let totalDuplicatesInATimeSlot = 0;
  let totalModels = 0;


  for (let i = 0; i < totalDays; i++) {
    let customerMistakesOnThisDay = 0;
    for (let j = 0; j < numCust; j++) {
      if (testCustomerMistake(model, i)) {
        customerMistakesOnThisDay += 1;
        totalCustomerMistakes += 1;
      }
      totalTests += 1;
    }

    if (testReportStep(totalTests)) {
      outputCustomerMistakesResults(model, totalCustomerMistakes, i + 1, totalTests, false);
    }

    totalAppts += model.stats.totalAppts;
    totalDuplicatesInDay += model.stats.totalDuplicatesInDay;
    totalDuplicatesInATimeSlot += model.stats.totalDuplicatesInATimeSlot;
    totalModels += 1;

    modelParams.changeSeed = appointmentsModelBuilder.seedRandomNumberGenerator();
    model = appointmentsModelBuilder.buildModel(modelParams);
  }


  const avtotalDuplicatesInATimeSlot = Math.round((totalDuplicatesInATimeSlot / totalModels) * 10000) / 10000;
  const avtotalDuplicatesInADay = Math.round((totalDuplicatesInDay / totalModels) * 10000) / 10000;
  const avtotalAppts = Math.round((totalAppts / totalModels) * 10000) / 10000;

  const percDuplicatesInATimeSlot = Math.round(((avtotalDuplicatesInATimeSlot * 100) / avtotalAppts) * 10000) / 10000;

  console.log(`Total appts with duplicate initials; in a timeslot: ${totalDuplicatesInATimeSlot}, in a day: ${totalDuplicatesInDay} total: ${totalModels}`);

  console.log(`Average appts with duplicate initials; in a timeslot: ${avtotalDuplicatesInATimeSlot}, ${percDuplicatesInATimeSlot}% in a day: ${avtotalDuplicatesInADay} with ${avtotalAppts} appts`);


  return outputCustomerMistakesResults(model, totalCustomerMistakes, totalDays, totalTests, true);
}


describe('Test SimulatedAppointmentsModelBuilder', () => {
  let model = null;

  it('Test random hits => 200', (done) => {
    const appointmentsModelBuilder = new SimulatedAppointmentsModelBuilder({}, 'A');

    const modelParams = appointmentsModelBuilder.standardParams();

    expect(modelParams.percentageHaveAppts).toBeGreaterThan(0);
    expect(modelParams.numberOfAgents).toBeGreaterThan(0);
    expect(modelParams.numberOfLocations).toBeGreaterThan(0);
    expect(modelParams.numberOfVisitors).toBeGreaterThan(0);

    model = appointmentsModelBuilder.buildModel(modelParams);

    expect(model.params.derivedParams.numCustomersWithAppts).toEqual(200);
    expect(model.params.derivedParams.numVisitorsWithNoAppt).toEqual(50);
    expect(model.params.derivedParams.numVisitorsWithNoApptAndUseSystem).toEqual(5);

    const pathOutput = path.join(__dirname, '../../../test-output');

    appointmentsModelBuilder.export(model, pathOutput, 'test-appts-');

    const percentageHit = testMonteCarloBasic(model);
    expect(percentageHit).toBeLessThan(0.7);

    done();
  });

  it('Test random hits => 1000', (done) => {
    const appointmentsModelBuilder = new SimulatedAppointmentsModelBuilder({}, 'A');

    const modelParams = appointmentsModelBuilder.standardParams();

    modelParams.numberOfAgents = 40;
    modelParams.numberOfVisitors = 1250;
    modelParams.probabilityCustomerMistake = 10 / 100;

    model = appointmentsModelBuilder.buildModel(modelParams);

    const percentageHit = testMonteCarloBasic(model);
    expect(percentageHit).toBeLessThan(3);

    done();
  });


  it('Test random customer mistakes => 200', (done) => {
    const appointmentsModelBuilder = new SimulatedAppointmentsModelBuilder({}, 'A');

    const modelParams = appointmentsModelBuilder.standardParams();

    const avCustomerMistakes = testMonteCarloCustomerMistakes(modelParams, appointmentsModelBuilder);
    expect(avCustomerMistakes).toBeLessThan(1);

    done();
  });

  it('Test random customer mistakes => 1000', (done) => {
    const appointmentsModelBuilder = new SimulatedAppointmentsModelBuilder({}, 'A');

    const modelParams = appointmentsModelBuilder.standardParams();

    modelParams.numberOfAgents = 40;
    modelParams.numberOfVisitors = 1250;
    modelParams.probabilityCustomerMistake = 10 / 100;


    const avCustomerMistakes = testMonteCarloCustomerMistakes(modelParams, appointmentsModelBuilder);
    expect(avCustomerMistakes).toBeLessThan(7);

    done();
  });
});
