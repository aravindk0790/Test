const SimpleAppointmentsModelBuilder = require('../../../../app/model_builders/simpleappointmentsmodelbuilder');


describe('Test SimpleAppointmentsModelBuilder', () => {
  it('Landing page', () => {
    const appointmentsModelBuilder = new SimpleAppointmentsModelBuilder({}, 'A');

    const model = appointmentsModelBuilder.build();

    expect(model.all.length).toBeGreaterThan(90);
  });
});
