const express = require('express');
const CFonts = require('cfonts');
const standardConfig = require('./app/config');
const MetricsService = require('./app/metricsservice');
const logger = require('./app/loggerservice');
const httpserver = require('./app/httpserver');
const AppHealth = require('./app/apphealth');

class SharedServices {
  constructor() {
    this.logger = logger;
    this.httpserver = httpserver;
    this.appHealth = null;
    this.systemStartUpLogged = false;
    this.localFatalError = false;
    this.setConfig();
    this.metricsService = new MetricsService(this.config, this.logger);
  }

  createNewInstance() {
    return new SharedServices();
  }

  // ------- public methods ----------
  setConfig(localConfig = {}) {
    this.config = standardConfig(localConfig);
    if (this.metricsService) {
      this.metricsService.updateConfig(this.config);
    }
  }

  addConfig(localConfig = {}) {
    this.config = Object.assign({}, this.config, localConfig);
    if (this.metricsService) {
      this.metricsService.updateConfig(this.config);
    }
  }

  banner(text) {
    if (text && text.toString().length > 0) {
      CFonts.say(text, {
        font: 'block',
        colors: ['cyan', 'magenta'],
      });
    }
  }

  addHealthToApp(app) {
    if (this.appHealth === null) {
      throw new Error('Internal error, app health not started yet');
    }
    this.appHealth.addHealthToApp(app);
  }

  startAppHealth() {
    this.metricsService.enableResets();
    this.logSystemStartUp();
    if (this.appHealth === null) {
      this.appHealth = new AppHealth(
        this.config,
        this.logger,
        this.httpserver,
        this.metricsService,
      );
    }
  }

  stopAppHealth() {
    if (this.metricsService) {
      this.metricsService.clearResets();
    }
    if (this.appHealth) {
      this.appHealth.stop();
    }
  }

  createApp(normalizePath) {
    const app = express();

    // TODO
    app.use(this.logger.Logger.HTTPLoggingBasic);

    if (this.config.useSecureCookies) {
      app.set('trust proxy', 1); // trust first proxy
    }

    // This call will track all http requests on this app to prometheus
    if (this.appHealth) {
      this.appHealth.monitorHTTPRequests(app, { normalizePath });
    }

    return app;
  }

  startApp(app) {
    let server = null;
    this.logSystemStartUp();
    return new Promise((resolve, reject) => {
      server = this.httpserver.createServer(this.config, app, (err) => {
        if (err) {
          this.logger.error(`Error starting server: ${err.toString()}`);
          reject(err);
        } else {
          this.logger.logHTTPHeader();
          if (this.appHealth) {
            this.appHealth.on('fatalError', () => {
              server.close(() => {
                this.logger.error('HTTP service closed due to fatal error');
              });
            });
          }
          resolve(server);
        }
      });
    });
  }

  fatalError(err) {
    if (this.appHealth) {
      this.appHealth.fatalError(err);
    } else {
      this.logger.error(err);
      this.localFatalError = true;
    }
  }

  isServerIsUp() {
    if (this.appHealth) {
      return this.appHealth.isServerIsUp();
    }
    return !this.localFatalError;
  }

  setServerIsUp(value) {
    if (this.appHealth) {
      return this.appHealth.setServerIsUp(value);
    }
    this.localFatalError = !value;
    return this.localFatalError;
  }

  // ------- private methods ------------
  logSystemStartUp() {
    if (!this.systemStartUpLogged) {
      this.systemStartUpLogged = true;
      this.banner(`${this.config.serviceName}|${this.config.appVersion}`);
      this.logger.logSystemStartUp(
        this.config.serviceName,
        this.config.appVersion,
        this.config.port,
        this.config.portHealth,
      );
    }
  }
}

SharedServices.in = new SharedServices();
module.exports = SharedServices.in;
