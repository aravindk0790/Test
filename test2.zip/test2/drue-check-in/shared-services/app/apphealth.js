/*
    Create an express app to handle an AWS style heathcheck,
    prometheus monitoring, OS metrics, version info, app info.

    This app is designed to run on a different port to the web services
    app that a node service typically provdes

*/
const EventEmitter = require('events');
const express = require('express');
const helmet = require('helmet');

const promClient = require('prom-client');
const promBundle = require('express-prom-bundle');

const getMetrics = require('metrics-os');


class AppHealth extends EventEmitter {
  constructor(config, logger, httpserver, metricsService) {
    super();
    this.config = config;
    this.logger = logger;
    this.httpserver = httpserver;
    this.metricsService = metricsService;
    this.serverIsUp = true;
    this.serverInstance = null;
    this.app = null;

    if (this.config.portHealth !== this.config.port) {
      // create a unique express app just to host the health urls
      // if running on the same port as the web service, then dont bother.
      this.createApp();
    }

  }

  // ------- public methods ----------
  fatalError(message = null) {
    this.logger.error(message || 'Unspecified fatal error occured');
    this.setServerIsUp(false);
    this.metricsService.inc('fatalErrors');
    this.emit('fatalError');
  }

  setServerIsUp(value) {
    this.serverIsUp = value;
    this.metricsService.set('serverIsUp', this.serverIsUp ? 1 : 0);
  }

  isServerIsUp() {
    return this.serverIsUp;
  }

  monitorHTTPRequests(app, options = {}) {
    if (app && this.httpRequestMetricsMiddleware) {
      if ('normalizePath' in options) {
        this.suppliedNormalizePath = options.normalizePath;
      }
      app.use(this.httpRequestMetricsMiddleware);
    }
  }

  stop() {
    if (this.serverInstance) {
      this.serverInstance.close(() => {
        this.logger.info('AppHealth closed');
      });
    }
  }

  // -------- end points -------------
  robots(req, res) {
    res
      .status(200)
      .type('text/plain')
      .send('User-agent: *\nDisallow: /');
  }

  notFound(req, res) {
    res
      .status(404)
      .type('text/plain')
      .send('404: Page not Found');
  }

  serverError(error, req, res) {
    res
      .status(500)
      .type('text/plain')
      .send('500: Internal Server Error');
    this.logger.error(`Internal Error: ${error.toString()}`);
  }

  prometheusz(req, res) {
    res
      .status(200)
      .type('text/plain')
      .send(promClient.register.metrics());
  }

  metricsz(req, res) {
    res.status(200).json(getMetrics());
  }

  healthz(req, res) {
    res.status(this.serverIsUp ? 200 : 500).json({ serverIsUp: this.serverIsUp });
  }

  infoz(req, res) {
    res.status(200).json({
      application: `${this.config.serviceName || ''}`,
      environment: `${this.config.env || ''}`,
      version: `${this.config.appVersion || ''}`,
    });
  }

  // -------- builder -------------
  createApp() {
    this.app = express();
    this.addSecurity();
    this.addHealthToApp(this.app);
    this.addErrorHandling();
    this.startHealth();
  }

  addSecurity() {
    // set header security options
    this.app.use(
      helmet({
        frameguard: { action: 'deny' },
        ieNoOpen: false,
      }),
    );


    if (this.config.useSecureCookies) {
      this.app.set('trust proxy', 1); // trust first proxy
    }

    if (this.config.logHealthChecks) {
      this.app.use(this.logger.HTTPLoggingBasic);
    }

    // Disallow search index idexing
    this.app.use((req, res, next) => {
      // Setting headers stops pages being indexed even if indexed pages link to them.
      res.setHeader('X-Robots-Tag', 'noindex');
      next();
    });

    this.app.get('/robots.txt', this.robots.bind(this));
  }

  addErrorHandling() {
    // Handle 404
    this.app.use(this.notFound.bind(this));

    // Handle 500
    this.app.use(this.serverError.bind(this));
  }

  addPrometheus(router) {
    promClient.collectDefaultMetrics({ timeout: 5000 });

    this.metricsService.registerGauge(
      'serverIsUp',
      'The application health check, 1 = up, 0 = not up',
    );
    this.metricsService.set('serverIsUp', this.serverIsUp ? 1 : 0);

    this.metricsService.registerCounter(
      'fatalErrors',
      'The number of fatal errors',
    );


    router.get('/prometheusz', this.prometheusz.bind(this));
  }

  normalizePath(req) {
    // normalizePath - convert URL path names to a simpler state to reduce the number
    // of different metrics that we record.
    let path = promBundle.normalizePath(req);
    if (this.suppliedNormalizePath) {
      path = this.suppliedNormalizePath(path);
    }
    return path;
  }

  addHTTPRequestsMetrics() {
    this.httpRequestMetricsMiddleware = promBundle({
      autoregister: false,
      // blacklist: ['up'],
      includeMethod: true,
      includePath: true,
      includeStatusCode: true,
      buckets: [0.5, 10],
      normalizePath: this.normalizePath.bind(this),
    });
  }

  addHealthToApp(app) {
    const router = express.Router();

    // -------- Routes -------
    // Basic app info such as application name and version
    router.get('/infoz', this.infoz.bind(this));

    // Health check - reports uptime with 200 response when everything is fine.
    router.get('/healthz', this.healthz.bind(this));

    // Metrics - reports memory and CPU utilization amongst others
    router.get('/metricsz', this.metricsz.bind(this));

    // Prometheus reporting
    this.addPrometheus(router);

    this.addHTTPRequestsMetrics();

    app.use('/', router);
  }

  startHealth() {
    const healthConfig = Object.assign({}, this.config, {
      port: this.config.portHealth,
    });
    this.serverInstance = this.httpserver.createServer(healthConfig, this.app, (err) => {
      if (err) {
        // fatalError
        this.logger.error(`Error starting health server: ${err.toString()}`);
      }
    }, this.config.healthCheckUsesHttp === 'true');
  }
}

module.exports = AppHealth;
