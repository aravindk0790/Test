// @ts-check

const https = require('https');
const http = require('http');
const constants = require('constants');
const tls = require('tls');
const fs = require('fs-extra');

const removePemsFromDisk = false;

function loadCaBundle(filename) {
  const ca = [];
  const chain = fs
    .readFileSync(filename)
    .toString()
    .split('\n');
  let cert = [];
  chain.forEach((lineInChain) => {
    cert.push(lineInChain);
    if (lineInChain.match(/-END CERTIFICATE-/)) {
      ca.push(cert.join('\n'));
      cert = [];
    }
  });
  return ca;
}

module.exports.createCertificateForClientWithPath = function (httpsClientCaBundlePath) {
  let clientCaBundle = null;
  try {
    const useHttps = fs.existsSync(httpsClientCaBundlePath);

    if (useHttps) {
      // Load the certificates
      clientCaBundle = loadCaBundle(httpsClientCaBundlePath);
    }
  } catch (err) {
    clientCaBundle = null;
  }
  return clientCaBundle;
};

module.exports.createCertificateForClient = function (config) {
  let clientCaBundle = null;
  try {
    const httpsClientCaBundlePath = `${config.httpsCertificatePath}/${config.httpsClientCaBundle}`;

    const useHttps = fs.existsSync(httpsClientCaBundlePath);

    if (useHttps) {
      // Load the certificates
      clientCaBundle = loadCaBundle(httpsClientCaBundlePath);
    }
  } catch (err) {
    clientCaBundle = null;
  }
  return clientCaBundle;
};

module.exports.createServer = function (config, app, onCompleted, useHttpOnly = false) {
  let server = null;
  try {
    // locate the certificate files and see if all are present
    const httpsServerKeyPath = `${config.httpsCertificatePath}/${config.httpsServerKey}`;
    const httpsServerCertificatePath = `${config.httpsCertificatePath}/${config.httpsServerCertificate}`;
    const httpsServerCaBundlePath = config.httpsServerCaBundle === ''
      ? ''
      : `${config.httpsCertificatePath}/${config.httpsServerCaBundle}`;

    const useHttps = !useHttpOnly
      && fs.existsSync(httpsServerKeyPath)
      && fs.existsSync(httpsServerCertificatePath);

    if (useHttps) {
      // HTTPS
      // Load the certificates
      const serverKey = fs.readFileSync(httpsServerKeyPath);
      const serverCertificate = fs.readFileSync(httpsServerCertificatePath);
      const serverCaBundle = httpsServerCaBundlePath === '' ? undefined : loadCaBundle(httpsServerCaBundlePath);

      if (removePemsFromDisk) {
        // delete the certificate files as they are no longer needed and if left
        // represent a possible security risk, if this service is compromised
        fs.remove(httpsServerKeyPath);
        fs.remove(httpsServerCertificatePath);
        if (httpsServerCaBundlePath !== '') {
          fs.remove(httpsServerCaBundlePath);
        }
      }

      // fix a vulnerability, by not allowing the user to renegotiate the protocol
      tls.CLIENT_RENEG_LIMIT = 0;

      // turn off older protocols
      const SERVER_SECURE_OPTIONS = constants.SSL_OP_NO_SSLv3 | constants.SSL_OP_NO_TLSv1; // NOSONAR
      // n.b. Sonar complains at the use of the OR operator in all cases. In this case its use is intentional,
      // required and justified.

      const httpsCertOptions = {
        key: serverKey,
        cert: serverCertificate,
        // These were added to make the application comply with security requirements, may not be necessary
        // for all deployments, see config.js for more information.
        ciphers: config.http_listen_cipher_spec,
        secureOptions: SERVER_SECURE_OPTIONS,
        honorCipherOrder: true,
      };
      // If a longer chain is used (intermediate certificates) then this will present the chain
      // to the client upon connection allowing the client to check trust if the client does not
      // already trust the intermediate certificate.
      if (serverCaBundle !== undefined) {
        httpsCertOptions.ca = serverCaBundle;
      }
      server = https.createServer(httpsCertOptions, app).listen(config.port, onCompleted);
    } else {
      // Plain HTTP
      server = http.createServer(app).listen(config.port, onCompleted);
    }
  } catch (err) {
    onCompleted(`Error binding to port ${config.port.toString()}`);
  }
  return server;
};
