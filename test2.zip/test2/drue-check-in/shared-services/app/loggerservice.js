// @ts-check
/*
// This module provides a copy of the winston logger for use throughout the application.
// The logger is configured to output to the stdout (Console) only. This is suitable for systemd
// logging functionality as used in our AWS environments.
// The default logging level is set to INFO for production and to DEBUG for development environments.

The logger is configured to use and output the Syslog standard logging messages

There are eight different logging levels. These are described below with guidence on when to call them:

0       Emergency: system is unusable
logger.emerg('message')
-- e.g. call if the system fails to start of crashes out

1       Alert: action must be taken immediately
logger.alert('message')
-- self explanatory

2       Critical: critical conditions
logger.crit('message')
-- e.g. A security event, such as a user enters 3 incorrect passwords

3       Error: error conditions
logger.error('message')
-- e.g. A database error, back end service timeout.
-- Not for user input errors

4       Warning: warning conditions
logger.warning('message')
-- items less serious than errors

5       Notice: normal but significant condition
logger.notice('message')
-- e.g. system start up, close down, system maintenance task

6       Informational: informational messages
logger.info('message')
-- e.g. each HTTP request should be logged as info

7       Debug: debug-level messages
logger.debug('message')
-- Info used for developers. Never turned on in production

See this URL for more details on Syslog formats
https://tools.ietf.org/html/rfc5424

*/

/*
// const config = require('../../../config/config.js');
const util = require('util');
const moment = require('moment-timezone');
const winston = require('winston');
const os = require('os');

const hostname = os.hostname();

const spaceReplacers = new RegExp(/\s+/, 'gm');

const defaultProductionLogLevel = 'info';

const env = (process.env.NODE_ENV || 'production').toLowerCase();
const appIdent = process.env.APP_IDENT || 'app.dwp.gov.uk';

let CustomLogger = null;

let reqCount = 1;

function syslogLevel(strAlert) {
  //NOSONAR
  switch (strAlert) {
    case 'emerg':
      return 8;
    case 'alert':
      return 9;
    case 'crit':
      return 10;
    case 'error':
      return 11;
    case 'warning':
      return 12;
    case 'notice':
      return 13;
    case 'info':
      return 14;
    case 'debug':
      return 15;
    default:
      break;
  }
  return 14;
}

function syslogTimeStamp() {
  return moment().format('YYYY-MM-DDTHH:mm:ss.SSSZ');
}

function fullsyslogFormat(options) {
  let messText = options.message ? options.message : '';
  if (options.meta && Object.keys(options.meta).length) {
    messText += ', ' + JSON.stringify(options.meta);
  }

  return (
    '<' +
    syslogLevel(options.level) +
    '> 1 ' +
    syslogTimeStamp() +
    ' ' +
    hostname +
    ' ' +
    options.level.toUpperCase() +
    ': ' +
    messText.replace(spaceReplacers, ' ')
  );
}

function basicLogFormat(options) {
  let messText = options.message ? options.message : '';
  if (options.meta && Object.keys(options.meta).length) {
    messText += ', ' + JSON.stringify(options.meta);
  }

  return (
    syslogTimeStamp() +
    ' ' +
    //+ hostname + ' '
    options.level.toUpperCase() +
    ': ' +
    messText.replace(spaceReplacers, ' ')
  );
}

function configureLogger(isDevelopEnv, useSyslogFormat, appIdent) {
  CustomLogger = null;
  const formatter = useSyslogFormat ? fullsyslogFormat : basicLogFormat;

 // winston.setLevels(winston.config.syslog.levels);

  if (isDevelopEnv) {
    // debug - everything to the console, no syslog
    winston.configure({
      levels: winston.config.syslog.levels,
      level: 'debug',
      transports: [
        new winston.transports.Console({
          formatter: formatter,
          level: 'debug'
        })
      ]
    });
  } else {
    // production - critical and below to console, info and above to syslog
    winston.configure({
      levels: winston.config.syslog.levels,
      level: defaultProductionLogLevel,
      transports: [
        new winston.transports.Console({
          formatter: formatter,
          level: defaultProductionLogLevel
        })
      ]
    });

  }
}

function networkAddresses() {
  const nis = os.networkInterfaces();
  let ips = '[';

  for(const ni in nis) {
    nis[ni].forEach((i) => {
      if (('address' in i)&&('internal' in i)&&(!i.internal)) {
        if (ips.length > 1)
          ips += ', ';
        ips += i.address;
      }
    })
  }

  ips += ']';

  return ips;
}

winston.logSystemStartUp = function(appname, appversion, port = null, settings = {}) {
  let message =
    appname +
    '. Application starting. version:' +
    appversion +
    ', hostname:' +
    os.hostname() +
    ', IP:' +
    networkAddresses() +
    ', environment:' +
    env +
    ', system uptime:' +
    os.uptime() +
    ', total memory:' +
    byteToMb(os.totalmem()) +
    ', free memory:' +
    byteToMb(os.freemem());

  if (port != null) {
    message += ', port:' + port.toString();
  }

  for (const prop in settings) {
    if (settings.hasOwnProperty(prop)) {
      message += `, ${prop}: ${settings[prop]}`;
    }
  }

  this.notice(message);
};

function byteToMb(b) {
  return Math.round(b / (1024 * 1024)).toString() + 'mb';
}

*/

/*
Add extra methods to provide support for HTTP Extended log file format
https://www.w3.org/TR/WD-logfile.html

This enables the app to be used as a HTTPS server.
The HTTP log entries are logged at the INFO level and are mixed up with the other entries.
They can be separated up by a log parer looking for the pattern INFO: HTTP

*/

/*
winston.logHTTPHeader = function() {
  this.info('HTTP #Version: 1.0');
  this.info('HTTP #Fields: date time c-ip cs-method cs-uri sc-status time-taken req-id');
};

function incrementRequestId(res) {
  let reqId = '0';
  if ('locals' in res) {
    if ('reqId' in res.locals) {
      reqId = res.locals.reqId;
    } else {
      reqId = reqCount.toString();
      res.locals.reqId = reqId;
      reqCount++;
    }
  }

  return reqId;
}

winston.logHTTPStartOfRequest = function(req, res) {
  const reqId = incrementRequestId(res);
  winston.xdebug(
    'StartHTTP ' + req.method.toString().toUpperCase() + ' ' + req.originalUrl + ' ' + reqId
  );
  return reqId;
};

function logHTTPRequest(res, status = null) {
  if (
    typeof res === 'undefined' ||
    res == null ||
    typeof res.locals === 'undefined' ||
    typeof res.locals.requestLogged === 'undefined' ||
    res.locals.requestLogged
  ) {
    return;
  }

  const reqId = incrementRequestId(res);

  let requestDuration = 0;
  if ('requestStartTime' in res.locals) {
    requestDuration = (Date.now() - res.locals.requestStartTime) / 1000;
  }

  res.locals.requestLogged = true;

  const method = res.locals.requestMethod;
  const uri = res.locals.requestOriginalUrl;
  let _status = 200;
  if ('statusCode' in res) {
    _status = res.statusCode;
  }
  if (status != null) _status = status;

  const msg =
    'HTTP ' +
    method.toString().toUpperCase() +
    ' ' +
    uri +
    ' ' +
    _status.toString() +
    ' ' +
    requestDuration.toString() +
    ' ' +
    reqId;

  winston.info(msg);
}

function pathchedRender(view, locals = null, callback = null) {
  logHTTPRequest(this);
  if ('origFunction_render' in this.locals && 'locals' in this) {
    this.locals.origFunction_render.call(this, view, locals, callback);
  }
}

function pathchedRedirect(a, b = null) {
  if ('origFunction_redirect' in this.locals && 'locals' in this) {
    if (b == null) {
      logHTTPRequest(this, 302);
      this.locals.origFunction_redirect.call(this, a);
    } else {
      logHTTPRequest(this, a);
      this.locals.origFunction_redirect.call(this, a, b);
    }
  }
}

function pathchedSendStatus(status) {
  logHTTPRequest(this, status);
  if ('origFunction_sendStatus' in this.locals && 'locals' in this) {
    this.locals.origFunction_sendStatus.call(this, status);
  }
}

function pathchedSend(body) {
  logHTTPRequest(this);
  if ('origFunction_send' in this.locals && 'locals' in this) {
    this.locals.origFunction_send.call(this, body);
  }
}

function recordRequestStart(req, res) {
  if (!('locals' in res)) {
    res.locals = {};
  }
  res.locals.requestStartTime = Date.now();
  res.locals.requestMethod = req.method.replace(/\s/g, ' ');
  res.locals.requestOriginalUrl = req.originalUrl.replace(/\s/g, ' ');
  res.locals.requestLogged = false;
}

winston.HTTPLoggingPrefilter = function(req, res, next) {
  recordRequestStart(req, res);

  if (!('origFunction_render' in res.locals)) {
    res.locals.origFunction_render = res.render;
    res.render = pathchedRender;
  }

  if (!('origFunction_redirect' in res.locals)) {
    res.locals.origFunction_redirect = res.redirect;
    res.redirect = pathchedRedirect;
  }

  if (!('origFunction_sendStatus' in res.locals)) {
    res.locals.origFunction_sendStatus = res.sendStatus;
    res.sendStatus = pathchedSendStatus;
  }

  if (!('origFunction_send' in res.locals)) {
    res.locals.origFunction_send = res.send;
    res.send = pathchedSend;
  }

  next();
};

winston.HTTPLoggingBasic = function(req, res, next) {
  recordRequestStart(req, res);
  res.on('finish', function() {
    logHTTPRequest(res);
  });
  next();
};

//--------------- add custom callback logger, used for testing -----------------------------

winston.addLoggerCallback = function(loggingCallback) {
  winston.removeLoggerCallback();

  CustomLogger = winston.transports.CustomLogger = function(options) {
    //
    // Name this logger
    //
    this.name = 'customLogger';

    //
    // Set the level from your options
    //
    this.level = options.level || 'debug';

    //
    // Configure your storage backing as you see fit
    //
  };

  //
  // Inherit from `winston.Transport` so you can take advantage
  // of the base functionality and `.handleExceptions()`.
  //
  util.inherits(CustomLogger, winston.Transport);

  CustomLogger.prototype.log = function(level, msg, meta, callback) {
    //
    // Store this message and metadata, maybe use some custom logic
    // then callback indicating success.
    //
    loggingCallback(level + ': ' + msg);

    callback(null, true);
  };

  winston.add(winston.transports.CustomLogger, {
    level: 'debug'
  });
};

winston.removeLoggerCallback = function() {
  if (CustomLogger != null) {
    winston.remove('customLogger');
    CustomLogger = null;
    winston.transports.CustomLogger = null;
  }
};

winston.xdebug = function() {
  // function is to allow logging to be disabled in code
};

configureLogger(env === 'development', false, appIdent);

winston.fullsyslogFormat = fullsyslogFormat;
winston.basicLogFormat = basicLogFormat;
winston.configureLogger = configureLogger;

// module.exports = winston;
*/
// ========================================================================

const moment = require('moment-timezone');
const os = require('os');

let reqCount = 1;

// ========================================================================

function incrementRequestId(res) {
  let reqId = '0';
  if ('locals' in res) {
    if ('reqId' in res.locals) {
      reqId = res.locals.reqId;
    } else {
      reqId = reqCount.toString();
      res.locals.reqId = reqId;
      reqCount++;
    }
  }

  return reqId;
}

/*
function logHTTPRequest(res, status = null) {
  if (
    typeof res === 'undefined' ||
    res == null ||
    typeof res.locals === 'undefined' ||
    typeof res.locals.requestLogged === 'undefined' ||
    res.locals.requestLogged
  ) {
    return;
  }

  const reqId = incrementRequestId(res);

  let requestDuration = 0;
  if ('requestStartTime' in res.locals) {
    requestDuration = (Date.now() - res.locals.requestStartTime) / 1000;
  }

  res.locals.requestLogged = true;

  const method = res.locals.requestMethod;
  const uri = res.locals.requestOriginalUrl;
  let _status = 200;
  if ('statusCode' in res) {
    _status = res.statusCode;
  }
  if (status != null) _status = status;

  const msg =
    'HTTP ' +
    method.toString().toUpperCase() +
    ' ' +
    uri +
    ' ' +
    _status.toString() +
    ' ' +
    requestDuration.toString() +
    ' ' +
    reqId;

  winston.info(msg);
}
*/

function logHTTPRequest(res, status = null) {
}

function pathchedRender(view, locals = null, callback = null) {
  logHTTPRequest(this);
  if ('origFunction_render' in this.locals && 'locals' in this) {
    this.locals.origFunction_render.call(this, view, locals, callback);
  }
}

function pathchedRedirect(a, b = null) {
  if ('origFunction_redirect' in this.locals && 'locals' in this) {
    if (b == null) {
      logHTTPRequest(this, 302);
      this.locals.origFunction_redirect.call(this, a);
    } else {
      logHTTPRequest(this, a);
      this.locals.origFunction_redirect.call(this, a, b);
    }
  }
}

function pathchedSendStatus(status) {
  logHTTPRequest(this, status);
  if ('origFunction_sendStatus' in this.locals && 'locals' in this) {
    this.locals.origFunction_sendStatus.call(this, status);
  }
}

function pathchedSend(body) {
  logHTTPRequest(this);
  if ('origFunction_send' in this.locals && 'locals' in this) {
    this.locals.origFunction_send.call(this, body);
  }
}

function recordRequestStart(req, res) {
  if (!('locals' in res)) {
    res.locals = {};
  }
  res.locals.requestStartTime = Date.now();
  res.locals.requestMethod = req.method.replace(/\s/g, ' ');
  res.locals.requestOriginalUrl = req.originalUrl.replace(/\s/g, ' ');
  res.locals.requestLogged = false;
}

/*
winston.HTTPLoggingPrefilter = function(req, res, next) {
  recordRequestStart(req, res);

  if (!('origFunction_render' in res.locals)) {
    res.locals.origFunction_render = res.render;
    res.render = pathchedRender;
  }

  if (!('origFunction_redirect' in res.locals)) {
    res.locals.origFunction_redirect = res.redirect;
    res.redirect = pathchedRedirect;
  }

  if (!('origFunction_sendStatus' in res.locals)) {
    res.locals.origFunction_sendStatus = res.sendStatus;
    res.sendStatus = pathchedSendStatus;
  }

  if (!('origFunction_send' in res.locals)) {
    res.locals.origFunction_send = res.send;
    res.send = pathchedSend;
  }

  next();
};
*/

// ========================================================================

class Logger {
  constructor(isDevelopEnv, useSyslogFormat) {
    this.Logger = Logger;
    this.isDevelopEnv = isDevelopEnv;
    this.useSyslogFormat = useSyslogFormat;
    this.maxLevel = Logger.syslogLevel(isDevelopEnv ? 'debug' : 'info');
  }

  // ------- public methods ----------
  emerg(message) {
    this.log('emerg', message);
  }

  alert(message) {
    this.log('alert', message);
  }

  crit(message) {
    this.log('crit', message);
  }

  error(message) {
    this.log('error', message);
  }

  warning(message) {
    this.log('warning', message);
  }

  notice(message) {
    this.log('notice', message);
  }

  info(message) {
    this.log('info', message);
  }

  debug(message) {
    this.log('debug', message);
  }

  xdebug(message) { }

  // ------ private methods ------------
  log(level, message) {
    if (Logger.syslogLevel(level) <= this.maxLevel) {
      console.log(Logger.formatMessage(level, message));
    }
  }

  static formatMessage(level, message) {
    const mess = (typeof message !== 'undefined') && (message !== null) ? message : '';
    return `${Logger.syslogTimeStamp()} ${level.toUpperCase()} ${mess.replace(/\s+/gm, ' ')}`;
  }

  static syslogTimeStamp() {
    return moment().format('YYYY-MM-DDTHH:mm:ss.SSSZ');
  }

  static syslogLevel(level) {
    switch (level) {
    case 'emerg':
      return 8;
    case 'alert':
      return 9;
    case 'crit':
      return 10;
    case 'error':
      return 11;
    case 'warning':
      return 12;
    case 'notice':
      return 13;
    case 'info':
      return 14;
    case 'debug':
      return 15;
    default:
      return 14;
    }
  }

  static networkAddresses() {
    const nis = os.networkInterfaces();
    let ips = '[';

    for (const ni in nis) {
      nis[ni].forEach((i) => {
        if (('address' in i) && ('internal' in i) && (!i.internal)) {
          if (ips.length > 1) {
            ips += ', ';
          }
          ips += i.address;
        }
      });
    }

    ips += ']';

    return ips;
  }

  logSystemStartUp(appname, appversion, port = null, portHealth = null, settings = {}) {
    let message = `${appname
    }. Application starting. version:${
      appversion
    }, hostname:${
      os.hostname()
    }, IP:${
      Logger.networkAddresses()
    }, environment:${
      env
    }, system uptime:${
      os.uptime()
    }, total memory:${
      Logger.byteToMb(os.totalmem())
    }, free memory:${
      Logger.byteToMb(os.freemem())}`;

    if (port != null) {
      message += `, port:${port.toString()}`;
    }

    if (portHealth != null) {
      message += `, health port:${portHealth.toString()}`;
    }

    for (const prop in settings) {
      if (settings.hasOwnProperty(prop)) {
        message += `, ${prop}: ${settings[prop]}`;
      }
    }

    this.notice(message);
  }

  static byteToMb(b) {
    return `${Math.round(b / (1024 * 1024)).toString()}mb`;
  }

  /*
Add extra methods to provide support for HTTP Extended log file format
https://www.w3.org/TR/WD-logfile.html

This enables the app to be used as a HTTPS server.
The HTTP log entries are logged at the INFO level and are mixed up with the other entries.
They can be separated up by a log parer looking for the pattern INFO: HTTP

*/


  logHTTPHeader() {
    this.info('HTTP #Version: 1.0');
    this.info('HTTP #Fields: date time c-ip cs-method cs-uri sc-status time-taken req-id');
  }


  logHTTPStartOfRequest(req, res) {
    return incrementRequestId(res);
  }

  static HTTPLoggingBasic(req, res, next) {
    recordRequestStart(req, res);
    res.on('finish', () => {
      Logger.logHTTPRequest(res);
    });
    next();
  }

  static logHTTPRequest(res, status = null) {
    if (
      typeof res === 'undefined'
    || res == null
    || typeof res.locals === 'undefined'
    || typeof res.locals.requestLogged === 'undefined'
    || res.locals.requestLogged
    ) {
      return;
    }

    const reqId = incrementRequestId(res);

    let requestDuration = 0;
    if ('requestStartTime' in res.locals) {
      requestDuration = (Date.now() - res.locals.requestStartTime) / 1000;
    }

    res.locals.requestLogged = true;

    const method = res.locals.requestMethod;
    const uri = res.locals.requestOriginalUrl;
    let _status = 200;
    if ('statusCode' in res) {
      _status = res.statusCode;
    }
    if (status != null) {
      _status = status;
    }

    const msg = `HTTP ${
      method.toString().toUpperCase()
    } ${
      uri
    } ${
      _status.toString()
    } ${
      requestDuration.toString()
    } ${
      reqId}`;

    console.log(msg);
  }
}

const env = (process.env.NODE_ENV || 'production').toLowerCase();

module.exports = new Logger(env === 'development', false);
