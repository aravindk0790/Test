/**
 * Provides functionality to allow record statistical data used to monitor the application
 *
 * There is the option to reset all counters at the start of a period of time.
 * The default is at the start of each day, as per the standard config.
 *
 * The reason to reset a counter to allow comparison between different time periods in grafana.
 * Unlike a tools like Google Analytics grafana is not good at working with deltas.
 *
 * There is no reason to set gauges as the gauge always holds the latest value.
 *
 * Resets only occur after enableResets has been called. This is because a reset will prevent
 * the app for exiting, so we only want to do this one the app has started.
 */

const promClient = require('prom-client');
const moment = require('moment-timezone');

const ONEDAY = 24 * 60 * 60 * 1000;

class MetricsService {
  constructor(config, logger) {
    this.logger = logger;
    this.nextResetTime = null;
    this.nextResetTimerId = null;
    this.resetsAreEnabled = false;
    this.resetMetricsPeriod = 'n'; // n,s,i,h,d,w,m = none,second,minute,hour,day,week,month
    this.promMetrics = new Map();
    promClient.register.clear();
    this.updateConfig(config);
  }

  updateConfig(config) {
    if (config) {
      this.defaultLabels = {
        svc: config.serviceName || 'service',
        env: config.general_deployment_env || 'dev',
        prj: config.projectName || 'project',
        ver: config.appVersion || '0.0.1',
      };
      promClient.register.setDefaultLabels(this.defaultLabels);
      if (config.resetMetricsPeriod) {
        this.resetMetricsPeriod = config.resetMetricsPeriod;
      }
    }
    this.configureReset();
  }

  enableResets() {
    this.resetsAreEnabled = true;
    this.configureReset();
  }

  clearResets() {
    this.resetsAreEnabled = false;
    this.configureReset();
  }

  configureReset() {
    //    this.logger.debug(`configureReset`);

    if (this.nextResetTimerId) {
      clearTimeout(this.nextResetTimerId);
      this.nextResetTimerId = null;
    }
    this.calculateNextResetTime();
    this.configureNextResetTimeCheck();
  }

  calculateNextResetTime() {
    this.nextResetTime = null;

    //   this.logger.debug(`calculateNextResetTime`);

    let p = 'n';
    if (this.resetsAreEnabled && this.resetMetricsPeriod && this.resetMetricsPeriod.length > 0) {
      p = this.resetMetricsPeriod.charAt(0).toLowerCase();
    }

    switch (p) {
    case 'n':
      // no reset
      break;

    case 's':
      this.nextResetTime = moment()
        .add(1, 'seconds')
        .startOf('second');
      break;

    case 'i':
      this.nextResetTime = moment()
        .add(1, 'minutes')
        .startOf('minute');
      break;

    case 'h':
      this.nextResetTime = moment()
        .add(1, 'hours')
        .startOf('hour')
        .subtract(3, 'seconds');
      break;

    case 'd':
      this.nextResetTime = moment()
        .add(1, 'days')
        .startOf('day')
        .subtract(1, 'minutes');
      break;

    case 'w':
      this.nextResetTime = moment()
        .add(7, 'days')
        .startOf('isoWeek')
        .subtract(1, 'minutes');
      break;

    case 'm':
      this.nextResetTime = moment()
        .endOf('month')
        .add(1, 'day')
        .startOf('month')
        .subtract(1, 'minutes');
      break;

    default:
      if (this.logger) {
        this.logger.error(`Unknown metrics reset option: ${p}`);
      }
    }

    if (this.nextResetTime && this.logger) {
      const localResetTime = moment(this.nextResetTime);
      localResetTime.local();
      this.logger.info(`Metrics scheduled for reset at ${localResetTime.toISOString(true)}`);
    }
  }

  configureNextResetTimeCheck() {
    if (this.nextResetTime) {
      let timeDiff = this.nextResetTime.diff(moment()) + 400;
      if (timeDiff > ONEDAY) {
        timeDiff = ONEDAY;
      }
      if (timeDiff < 500) {
        timeDiff = 500;
      }

      //     this.logger.debug(`configureNextResetTimeCheck ${timeDiff}`);

      this.nextResetTimerId = setTimeout(() => this.onResetTimeout(), timeDiff, this);
    }
  }

  onResetTimeout() {
    //    this.logger.debug(`onResetTimeout`);

    if (this.nextResetTime) {
      const now = moment();
      if (now.isSameOrAfter(this.nextResetTime)) {
        // immediate trigger
        this.resetTriggered();
      } else {
        this.configureNextResetTimeCheck();
      }
    }
  }

  resetTriggered() {
    //  this.logger.debug(`resetTriggered`);

    this.resetAllCounters();
    if (this.logger) {
      this.logger.notice('Reset all metrics');
    }
    this.nextResetTime = null;
    this.nextResetTimerId = null;
    this.configureReset();
  }

  // ------- public methods ----------
  registerGauge(metricName, help) {
    this.registerMetric(metricName, help, 'Gauge');
  }

  registerCounter(metricName, help) {
    this.registerMetric(metricName, help, 'Counter');
  }

  set(metricName, value = 0) {
    this.getMetric(metricName).set(value);
  }

  inc(metricName, byAmount = 1) {
    this.getMetric(metricName).inc(byAmount);
  }

  dec(metricName, byAmount = 1) {
    this.inc(metricName, byAmount * -1);
  }

  reset(metricName) {
    this.getMetric(metricName).reset();
  }

  value(metricName) {
    const m = this.getMetric(metricName);
    if (m.hashMap && m.hashMap['']) {
      return m.hashMap[''].value || 0;
    }
    return 0;
  }

  /* eslint-disable-next-line no-underscore-dangle */
  resetAllCounters() {
    for (const metric in promClient.register._metrics) {
      if (promClient.register._metrics[metric] instanceof promClient.Gauge == false) {
        promClient.register._metrics[metric].reset();
      }
    }
  }

  // ------- private methods ------------
  registerMetric(metricName, help, type = 'Gauge') {
    let metric = null;

    if (typeof this.promMetrics.get(metricName) === 'undefined') {
      const def = {
        name: metricName,
        help,
      };

      switch (type) {
      case 'Gauge':
        metric = new promClient.Gauge(def);
        break;
      case 'Counter':
        metric = new promClient.Counter(def);
        break;
      default:
        metric = null;
        break;
      }

      if (metric) {
        this.promMetrics.set(metricName, metric);
      }
    }
  }

  getMetric(metricName) {
    const m = this.promMetrics.get(metricName);
    if (typeof m === 'undefined') {
      throw new Error(`Unregistered metric: '${metricName}'`);
    }
    return m;
  }
}

module.exports = MetricsService;
