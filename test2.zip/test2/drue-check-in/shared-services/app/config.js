const path = require('path');
const { name, version } = require('../../package.json');

module.exports = function(localConfig = {}) {
  // These are the standard configuration values for a basic service
  // Any properties defined in the localConfig will over-ride ones in
  // the standard configuration
  return Object.assign(
    {},
    {
      appVersion: version,
      serviceName: name,
      projectName: name,
      supportEmail: 'xxxxx@dwp.gov.uk',
      administrationContact: 'The admin team',

      port: process.env.PORT || 3000,
      portHealth: process.env.PORT_HEALTH || process.env.PORT || 4000,

      authorizationSecret: process.env.AUTHORIZATION_SECRET || 'CHANGE-ME',
      gaKey: process.env.GOOGLE_ANALYTICS_KEY /*  || 'UA-11111111-1' */,
      gaKey2: process.env.GOOGLE_ANALYTICS_KEY2 /* || 'UA-22222222-2' */,
      gaSiteSpeedSampleRate: 50,

      salt: process.env.CACHE_SALT || 'CHANGE-ME',
      sessionSecret: process.env.SESSION_SECRET || 'CHANGE-ME',
      //        healthCheckSecret: process.env.HEALTH_CHECK_SECRET || 'CHANGE-ME',
      sessionPath: process.env.SESSION_PATH || path.join(process.env.HOME, 'tmp_sessions'),

      // resets the metrics at the start of the next persiod; minute,hour,day,week,none
      resetMetricsPeriod: (process.env.RESET_METRIC_PERIOD || 'day').toLowerCase(),

      env: (process.env.NODE_ENV || 'production').toLowerCase(),
      isDev: process.env.NODE_ENV === 'development',

      // indicates the specific deployment environment we are using. e.g. staging-blue
      deployment_env: (process.env.ENV || 'dev').toLowerCase(),

      // indicates the general deployment environment we are using. e.g. staging
      general_deployment_env: (process.env.ENV3 || 'dev').toLowerCase(),

      logHealthChecks: process.env.LOG_HEALTH_CHECKS || process.env.NODE_ENV === 'development',

      httpsCertificatePath: process.env.CERTIFICATE_PATH || '.',
      httpsServerKey: process.env.SERVER_KEY || 'server_key.pem',
      httpsServerCertificate: process.env.SERVER_CERTIFICATE || 'server_cert.pem',
      httpsServerCaBundle: process.env.SERVER_CA_BUNDLE || '',
      httpsClientCaBundle: process.env.CLIENT_CA_BUNDLE || 'client_cabundle.pem',
      httpListenCipherSpec: 'ECDHE-RSA-AES128-GCM-SHA256:!RC4',

      healthCheckUsesHttp: process.env.HEALTH_USES_HTTP || 'true',

      applicationRootPath: '',
      homeDirectory: process.env.HOME,

      sessionStorage: process.env.SESSION_STORAGE || 'redis',
      sessionTTL: 120 * 60,
      redisServerMode: process.env.REDIS_SERVER_MODE || 'cluster',
      redisSessionServerAddress: process.env.REDIS_SERVER_ADDR || '127.0.0.1',
      redisSessionServerPort: process.env.REDIS_SERVER_PORT || '6379',
      redisSessionPrefix: process.env.REDIS_SESSION_PREFIX || 'appnodesess:',
      useSecureCookies:
        process.env.USE_SECURE_COOKIES === 'true' || process.env.NODE_ENV !== 'development',

      useHttpCompression: process.env.USE_HTTP_COMPRESSION || 'false',

      useLocalStackAWS: process.env.USE_LOCAL_STACK || 'false',
      localStackAddress: process.env.LOCAL_STACK_ADDR || '127.0.0.1',

      // CONNECT proxy URL to use (e.g. TinyProxy)
      awsEndpointProxyUrl: process.env.AWS_ENDPOINT_PROXY,

      // Lowercase comma-sepped list (no spaces)
      // If set, will proxy only these endpoints
      // If not, will proxy all endpoints
      awsProxyEndpoints: process.env.AWS_PROXY_ENDPOINTS
        ? process.env.AWS_PROXY_ENDPOINTS.split(',')
        : undefined,

      checkForInfrastructure: process.env.CHECK_FOR_INFRASTRUCTURE || 'true',
      infrastructureIndicator:
        process.env.INFRASTRUCTURE_INDICATOR || '/project/infrastructure/isup',
      infrastructureTimeout: process.env.INFRASTRUCTURE_TIMEOUT || 5 * 60 * 1000, // 5 minutes - time to wait for the queues to be created

      dataApiDomain: process.env.DATA_API_DOMAIN || 'localhost',
      dataApiPort: process.env.DATA_API_PORT || 3100,
      dataApiProtocol: process.env.DATA_API_PROTOCOL || 'https',

      validateApiCertificate: process.env.VALIDATE_DATA_API == 'true' || false,

      adminUserName: process.env.ADMIN_USER_NAME || 'admin@dwp.gov.uk',
      adminUserPassword: process.env.ADMIN_USER_PASSWORD || 'changethis1066',

      checkinUserName: process.env.CHECKIN_USER_NAME || 'checkin@dwp.gov.uk',
      checkinUserPassword: process.env.CHECKIN_USER_PASSWORD || 'notsecure1970',
    },
    localConfig,
  );
};
