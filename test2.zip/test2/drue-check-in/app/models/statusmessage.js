// @ts-check

class StatusMessage {
  constructor() {
    this.statusCode = 200;
    this.message = '';
    this.safeMessage = '';
    this.fieldErrors = [];
    this.subMessages = [];
    this.isError = false;
    this.isSuccess = true;
    this.hasOrigMessage = false;
    this.origStatusCode = 0;
    this.body = null;
    this.internalErrorCode = '';
    this.internalErrorDescription = '';
    this.internalErrorStatus = '';
  }

  setErrorMessage(value, code = 501) {
    this.message = value;
    this.statusCode = code;
    this.isError = true;
    this.hasOrigMessage = false;
    this.isSuccess = false;
  }

  setMessage(value) {
    this.message = value;
  }

  setMessageIfBlank(value) {
    if (this.message.length === 0) {
      this.message = value;
    }
  }

  setSuccessMessage(value) {
    this.message = value;
    this.statusCode = 200;
    this.isError = false;
    this.isSuccess = true;
  }

  setSuccessMessageSafe(value) {
    this.safeMessage = value;
    this.statusCode = 200;
    this.isError = false;
    this.isSuccess = true;
  }

  addFieldValidationError(fieldName, errorDescription, safeErrorDescription = '') {
    this.statusCode = 422;
    this.isError = true;
    this.isSuccess = false;

    if (safeErrorDescription) {
      this.fieldErrors.push({
        name: fieldName,
        safeMessage: safeErrorDescription,
      });
    } else {
      this.fieldErrors.push({
        name: fieldName,
        message: errorDescription,
      });
    }

    if (typeof this.message === 'undefined' || this.message === '') {
      this.message = 'There’s a problem';
    }
  }

  addSubMessage(value = '') {
    if (value !== '') {
      this.subMessages.push({
        name: `submessage${this.subMessages +1}`,
        message: value,
      });
    }
  }

  hasSubMessages() {
    return this.subMessages.length > 0;
  }

  setBody(value) {
    this.body = value;
  }
}

StatusMessage.createError = function(message, code = 500) {
  const mess = new StatusMessage();
  mess.setErrorMessage(message, code);
  return mess;
};

StatusMessage.createBlank = function() {
  return new StatusMessage();
};

StatusMessage.decodeAPIErrorResponse = function(body, statusCode) {
  const mess = new StatusMessage();

  mess.setErrorMessage('', statusCode);

  if (typeof body === 'object' && body !== null) {
    mess.setBody(body);
    if (typeof body.error === 'string') {
      mess.internalErrorCode = body.error;
    }
    if (typeof body.error_description === 'string') {
      mess.internalErrorDescription = body.error_description;
    }
    if (typeof body.errorStatus === 'string') {
      mess.internalErrorStatus = body.errorStatus;
    }
  }

  return mess;
};

module.exports = StatusMessage;
