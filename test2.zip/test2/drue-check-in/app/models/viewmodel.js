const moment = require('moment-timezone');

class ViewModel {
  constructor(req, res, model, now, analytics = '') {
    if ((req.session)
          && (req.session.hasOwnProperty('statusMessages'))
          && (Array.isArray(req.session.statusMessages))) {
      this.statusMessages = req.session.statusMessages;
      req.session.statusMessages = [];
    } else {
      this.statusMessages = [];
    }
    this.model = model;
    this.countMessages();

    if (model) {
      if ('bodyClasses' in model) {
        this.bodyClasses = model.bodyClasses;
      }
      if ('mainClasses' in model) {
        this.mainClasses = model.mainClasses;
      }
      if ('htmlClasses' in model) {
        this.htmlClasses = model.htmlClasses;
      }
    }

    this.breadcrumbs = [];
    if (('breadcrumbs' in req) && (Array.isArray(req.breadcrumbs))) {
      this.breadcrumbs = req.breadcrumbs;
      req.breadcrumbs = null;
    }

    this.now = now;
    this.analytics = analytics;
    this.isWebView = true;
    this.isPDFView = false;

    // this.currentUsersAccessLevel = authenticationService.users_role_access_level(req);
  }

  countMessages() {
    this.numSuccessMessages = 0;
    this.numErrorMessages = 0;

    this.fieldErrors = {};

    for (let messageIndex = 0; messageIndex < this.statusMessages.length; messageIndex++) {
      if (('isError' in this.statusMessages[messageIndex]) && (this.statusMessages[messageIndex].isError)) {
        this.numErrorMessages++;
        this._mapFieldError(messageIndex);
      } else {
        this.numSuccessMessages++;
      }
    }
  }

  _mapFieldError(messageIndex) {
    for (let fieldErrorIndex = 0; fieldErrorIndex < this.statusMessages[messageIndex].fieldErrors.length; fieldErrorIndex++) {
      try {
        this.fieldErrors[this.statusMessages[messageIndex].fieldErrors[fieldErrorIndex].name] = this.statusMessages[messageIndex].fieldErrors[fieldErrorIndex].message;
      } catch (ex) {
      }
    }
  }

  formatDate(value) {
    return ViewModel.formatADate(value);
  }

  dateDifference(from, to) {
    return ViewModel.dateDifference(from, to);
  }

  static formatADate(value) {
    let fd = '';
    try {
      fd = moment(value).format('D MMMM YYYY');
    } catch (ex) {
      fd = '';
    }
    return fd;
  }

  static dateDifference(from, to) {
    let dur = 0;
    try {
      const ms = moment(from).diff(moment(to));
      const d = moment.duration(ms);
      dur = d.as('days');
    } catch (ex) {
      dur = 0;
    }
    return Math.round(dur);
  }
}

module.exports = ViewModel;
