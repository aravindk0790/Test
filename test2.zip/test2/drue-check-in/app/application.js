const { name: serviceName, version: appVersion } = require('../package.json');
const UiServer = require('./check-in-server');
const sharedServices = require('../shared-services/shared-services');
const TimeService = require('./services/timeservice');
const ResponseService = require('./services/responseservice');
const ApiFacadeService = require('./services/apifacadeservice');

class Application {
  constructor(localOptions = {}) {
    const options = Object.assign(
      {},
      {
        serviceName,
        appVersion,
        projectName: 'Check in',
        uploadPath: process.env.TMP_UPLOAD_PATH || `${process.env.HOME}/uploadfiles/`,
      },
      localOptions,
    );

    sharedServices.setConfig(options);

    this.uiServer = null;
    this.httpServer = null;

    this.timeService = new TimeService();
    this.responseService = new ResponseService(this.timeService, sharedServices.logger);
    this.apiFacadeService = new ApiFacadeService(
      sharedServices.config,
      this.timeService,
      sharedServices.logger,
    );
  }

  startUp() {
    sharedServices.startAppHealth();

    this.uiServer = new UiServer(sharedServices, this.apiFacadeService, this.responseService);
    return this.uiServer.startUp()
    .then(() => {
      const app = this.uiServer.makeApp();
      if (sharedServices.config.portHealth === sharedServices.config.port) {
        sharedServices.addHealthToApp(app);
      }
      this.uiServer.addRoutesToApp(app) ;

      return Promise.resolve(app);
    })
      .then((app) => sharedServices.startApp(app))
      .then(server => {
        this.httpServer = server;
        return Promise.resolve();
      })
      .catch(err => {
        sharedServices.logger.notice('App exiting');
        return Promise.reject(err);
      });
  }
}

module.exports = Application;
