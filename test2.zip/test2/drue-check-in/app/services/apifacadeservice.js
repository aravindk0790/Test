// @ts-check
const request = require('request');
const moment = require('moment-timezone');

// const httpserver = require('../utils/httpserver');
const _ = require('lodash');
const StatusMessage = require('../models/statusmessage');

class ApiFacadeService {
  constructor(config, timeService, logger = null) {
    this.timeService = timeService;
    this.logger = logger;

    this.config = config;

    this.standardOptions = {
      json: true,
      timeout: config.apiTimeOut,
    };

    this.client = request.defaults(this.standardOptions);

    this.customApiClient = null;
    this.customApiCallLogin = null;

    this.clientCertificate = null; // httpserver.createCertificateForClient(config);
    this.api_uses_https = this.clientCertificate !== null;
    this.base_url = this.makeBaseUrl();

    this.fixedResponses = [];

    this.postProcesses = [];

    this._now = function () {
      return moment();
    };

    this._today = function () {
      const m = this._now();
      return m.format('YYYY-MM-DD');
    };

    this._todayPlusDays = function (days) {
      const m = this._now().add(days, 'days');
      return m.format('YYYY-MM-DD');
    };

    this.debugMessages = true;
  }

  makeBaseUrl() {
    return `${this.config.dataApiProtocol}://${this.config.dataApiDomain}:${this.config.dataApiPort}`;
  }

  makeFullUrl(value) {
    return this.base_url + value;
  }

  // ------------------ Direct calls --------------------------------------------------------
  buildRequest(accessToken, params = {}, fields = {}) {
    const req = {
      method: 'GET',
      url: '/',
      originalUrl: '/',
      session: this._buildSession(accessToken),
      params,
      body: fields,
      query: {},
    };
    const res = {};
    return [req, res];
  }

  _buildSession(accessToken) {
    return {
      cookie: {
        originalMaxAge: null,
        expires: null,
        httpOnly: true,
        path: '/',
      },
      accessToken,
      statusMessages: [],
    };
  }

  // ------------------ Caching --------------------------------------------------------
  addFixedResponse(value) {
    if (typeof value === 'object') {
      const o = Object.assign({}, value);
      if ('uri' in o) {
        o.uri = this.makeFullUrl(o.uri);
        o.uriRE = new RegExp(o.uri, 'i');
      }

      this.fixedResponses.push(o);
    }
  }

  lookupCachedResponse(params) {
    const resp = this.fixedResponses.find((r) => {
      if (('method' in r) && ('uri' in r) && (r.method === params.method)) {
        if (r.uri === params.uri) {
          if (this.logger) {
            this.logger.debug(`Found cached response for: ${params.uri}`);
          }
          return _.isEqual(r.body, params.body);
        }

        if (r.uriRE.test(params.uri)) {
          if (this.logger) {
            this.logger.debug(`Found cached response for matched: ${params.uri}`);
          }
          return _.isEqual(r.body, params.body);
        }
      }
      return false;
    });

    if ((typeof resp !== 'undefined') && ('responseStatusCode' in resp)) {
      let respObj = {};
      if ('responseContent' in resp) {
        respObj = resp.responseContent;
      }

      if (resp.responseStatusCode === 200) {
        return Promise.resolve(respObj);
      }

      respObj = new StatusMessage();

      respObj.setErrorMessage('error', resp.responseStatusCode);

      return Promise.reject(respObj);
    }

    return null;
  }

  // ------------------ Post processing --------------------------------------------------------
  postProcessTheResponse(params, response) {
    this.postProcesses.forEach((pp) => {
      if (pp.match(params)) {
        pp.process(params, response);
      }
    });
  }

  // ------------------ Calls --------------------------------------------------------
  callLogin(email, password) {
    if (typeof this.customApiCallLogin === 'function') {
      return this.customApiCallLogin(email, password);
    }

    const params = {
      url: this.makeFullUrl('/oauth/token'),
      method: 'POST',
      auth: {
        user: this.config.apiClientId,
        pass: this.config.authorizationSecret,
      },
      form: {
        grant_type: 'password',
        username: email,
        password,
      },
      debugMessages: this.debugMessages,
      expectJSON: true,
    };
    if (this.clientCertificate) {
      params.ca = this.clientCertificate;
    }

    const apifacade = this;

    return new Promise(((resolve, reject) => {
      clientCallback(apifacade, params, resolve, reject);
    }));
  }


  call(method,
    url,
    accessToken = null,
    payload = null,
    expectJSON = true) {
    const urlTocall = this.makeFullUrl(url);

    const params = {
      uri: urlTocall,
      method,
      debugMessages: this.debugMessages,
      expectJSON,
    };
    if (accessToken) {
      params.auth = { bearer: accessToken };
    }
    if (payload) {
      params.body = payload;
    }
    if (this.clientCertificate) {
      params.ca = this.clientCertificate;
    }


    params.rejectUnauthorized = this.config.validateApiCertificate;


    const p = this.lookupCachedResponse(params);
    if (p != null) {
      return p;
    }

    const apifacade = this;

    if (typeof this.customApiClient === 'function') {
      const customApiClient = function (apifacade, params, resolve, reject) {
        this.customApiClient(apifacade, params, resolve, reject);
      }.bind(this);
      return new Promise(((resolve, reject) => {
        customApiClient(apifacade, params, resolve, reject);
      }));
    }

    return new Promise(((resolve, reject) => {
      clientCallback(apifacade, params, resolve, reject);
    }));
  }

  get(url,
    accessToken = null,
    payload = null,
    expectJSON = true) {
    return this.call('GET', url, accessToken, payload, expectJSON);
  }

  post(url,
    accessToken = null,
    payload = null) {
    return this.call('POST', url, accessToken, payload);
  }

  /* delete_call(url,
         accessToken = null,
         payload = null) {
        return this.call('DELETE',url,accessToken,payload);
         } */
  delete(url,
    accessToken = null,
    payload = null) {
    return this.call('DELETE', url, accessToken, payload);
  }

  put(url,
    accessToken = null,
    payload = null) {
    return this.call('PUT', url, accessToken, payload);
  }

  patch(url,
    accessToken = null,
    payload = null) {
    return this.call('PATCH', url, accessToken, payload);
  }

  // ---------------------- date time -------------------------------------------------
  getToday() {
    return this._today();
  }

  getTodayPlusDays(days) {
    return this._todayPlusDays(days);
  }

  getTodayMinusDays(days) {
    return this._todayPlusDays(-1 * days);
  }

  getNow() {
    return this._now();
  }

  setNow(fn) {
    this._now = fn;
  }
}

function _parseSuccessResponse(responseContainer, params) {
  responseContainer.statusCode = 200;
  if (!params.expectJSON) {
    responseContainer.response = { body: responseContainer.body };
  } else if (typeof responseContainer.body === 'object') {
    responseContainer.response = responseContainer.body;
  } else {
    responseContainer.response = {};
  }
}

function _parseErrorResponse(responseContainer) {
  if (typeof responseContainer.body === 'object') {
    // Assume it is an error. save the messages from the api for later analysis
    responseContainer.response = StatusMessage.decodeAPIErrorResponse(responseContainer.body, responseContainer.statusCode);
  } else {
    responseContainer.statusCode = 500;
  }
}

function _parseResponseIntoContainer(responseContainer, err, res, params) {
  if (err) {
    if ('message' in err) {
      responseContainer.errorMessage = err.message;
    }
  } else {
    responseContainer.statusCode = res.statusCode;
    responseContainer.origStatusCode = responseContainer.statusCode;
    if ((typeof responseContainer.body === 'string') && (params.expectJSON)) {
      responseContainer.body = JSON.parse(responseContainer.body);
    }
    if ((responseContainer.statusCode >= 200) && (responseContainer.statusCode <= 299)) {
      _parseSuccessResponse(responseContainer, params);
    } else {
      _parseErrorResponse(responseContainer);
    }
  }
}

function _logResponseMessages(apifacade, responseContainer, params, stopwatch1, err) {
  let outputMessage = false;

  if (!apifacade.logger) {
    return;
  }


  let url = '';
  if ('uri' in params) {
    url = params.uri;
  }
  if ('url' in params) {
    url = params.url;
  }
  let debugMessage = `API: ${apifacade.timeService.timeStopWatch(stopwatch1).toString().padStart(6, '0')}ms ${params.method} ${url} ${responseContainer.statusCode}`;
  if ((responseContainer.statusCode < 200) || (responseContainer.statusCode >= 300)) {
    outputMessage = true;
    if (responseContainer.errorMessage !== '') {
      debugMessage += ` {${responseContainer.errorMessage}}`;
    }
    if (typeof body === 'object') {
      debugMessage += ` (${JSON.stringify(responseContainer.body)})`;
    }
    if (typeof body === 'string') {
      debugMessage += ` [${responseContainer.body.toString()}]`;
    }
  }

  if (err) {
    apifacade.logger.error(debugMessage);
  } else if (outputMessage) {
    apifacade.logger.info(debugMessage);
  } else if (params.debugMessages) {
    apifacade.logger.debug(debugMessage);
  }
}

// -------------- Internal ------------------------------------------
function clientCallback(apifacade, params, resolve, reject) {
  const stopwatch1 = apifacade.timeService.startStopWatch();

  params._apifacade = apifacade;

  apifacade.client(params, (err, res, body) => {
    const responseContainer = {
      statusCode: 500,
      origStatusCode: 0,
      response: new StatusMessage(),
      errorMessage: '',
      body,
    };

    try {
      _parseResponseIntoContainer(responseContainer, err, res, params);
    } catch (ex) {
      responseContainer.statusCode = 500;
    }

    _logResponseMessages(apifacade, responseContainer, params, stopwatch1, err);

    if (responseContainer.statusCode === 200) {
      params._apifacade.postProcessTheResponse(params, responseContainer.response);
      resolve(responseContainer.response);
    } else {
      responseContainer.response.statusCode = responseContainer.statusCode;
      responseContainer.response.isError = true;
      responseContainer.response.isSuccess = false;
      if (responseContainer.origStatusCode > 0) {
        responseContainer.response.origStatusCode = responseContainer.origStatusCode;
      }
      reject(responseContainer.response);
    }
  });
}

module.exports = ApiFacadeService;
