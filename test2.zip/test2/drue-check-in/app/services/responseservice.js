const HtmlEntities = require('html-entities');
const StatusMessage = require('../models/statusmessage');
const ViewModel = require('../models/viewmodel');
// const authenticationService = require('./authenticationservice');

// const nunjucks = require('nunjucks');
// const customFilters = require('../filters.js')();


class ResponseService {
  constructor(timeService, logger = null) {
    this.timeService = timeService;
    this.logger = logger;

    this.renderDoneCallback = null;
    this.renderErrorCallback = null;
    this.localRenderEngine = null;

    this.entities = new HtmlEntities.AllHtmlEntities();
  }

  getUsersHomePath(req, action) { // NOSONAR
    if ('homeUrl' in action) {
      return action.homeUrl;
    }
    return '/';
  }

  /*
    setupLocalRenderEngine() {
        this.localRenderEngine = nunjucks.configure('app/views', {
            autoescape: true,
            watch: false,
            noCache: false
        });

        if (customFilters) {
            Object.keys(customFilters).forEach(name => {
                this.localRenderEngine.addFilter(name, customFilters[name]);
            });
        }
    }

    setRenderToCallback(renderDone, renderError = null) {
        this.renderDoneCallback = renderDone;
        this.renderErrorCallback = renderError;
        if (this.renderDoneCallback !== null) {
            this.setupLocalRenderEngine();
        } else {
            this.localRenderEngine = null;
        }
    }

    clearRenderToCallback() {
        this.setRenderToCallback(null);
    }
    */
  // ---------- Field extraction and validation -----------------------------
  makeEmptyMessage() {
    return StatusMessage.createBlank();
  }

  humanizeFieldName(fieldName) {
    const f = fieldName.replace(/([a-z0-9])([A-Z])/g, '$1 $2').toLowerCase();
    return f.replace(/\sid$/, '');
  }

  makeReadableFieldLabel(fieldName, fieldOptions) {
    if ((typeof fieldOptions !== 'undefined') && ('fieldLabel' in fieldOptions)) {
      return fieldOptions.fieldLabel;
    }
    return this.humanizeFieldName(fieldName);
  }

  getFieldValue(req, fieldName) {
    let value = '';
    if ((fieldName in req.body) && (typeof req.body[fieldName] !== 'undefined') && (req.body[fieldName] !== null)) {
      if (Array.isArray(req.body[fieldName])) {
        value = req.body[fieldName].join(' ');
      } else {
        value = req.body[fieldName].toString();
      }
      return value.trim();
    }
    return value;
  }

  prependAorAn(name) {
    if (typeof name === 'string') {
      name = ((name.match(/^[aeiou]/i) != null) ? 'an ' : 'a ') + name;
    }
    return name;
  }

  getStringFieldValue(req, fieldName, errMess = null, options = {}) {
    const fieldOptions = Object.assign({
      required: true,
      encoded: false,
    }, options);

    let value = this.getFieldValue(req, fieldName);

    if (fieldOptions.encoded) {
      value = this.entities.encode(value);
    }

    if ((value === '') && (fieldOptions.required) && (errMess !== null) && (typeof errMess === 'object')) {
      errMess.addFieldValidationError(fieldName, `${options.errorVerb} ${this.prependAorAn(this.makeReadableFieldLabel(fieldName, fieldOptions))}`);
    }

    return value;
  }

  getStringField(req, fieldName, errMess = null, options = {}) {
    options = Object.assign({
      errorVerb: 'Enter',
    }, options);

    return this.getStringFieldValue(req, fieldName, errMess, options);
  }

  getSelectField(req, fieldName, errMess = null, options = {}) {
    options = Object.assign({
      errorVerb: 'Select',
    }, options);

    return this.getStringFieldValue(req, fieldName, errMess, options);
  }


  getEncodedStringField(req, fieldName, errMess = null, options = {}) {
    return this.getStringField(req, fieldName, errMess, Object.assign({ encoded: true }, options));
  }

  getNumericField(req, fieldName, errMess = null, options = {}) {
    const fieldOptions = Object.assign({
      required: true,
      integerRequired: true,
      default: 0,
    }, options);

    let value = fieldOptions.default;
    const stringValue = this.getFieldValue(req, fieldName);

    if (stringValue === '') {
      if ((fieldOptions.required) && (errMess != null) && (typeof errMess === 'object')) {
        errMess.addFieldValidationError(fieldName, `Enter ${this.prependAorAn(this.makeReadableFieldLabel(fieldName, fieldOptions))}`);
      }
    } else {
      value = this._parseNumericValue(stringValue, errMess, fieldName, fieldOptions);
    }

    return value;
  }

  _parseNumericValue(strvalue, errMess, fieldName, fieldOptions) {
    let value = Number.parseInt(strvalue);
    if (Number.isNaN(value)) {
      if ((errMess != null) && (typeof errMess === 'object')) {
        errMess.addFieldValidationError(fieldName, `Enter ${this.prependAorAn(this.makeReadableFieldLabel(fieldName, fieldOptions))} as a number`);
        value = strvalue;
      }
    } else {
      if (('integerRequired' in fieldOptions) && (fieldOptions.integerRequired)
                && (!Number.isSafeInteger(Number.parseFloat(strvalue)))) {
        errMess.addFieldValidationError(fieldName, `Enter ${this.prependAorAn(this.makeReadableFieldLabel(fieldName, fieldOptions))} as a whole number`);
        value = strvalue;
      }

      const minError = (('min' in fieldOptions) && (value < fieldOptions.min));
      const maxError = (('max' in fieldOptions) && (value > fieldOptions.max));

      if ((minError) || (maxError)) {
        value = this._handleRangeError(fieldOptions, errMess, fieldName, value, strvalue);
      }
    }
    return value;
  }

  _handleRangeError(fieldOptions, errMess, fieldName, value, strvalue) {
    if (('min' in fieldOptions) && ('max' in fieldOptions)) {
      errMess.addFieldValidationError(fieldName, `Enter ${this.prependAorAn(this.makeReadableFieldLabel(fieldName, fieldOptions))} between ${fieldOptions.min} and ${fieldOptions.max}`);
      return strvalue;
    } if ('min' in fieldOptions) {
      errMess.addFieldValidationError(fieldName, `Enter ${this.prependAorAn(this.makeReadableFieldLabel(fieldName, fieldOptions))} greater or equal to ${fieldOptions.min}`);
      return strvalue;
    } if ('max' in fieldOptions) {
      errMess.addFieldValidationError(fieldName, `Enter ${this.prependAorAn(this.makeReadableFieldLabel(fieldName, fieldOptions))} less than or equal to ${fieldOptions.max}`);
      return strvalue;
    }
    return value;
  }

  getBooleanField(req, fieldName) {
    return this.getFieldValue(req, fieldName) !== '';
  }

  noop() {
    if (this.logger != null) {
      this.logger.debug('noop');
    }
  }

  // ---------- Field formatting -----------------------------
  formatDate(value) {
    return ViewModel.formatADate(value);
  }

  dateDifference(from, to) {
    return ViewModel.dateDifference(from, to);
  }

  // ---------- Breadcrumbs -----------------------------
  _checkBreadcrumb(bc) {
    if (!('includeInAnalytics' in bc)) {
      bc.includeInAnalytics = true;
    }
    if (!('visible' in bc)) {
      bc.visible = true;
    }
    return bc;
  }


  clearBreadcrumb(req) {
    req.breadcrumbs = [];
  }

  setBreadcrumb(req, bc) {
    req.breadcrumbs = [this._checkBreadcrumb(bc)];
  }

  addBreadcrumb(req, bc) {
    this._checkBreadcrumb(bc);
    if (('breadcrumbs' in req) && (Array.isArray(req.breadcrumbs))) {
      req.breadcrumbs.push(bc);
    } else {
      req.breadcrumbs = [bc];
    }
  }

  // ---------- Item session store -----------------------------
  storeInUserSession(req, key, value) {
    if ((!req.session.hasOwnProperty('valueStore'))
            || (typeof req.session.valueStore !== 'object')) {
      req.session.valueStore = {};
    }

    let valueAsString;
    if ((typeof value === 'undefined') || (value == null)) {
      valueAsString = '';
    } else if (typeof value === 'object') {
      valueAsString = JSON.stringify(value);
    } else {
      valueAsString = value.toString();
    }

    req.session.valueStore[key] = valueAsString;
  }

  retrieveFromUserSession(req, key) {
    let value = null;
    try {
      if (req.session.hasOwnProperty('valueStore')) {
        value = req.session.valueStore[key];
      }
    } catch (ex) {
      value = null;
    }
    return value;
  }

  retrieveObjectFromUserSession(req, key) {
    let value = null;
    try {
      const strValue = this.retrieveFromUserSession(req, key);
      value = JSON.parse(strValue);
    } catch (ex) {
      value = null;
    }
    return value;
  }

  // ---------- Messages -----------------------------
  addMessage(req, value) {
    if ((!req.session.hasOwnProperty('statusMessages'))
            || (!Array.isArray(req.session.statusMessages))) {
      req.session.statusMessages = [];
    }

    req.session.statusMessages.push(value);
  }

  clearMessages(req) {
    req.session.statusMessages = [];
  }

  setSuccessMessage(req, value) {
    const um = new StatusMessage();
    um.setSuccessMessage(value);
    this.addMessage(req, um);
  }

  setSuccessMessageSafe(req, value) {
    const um = new StatusMessage();
    um.setSuccessMessageSafe(value);
    this.addMessage(req, um);
  }

  setErrorMessage(req, value) {
    const um = new StatusMessage();
    um.setErrorMessage(value);
    this.addMessage(req, um);
  }

  addStatusMessage(req, value) {
    this.addMessage(req, value);
  }

  // ---------- Actions -----------------------------
  _renderViewModel(res, view, vm) {
    if ((this.renderDoneCallback === null) || (this.localRenderEngine === null)) {
      res.render(view, vm);
    } else {
      try {
        let viewWithExt = view;
        if (viewWithExt.match(/\.html$/i) == null) {
          viewWithExt += '.html';
        }

        vm.isWebView = false;
        vm.isPDFView = true;

        const value = this.localRenderEngine.render(viewWithExt, vm);
        this.renderDoneCallback(value);
      } catch (ex) {
        this.logger.error(ex.toString());
        if (this.renderErrorCallback) {
          this.renderErrorCallback(ex.toString());
        }
      }
    }
  }

  _renderViewAndModel(req, res, view, model) {
    const vm = new ViewModel(req, res, model, this.timeService.getNow());
    this._renderViewModel(res, view, vm);
  }

  render(req, res, view, model = null) {
    this._renderViewAndModel(req, res, view, model);
  }

  renderSuccessMessage(req, res, view, message, model = null) {
    this.setSuccessMessage(req, message);
    this._renderViewAndModel(req, res, view, model);
  }

  renderErrorMessage(req, res, view, message, model = null) {
    this.setErrorMessage(req, StatusMessage.create(message));
    this._renderViewAndModel(req, res, view, model);
  }

  json(res, model = {}, status = 200) {
    if (status === 200) {
      res.json(model);
    } else {
      res.status(status).json(model);
    }
  }

  jsonraw(res, model = {}, status = 200) {
    // return json as plain text with no line breaks.
    // This is dirty fix for the dirty browser IE9
    res.set('Content-Type', 'text/plain');
    res.status(status).send(JSON.stringify(model, null, 0));
  }

  redirect(req, res, url) {
    if (req.session) {
      req.session.save(() => {
        res.redirect(url);
      });
    } else {
      res.redirect(url);
    }
  }

  redirectSuccessMessage(req, res, url, message) {
    this.setSuccessMessage(req, message);
    this.redirect(req, res, url);
  }

  redirectSuccessMessageSafe(req, res, url, message) {
    this.setSuccessMessageSafe(req, message);
    this.redirect(req, res, url);
  }

  redirectErrorMessage(req, res, url, message) {
    this.setErrorMessage(req, message);
    this.redirect(req, res, url);
  }

  redirectToSelf(req, res) {
    this.redirect(req, res, req.url);
  }

  redirectToSelfWithSuccessMessage(req, res, message) {
    this.redirectSuccessMessage(req, res, req.url, message);
  }

  redirectToSelfWithErrorMessage(req, res, message) {
    this.redirectErrorMessage(req, res, req.url, message);
  }


  // ---------- Internal -----------------------------
  addGlobalOptionsToAction(action, options) {
    if (('homeUrl' in options) && (!('homeUrl' in action))) {
      action.homeUrl = options.homeUrl;
    }
    if (('url' in options) && (!('url' in action))) {
      action.url = options.url;
    }
    if (('view' in options) && (!('view' in action))) {
      action.view = options.view;
    }
    if (('renderWith' in options) && (!('renderWith' in action))) {
      action.renderWith = options.renderWith;
    }
  }

  checkSuppliedErrorHandler(req, res, err, options) {
    let action = null;
    let statusCode = 500;
    if ((err != null) && ('statusCode' in err)) {
      statusCode = err.statusCode;
    }

    const statusProperty = `s${statusCode.toString()}`;

    if ((statusProperty in options) && (typeof options[statusProperty] === 'object')) {
      action = Object.assign(options[statusProperty], { type: 'signout' });
      this.addGlobalOptionsToAction(action, options);

      if ('url' in action) {
        action.type = 'redirect';
      } else if (('view' in action) && (action.view.length > 0)) {
        action.type = 'rerender';
      } else if (('renderWith' in action) && (typeof action.renderWith === 'function')) {
        action.type = 'rerenderfunction';
      }

      this._checkError(action, err);
    }

    return action;
  }

  _checkError(action, err) {
    if ('errorChecker' in action) {
      try {
        err.message = '';
        action.errorChecker(err);
        if ((typeof err.message === 'undefined') || (err.message === '')) {
          action.message = 'Internal error checker problem';
          action.type = 'redirectHome';
        }
      } catch (e) {
        action.message = 'Internal error handler problem';
        action.type = 'redirectHome';
      }
    }
  }

  defaultErrorHandler(req, res, err, options) {
    const action = { type: 'signout' };

    this.addGlobalOptionsToAction(action, options);

    switch (err.statusCode) {
    case 404:
      action.message = 'Not found';
      action.type = 'redirectHome';
      break;

    case 400:
      action.message = 'Invalid Request Error has occurred';
      action.type = 'signout';
      break;

    case 500:
      action.message = 'Internal Server Error has occurred';
      action.type = 'redirectHome';
      break;

    case 401:
      action.message = 'Your session has expired';
      action.type = 'signout';
      break;

    case 422:
      action.message = 'An invalid input was supplied';
      if ('url' in action) {
        action.type = 'redirect';
      } else if (('view' in action) && (action.view.length > 0)) {
        action.type = 'rerender';
      } else if (('renderWith' in action) && (typeof action.renderWith === 'function')) {
        action.type = 'rerenderfunction';
      } else {
        action.type = 'redirectHome';
      }
      break;

    case 403:
      action.message = 'You do not have permission for that operation';
      action.type = 'redirectHome';
      break;
    default:
      break;
    }

    if ((action.type === 'redirectHome') && ('redirectUrl' in options)) {
      action.type = 'redirect';
      action.url = options.redirectUrl;
    }

    return action;
  }

  logError(err) {
    if (this.logger != null) {
      let mess = '';
      if ('message' in err) {
        mess += err.message;
      }

      if ('origStatusCode' in err) {
        mess += `, HTTP Status: ${err.origStatusCode.toString()}`;
      }

      if ('origMessage' in err) {
        mess += `, [${err.origMessage.toString()}]`;
      }

      mess = this._addInternalErrorMessages(err, mess);

      this._logError(err, mess);
    }
  }

  _addInternalErrorMessages(err, mess) {
    if (('internalErrorCode' in err) && (typeof err.internalErrorCode === 'string') && (err.internalErrorCode.length > 0)) {
      mess += `, {${err.internalErrorCode.toString()}`;
      if (('internalErrorDescription' in err) && (err.internalErrorDescription.length > 0)) {
        mess += `; ${err.internalErrorDescription}`;
      }
      if (('internalErrorStatus' in err) && (err.internalErrorStatus.length > 0)) {
        mess += `; ${err.internalErrorStatus}`;
      }
      mess += '}';
    }
    return mess;
  }

  _logError(err, mess) {
    if ((err.statusCode >= 500) || (err.statusCode == 400)) {
      this.logger.error(mess);
    } else {
      this.logger.warning(mess);
    }
  }

  handleError(req, res, err, options = {}, model = null) {
    if ((typeof err === 'undefined') || (err == null)) {
      err = StatusMessage.createError('Null Error');
    }
    else if (typeof err !== 'object') {
      const mess = err.toString();
      err = StatusMessage.createError(mess);
    } else {
      const message = err.message ? err.message : 'Error';
      const statusCode = err.statusCode ? err.statusCode : 500;
      err = StatusMessage.createError(message,statusCode);
    }

    if (!('statusCode' in err)) {
      err.statusCode = 500;
    }

    let action = this.checkSuppliedErrorHandler(req, res, err, options);
    if (action == null) {
      action = this.defaultErrorHandler(req, res, err, options);
    }

    if ('message' in action) {
      if ('message' in err) {
        err.hasOrigMessage = false;
        if (err.message !== undefined) {
          err.origMessage = err.message.toString();
        }
      }
      err.message = action.message;
    }
    if ('errorEmailLinkSubject' in action) {
      err.errorEmailLinkSubject = action.errorEmailLinkSubject;
    }
    if ('errorLinkUrl' in action) {
      err.errorLinkUrl = action.errorLinkUrl;
    }
    if ('errorLinkText' in action) {
      err.errorLinkText = action.errorLinkText;
    }
    this.addStatusMessage(req, err);

    this.logError(err);

    this._handleAction(action, req, res, model);
  }

  _handleAction(action, req, res, model) {
    switch (action.type) {
    case 'rerender':
      this.render(req, res, action.view, model);
      break;

    case 'rerenderfunction':
      action.renderWith();
      break;

    case 'redirect':
      if ('url' in action) {
        this.redirect(req, res, action.url);
      } else {
        this.redirect(req, res, this.getUsersHomePath(req, action));
      }
      break;

    case 'redirectHome':
      this.redirect(req, res, this.getUsersHomePath(req, action));
      break;

    default: // signout and any unknow actions
      // kick user out and get them to sign in again

      // authenticationService.remove_access_token(req);
      this.redirect(req, res, '/');

      break;
    }
  }
}


module.exports = ResponseService;
