
class AuthenticationService {
  constructor(config) {
    this.config = config;
    this.signinUrl = config.signinUrl || '/';
  }

  isUserAuthenticated(req) {
    return 'session' in req && 'accessToken' in req.session && req.session.accessToken;
  }

  isUserAdmin(req) {
    return 'session' in req && 'userInfo' in req.session && 'isAdmin' in req.session.userInfo && req.session.userInfo.isAdmin;
  }

  isAuthenticated(req, res, next) {
    // If a user is authenticated allow the routing to proceed.
    if (this.isUserAuthenticated(req)) {
      res.locals.isAuthenticated = true;
      return next();
    }
    // If a user isn't authenticated, send them to the login page.
    res.locals.isAuthenticated = false;
    return res.redirect(this.signinUrl);
  }

  isAdmin(req, res, next) {
    // If a user is authenticated allow the routing to proceed.
    if (this.isUserAdmin(req)) {
      return next();
    }
    return res.redirect(this.signinUrl);
  }

  removeAccessToken(req) {
    if ('session' in req) {
      req.session.accessToken = '';
      req.session.userInfo = null;
    }
  }

  saveAccessToken(req, accessToken, userInfo) {
    if ('session' in req) {
      req.session.accessToken = accessToken;
      req.session.userInfo = userInfo;

      return new Promise(function(resolve) {
        req.session.save(() => {
          resolve('session saved');
        });
      });
    }
    return Promise.reject('Missing session');
  }
}

module.exports = AuthenticationService;
