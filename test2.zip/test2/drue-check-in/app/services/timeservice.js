const moment = require('moment-timezone');

class TimeService {
  constructor() {
    this.internalNow = function () {
      return moment();
    };

    this.internalToday = function () {
      const m = this.internalNow();
      return m.format('YYYY-MM-DD');
    };

    this._todayPlusDays = function (days) {
      const m = this.internalNow().add(days, 'days');
      return m.format('YYYY-MM-DD');
    };
  }

  getToday() {
    return this.internalToday();
  }

  getTodayPlusDays(days) {
    return this._todayPlusDays(days);
  }

  getTodayMinusDays(days) {
    return this._todayPlusDays(-1 * days);
  }

  getNow() {
    return this.internalNow();
  }

  setNow(fn) {
    this.internalNow = fn;
  }


  getNextDateOnWeekDay(date, in_weeks, weekday = 3) {
    let m = moment(date);
    if (in_weeks !== 0) {
      m = m.add(in_weeks, 'weeks');
    }
    while (m.isoWeekday() !== weekday) {
      m = m.add(1, 'days');
    }
    return m;
  }


  startStopWatch() {
    return Date.now();
  }

  timeStopWatch(stopwatch) {
    return Date.now() - stopwatch;
  }
}

module.exports = TimeService;
