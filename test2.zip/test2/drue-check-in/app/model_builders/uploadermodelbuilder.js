const fs = require('fs-extra');
const XLSX = require('xlsx');
const moment = require('moment');

class UploaderModelBuilder {
  constructor(context, apiFacadeService) {
    this.context = context;
    this.logger = this.context.sharedServices.logger;
    this.config = this.context.sharedServices.config;
    this.validationUtil = this.context.validationUtil;

    this.duplicateInitialsAreErrors = false;

    this.api = apiFacadeService;

    this.maxRow = 10000;
  }

  isValidText(value) {
    return value !== null && typeof value !== 'undefined' ? value.toString().length > 0 : false;
  }


  isValidAndPermittedEmail(email) {
    return (this.validationUtil.emailValidator(email, false) !== '');
  }

  cellValue(worksheet, cellId) {
    const desiredCell = worksheet[cellId];
    return (desiredCell ? desiredCell.v.toString().trim() : '');
  }

  checkCellValue(worksheet, cellId, value) {
    //this.context.sharedServices.logger.info(`${this.cellValue(worksheet, cellId)} == ${value}`);
    return this.cellValue(worksheet, cellId) === value;
  }

  cellId(col, row) {
    return col + row.toString();
  }

  findCellByValue(worksheet, value, col = 'A', initialRow = 1) {
    for (let row = initialRow; row <= this.maxRow; row++) {
      const cellId = this.cellId(col, row);
      if (this.checkCellValue(worksheet, cellId, value)) {
        return row;
      }
    }

    return null;
  }

  buildUploadModel(file, dateOfAppointments, errMess) {
    const model = {
      validSpreadsheet: false,
      validDataEntered: false,
      validDataIntegrity: false,
      jobCentreName: '',
      dateOfAppointmentsString: dateOfAppointments.format('dddd, D MMMM YYYY'),
      planId: 0,
      requestor: '',
      lastUpdated: '',
      appointments: [],
      locations: [],
      agents: [],
      sheetErrors: [],
      totalNumErrors: 0,
      totalUserActions: 0,
    };

    if (!fs.existsSync(file.path)) {
      this.logger.error(`File upload failed to find uploaded file: ${file.path}`);
      errMess.setErrorMessage('Internal error, upload file not found', 500);
      return model;
    }

    try {
      const workbook = this.validateWorkbook(model, file, errMess);

      // The workbook is a valid file so now extract the data
      if (!errMess.isError) {
        this.buildJobCentreModelFromValidWorkSheet(model, workbook);
        this.buildUCFSModelFromValidWorkSheet(model, dateOfAppointments, workbook);
        this.buildLMSModelFromValidWorkSheet(model, dateOfAppointments, workbook);
        this.buildLocationsModelFromValidWorkSheet(model, workbook);
        this.buildAgentsModelFromValidWorkSheet(model, workbook);
        this.validateModelData(model, errMess);
      }

      if (model.appointments.length > 0) {
        model.totalUserActions++;
      }

      this.processErrorMessages(model, errMess);
    } catch (ex) {
      this.logger.error(`Error processing uploaded file: ${file.path}, {${ex.toString()}}`);
      errMess.setErrorMessage('Internal error, processing upload file', 500);
    }

    // delete the file now we have processed it
    if (!fs.existsSync(file.path)) {
      this.logger.error(`File upload, failed to find uploaded file: ${file.path}`);
    }

    fs.unlinkSync(file.path);

    this.logger.info(`Removing uploaded file: ${file.path}`);

    if (fs.existsSync(file.path)) {
      this.logger.error(`Failed to remove uploaded file: ${file.path}`);
    }

    return model;
  }

  hasWorksheet(workbook, name) {
    return name in workbook.Sheets;
  }

  validateWorkbook(paramModel, file, errMess) {
    const model = paramModel;
    if (!file.originalname.match(/\.xlsx$/i)) {
      errMess.addFieldValidationError('qqfile', `Upload a valid ‘${this.config.serviceName} daily appointments’ spreadsheet`);
      return null;
    }

    // read the file and extract its data
    const workbook = XLSX.readFile(file.path);

    if (workbook == null) {
      errMess.addFieldValidationError('qqfile', `Upload a valid ‘${this.config.serviceName} daily appointments’ spreadsheet`);
      return null;
    }

    // Check the tab names
    if ((!this.hasWorksheet(workbook, 'UCFS'))
      || (!this.hasWorksheet(workbook, 'AJCS'))
      || (!this.hasWorksheet(workbook, 'LMS'))
      || (!this.hasWorksheet(workbook, 'JC Locations'))
      || (!this.hasWorksheet(workbook, 'JC Agents'))
      || (!this.hasWorksheet(workbook, 'Job Centre'))
    ) {
      model.validSpreadsheet = false;
      errMess.addFieldValidationError('qqfile', `Upload a valid ‘${this.config.serviceName} daily appointments’ spreadsheet. Unexpected Tabs found`);
      return null;
    }

    model.validSpreadsheet = true;

    return workbook;
  }

  createAppointment(appointment) {
    if ((!this.isValidText(appointment.time))
         || (!this.isValidText(appointment.customerFirstName))
         || (!this.isValidText(appointment.customerLastName))
         || (!this.isValidText(appointment.agentFirstNameAndInitial))) {
      return null;
    }

    return appointment;
  }

  buildJobCentreModelFromValidWorkSheet(paramModel, workbook) {
    const model = paramModel;
    const worksheet = workbook.Sheets['Job Centre'];

    model.jobCentreName = this.cellValue(worksheet, 'A2');

    if (model.jobCentreName.length <= 0) {
      model.sheetErrors.push('Enter the name of the job centre');
    }
  }

  makeDateTimeFromString(dateOfAppointments, value) {
    const fullDateTime = `${dateOfAppointments.format('YYYY-MM-DD')} ${value}`;
    const dt = moment(fullDateTime, 'YYYY-MM-DD h:mma');
    return dt.format('YYYY-MM-DDTHH:mm:ss.SSSZ');
  }

  buildUCFSModelFromValidWorkSheet(paramModel, dateOfAppointments, workbook) {
    this.buildUCFSStyleModelFromValidWorkSheet(paramModel, dateOfAppointments, workbook.Sheets.UCFS, 'UCFS');
  }

  buildLMSModelFromValidWorkSheet(paramModel, dateOfAppointments, workbook) {
    this.buildUCFSStyleModelFromValidWorkSheet(paramModel, dateOfAppointments, workbook.Sheets.LMS, 'LMS');
  }


  buildUCFSStyleModelFromValidWorkSheet(paramModel, dateOfAppointments, worksheet, sourceSystem) {
    const model = paramModel;

    // find title row
    const titleRow = this.findCellByValue(worksheet, 'Time', 'A');
    if ((titleRow == null)
      || (!this.checkCellValue(worksheet, this.cellId('B', titleRow), 'First name'))
      || (!this.checkCellValue(worksheet, this.cellId('C', titleRow), 'Last name'))
      || (!this.checkCellValue(worksheet, this.cellId('D', titleRow), 'Work coach'))
    ) {
      model.validDataEntered = false;
      model.sheetErrors.push('UCFS appointment data not found');
      return;
    }

    // Load the data
    let row = titleRow + 1;
    let numNonAppointment = 0;
    let dataFound = true;

    while (dataFound && row <= this.maxRow) {
      const apptTime = this.cellValue(worksheet, this.cellId('A', row));
      const appointment = this.createAppointment({
        source: sourceSystem,
        sourceRow: row,
        time: this.makeDateTimeFromString(dateOfAppointments, apptTime),
        timeOnly: apptTime,
        customerFirstName: this.cellValue(worksheet, this.cellId('B', row)),
        customerLastName: this.cellValue(worksheet, this.cellId('C', row)),
        agentFirstNameAndInitial: this.cellValue(worksheet, this.cellId('D', row)),
      });
      if (appointment) {
        model.appointments.push(appointment);
        numNonAppointment = 0;
      } else {
        numNonAppointment += 1;
        if (numNonAppointment >= 2) {
          dataFound = false;
        }
      }

      row++;
    }

    model.validDataEntered = true;
  }

  buildLocationsModelFromValidWorkSheet(paramModel, workbook) {
    const model = paramModel;
    const worksheet = workbook.Sheets['JC Locations'];

    // find title row
    const titleRow = this.findCellByValue(worksheet, 'Id', 'A');
    if ((titleRow == null)
      || (!this.checkCellValue(worksheet, this.cellId('B', titleRow), 'Location title'))
      || (!this.checkCellValue(worksheet, this.cellId('C', titleRow), 'How to get there'))
    ) {
      model.validDataEntered = false;
      model.sheetErrors.push('Job centre location data not found');
      return;
    }

    // Load the data
    let row = titleRow + 1;
    let dataFound = true;

    while (dataFound && row <= this.maxRow) {
      const item = {
        id: this.cellValue(worksheet, this.cellId('A', row)),
        title: this.cellValue(worksheet, this.cellId('B', row)),
        instruction: this.cellValue(worksheet, this.cellId('C', row)),
      };

      if (this.isValidText(item.id)) {
        model.locations.push(item);
      } else {
        dataFound = false;
      }

      row++;
    }

    model.validDataEntered = true;
  }

  buildAgentsModelFromValidWorkSheet(paramModel, workbook) {
    const model = paramModel;
    const worksheet = workbook.Sheets['JC Agents'];


    // find title row
    const titleRow = this.findCellByValue(worksheet, 'Agent on appointment', 'A');
    if ((titleRow == null)
      || (!this.checkCellValue(worksheet, this.cellId('C', titleRow), 'Actual agent, if different'))
      || (!this.checkCellValue(worksheet, this.cellId('E', titleRow), 'Location'))
      || (!this.checkCellValue(worksheet, this.cellId('F', titleRow), 'Instruction'))
    ) {
      model.validDataEntered = false;
      model.sheetErrors.push('Job centre agent data not found');
      return;
    }

    // Load the data
    let row = titleRow + 2;
    let dataFound = true;

    while (dataFound && row <= this.maxRow) {
      const item = {
        apptAgentFirstName: this.cellValue(worksheet, this.cellId('A', row)),
        apptAgentLastName: this.cellValue(worksheet, this.cellId('B', row)),
        actualAgentFirstName: this.cellValue(worksheet, this.cellId('C', row)),
        actualAgentLastName: this.cellValue(worksheet, this.cellId('D', row)),
        locationId: this.cellValue(worksheet, this.cellId('E', row)),
        instruction: this.cellValue(worksheet, this.cellId('F', row)),
      };

      item.lastNameInitial = item.apptAgentLastName.substring(0, 1);
      item.firstNameAndInitial = `${item.apptAgentFirstName} ${item.lastNameInitial}.`;

      if ((this.isValidText(item.apptAgentFirstName))
        && (this.isValidText(item.apptAgentLastName))) {
        model.agents.push(item);
      } else {
        dataFound = false;
      }

      row++;
    }

    model.validDataEntered = true;
  }

  validateLocations(model, errMess) {
    const ids = new Set();
    const titles = new Set();
    model.locations.forEach((l) => {
      if ((!this.isValidText(l.id)) || (!this.isValidText(l.title)) || (!this.isValidText(l.instruction))) {
        errMess.addFieldValidationError('qqfile', `The location '${l.id}' must have an id, title and instruction defined`);
      }

      if ((this.isValidText(l.id)) && (ids.has(l.id))) {
        errMess.addFieldValidationError('qqfile', `The location id '${l.id}' must only be defined once`);
      } else {
        ids.add(l.id);
      }

      if ((this.isValidText(l.title)) && (titles.has(l.title))) {
        errMess.addFieldValidationError('qqfile', `The location title '${l.title}' must only be defined once`);
      } else {
        titles.add(l.title);
      }
    });
  }

  validateAgents(model, errMess) {
    model.agents.forEach((a) => {
      if ((a.locationId === '') && (a.instruction === '')) {
        errMess.addFieldValidationError('qqfile', `The agent '${a.apptAgentFirstName} ${a.apptAgentLastName}' must have either a location or an instruction defined`);
      }
    });
  }

  validateAgentsLocations(model, errMess) {
    model.agents.forEach((a) => {
      if ((a.locationId !== '') && (typeof model.locations.find(l => l.id == a.locationId) === 'undefined')) {
        errMess.addFieldValidationError('qqfile', `The location '${a.locationId}' for agent '${a.apptAgentFirstName} ${a.apptAgentLastName}' has not been defined`);
      }
    });
  }

  findAgentFromFirstNameAndInitial(model, agentFirstNameAndInitial) {
    return model.agents.find(a => agentFirstNameAndInitial === a.firstNameAndInitial);
  }

  validateAppointments(model, errMess) {
    const uniqueTimeInitials = new Set();

    model.appointments.forEach((a) => {
      if ((!this.isValidText(a.time)) || (!this.isValidText(a.customerFirstName)) || (!this.isValidText(a.customerLastName))
      || (!this.isValidText(a.agentFirstNameAndInitial))) {
        errMess.addFieldValidationError('qqfile', `The appointment '${a.source}, row ${a.sourceRow}' must have a valid time, customer first name, customer last name and agent name `);
      } else {
        const agent = this.findAgentFromFirstNameAndInitial(model, a.agentFirstNameAndInitial);
        if (agent) {
          a.agentFirstName = agent.apptAgentFirstName;
          a.agentLastName = agent.apptAgentLastName;
        } else {
          errMess.addFieldValidationError('qqfile', `The appointment '${a.source}, row ${a.sourceRow}' has an undefined agent: '${a.agentFirstNameAndInitial}'`);
        }

        const uniqueInitialString= `${a.customerFirstName.substring(0, 1).toUpperCase()}  ${a.customerLastName.substring(0, 1).toUpperCase()}`;
        const uniqueTimeInitialString = `${a.time} ${uniqueInitialString}`;
        if (uniqueTimeInitials.has(uniqueTimeInitialString)) {
          errMess.addSubMessage(`The appointment '${a.source}, row ${a.sourceRow}' has the same initials, ${uniqueInitialString}, as another row`);
        } else {
          uniqueTimeInitials.add(uniqueTimeInitialString);
        }

      }
    });
  }

  validateModelData(model, errMess) {
    this.validateLocations(model, errMess);
    this.validateAgents(model, errMess);
    this.validateAgentsLocations(model, errMess);
    this.validateAppointments(model, errMess);
  }

  processErrorMessages(paramModel, errMess) {
    const model = paramModel;
    if (!errMess.isError) {
      model.sheetErrors.forEach((e) => {
        errMess.addFieldValidationError('qqfile', e);
      });
      model.totalNumErrors = model.sheetErrors.length;
      model.validDataEntered = model.totalNumErrors === 0;

      if (!model.validDataEntered) {
        errMess.setMessage("There's a problem with the spreadsheet");
      }
    }
  }

  // /+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  buildModelForDatastore(model) {
    const dataStoreModel = {
      jobCentre: {
        name: model.jobCentreName,
      },
      locations: model.locations.map(v => ({
        code: v.id,
        title: v.title,
        instruction: v.instruction,
      })),
      agents: model.agents.map(v => ({
        firstName: v.apptAgentFirstName,
        lastName: v.apptAgentLastName,
        locationCode: v.locationId,
        instruction: v.instruction,
      })),
      appointments: model.appointments.map(v => ({
        source: v.source,
        time: v.time,
        customerFirstName: v.customerFirstName,
        customerLastName: v.customerLastName,
        agentFirstName: v.agentFirstName,
        agentLastName: v.agentLastName,
      })),
    };


    //const modelString = JSON.stringify(dataStoreModel, null, 1);
    //console.log(modelString);

    // hack for now
    /*
    return {
      id: 0,
      name: model.jobCentreName,
    };
    */


    return dataStoreModel;
  }

  implementActionsOfUploadModel(model, sessionAccessToken) {
    this.logger.info(`Uploading appointments for ${model.jobCentreName}`);
    return this.api.post('/drue/api/upload', sessionAccessToken, this.buildModelForDatastore(model));
  }
}

module.exports = UploaderModelBuilder;
