const moment = require('moment-timezone');
const Chance = require('chance');

class SimpleAppointmentsModelBuilder {
  constructor(context, variant) {
    this.variant = variant;
    this.context = context;
  }

  generateForToday(model) {
    this.chance = new Chance(12345);

    const now = moment();
    // this.context.sharedServices.logger.info(`Time generatedForToday by momnet is: ${now}`);

    const lastPossibleAppt = moment(Object.assign({}, { year: now.year(), month: now.month(), date: now.date() }, model.lastAppt));

    let nextAppt = moment(Object.assign({}, { year: now.year(), month: now.month(), date: now.date() }, model.firstAppt));

    while (nextAppt.isSameOrBefore(lastPossibleAppt)) {
      //     console.log(`${nextAppt.format('hh:mma')}`);
      model.all.push(nextAppt);
      const tenMinuteMod = nextAppt.minute() % 10;
      const dice = this.chance.integer({ min: 1, max: 6 });

      let mins;
      if (tenMinuteMod === 0) {
        // already on a ten minute time slot
        switch (dice) {
        case 1:
          mins = 5;
          break;

        case 2:
        case 3:
          mins = 20;
          break;

        case 4:
          mins = 30;
          break;

        default:
          mins = 10;
          break;
        }
      } else {
        // on a five minute time slot
        switch (dice) {
        case 1:
          mins = 5;
          break;

        case 2:
          mins = 10;
          break;

        case 3:
          mins = 25;
          break;

        default:
          mins = 15;
          break;
        }
      }

      if (this.variant === 'A') {
        mins = 5;
      }

      nextAppt = moment(nextAppt).add(mins, 'm');
    }
  }

  timeToDate(now, value) {
    try {
      return moment(`${now.year()}-${now.month() + 1}-${now.date()} ${value}`, 'YYYY-MM-DD h:mma');
    } catch (ex) {
      return null;
    }
  }

  selectViewForNow(paramModel, nextAppts, prevAppts) {
    const model = paramModel;
    const now = moment();
    let nextApptOffset = -1;

    if (nextAppts !== '') {
      const tm = this.timeToDate(now, nextAppts);
      if (tm) {
        if (this.context.sharedServices) {
          this.context.sharedServices.logger.info(`${tm.format('YYYYY-MM-DD h:mma')}`);
        }
        nextApptOffset = model.all.findIndex(appt => tm.isBefore(appt));

        if (nextApptOffset + model.maxInView >= model.all.length) {
          model.hasLaterAppts = false;
        }

        if (nextApptOffset < 0) {
          nextApptOffset = model.all.length > 0 ? model.all.length - 1 : 0;
        }
      }
    } else if (prevAppts !== '') {
      const tm = this.timeToDate(now, prevAppts);
      if (tm) {
        if (this.context.sharedServices) {
          this.context.sharedServices.logger.info(`${tm.format('YYYYY-MM-DD h:mma')}`);
        }

        nextApptOffset = model.all.findIndex(appt => tm.isSameOrBefore(appt));

        if (nextApptOffset <= 0) {
          model.hasEarlierAppts = false;
        }

        nextApptOffset -= model.maxInView;
        if (nextApptOffset < 0) {
          nextApptOffset = 0;
        }
      }
    }

    if (nextApptOffset < 0) {
      nextApptOffset = model.all.findIndex(appt => now.isSameOrBefore(appt));
      if (nextApptOffset >= 2) {
        nextApptOffset -= 2;
      }
    }

    if (nextApptOffset < 0) {
      nextApptOffset = model.all.length > 0 ? model.all.length - 1 : 0;
    }

    const startOffset = nextApptOffset;

    /*
    if (offset > 0) {
      while ((model.viewOffset < offset) &&
              (startOffset + model.maxInView < model.all.length)) {
                model.viewOffset += 1;
                startOffset += model.maxInView;
      }
    } else if (offset < 0) {
      while ((model.viewOffset > offset) &&
              (startOffset - model.maxInView > 0)) {
                model.viewOffset -= 1;
                startOffset -= model.maxInView;
      }
    }
*/

    const endOffset = startOffset + model.maxInView;

    model.view = model.all.slice(startOffset, endOffset);
  }

  build(nextAppts = '', prevAppts = '') {
    const model = {
      maxInView: 12,
      firstAppt: { hour: 9, minute: 0 },
      lastAppt: { hour: 16, minute: 45 },
      viewOffset: 0,
      all: [],
      view: [],
      viewStr: [],
      hasEarlierAppts: true,
      hasLaterAppts: true,
    };

    this.generateForToday(model);
    this.selectViewForNow(model, nextAppts, prevAppts);

    model.viewStr = model.view.map(a => a.format('h:mma'));

    if (model.viewStr.length > 0) {
      model.nextAppts = `?nextappts=${model.viewStr[model.viewStr.length - 1]}`;
      model.prevAppts = `?prevappts=${model.viewStr[0]}`;
    }

    model.view.forEach((a) => {
      if (this.context.sharedServices) {
        this.context.sharedServices.logger.info(`${a.format('YYYYY-MM-DD h:mma')}`);
      }
    });

    return model;
  }
}

module.exports = SimpleAppointmentsModelBuilder;
