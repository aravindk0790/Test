const moment = require('moment-timezone');
const Chance = require('chance');
const fs = require('fs-extra');
const path = require('path');

const globalChance = new Chance();

class SimulatedAppointmentsModelBuilder {
  constructor(context, variant) {
    this.variant = variant;
    this.context = context;
  }

  standardParams() {
    const now = moment();


    return {
      changeSeed: this.seedRandomNumberGenerator(),
      today: { year: now.year(), month: now.month(), date: now.date() },
      jobCentreName: 'default',
      maxInView: 12,
      firstAppt: { hour: 9, minute: 0 },
      lastAppt: { hour: 16, minute: 45 },
      timeSlotsPerHour: 7,
      workingHoursPerDay: 8,
      numberOfAgents: 20,
      numberOfLocations: 5,
      numberOfVisitors: 250,
      percentageHaveAppts: 80 / 100,
      probabilityUseByVisitorWithNoAppt: 10 / 100,
      probabilityCustomerMistake: 10 / 100,
    };
  }

  seedRandomNumberGenerator() {
    return globalChance.integer();
  }

  calcDerivedParams(params) {
    const calcedParams = {
      chance: new Chance(params.changeSeed),
      baseParams: params,
      derivedParams: {},
    };

    calcedParams.derivedParams.numCustomersWithAppts = Math.round(params.numberOfVisitors * (params.percentageHaveAppts));
    calcedParams.derivedParams.numVisitorsWithNoAppt = Math.round(params.numberOfVisitors * (1 - params.percentageHaveAppts));
    calcedParams.derivedParams.numVisitorsWithNoApptAndUseSystem = Math.round(calcedParams.derivedParams.numVisitorsWithNoAppt
        * (params.probabilityUseByVisitorWithNoAppt));

    calcedParams.derivedParams.firstAppt = moment(Object.assign({}, {
      year: params.today.year,
      month: params.today.month,
      date: params.today.date,
    }, params.firstAppt));


    return calcedParams;
  }

  makeLocation(id) {
    return {
      id,
      title: id === 0 ? 'Reception desk' : `Waiting area ${id}`,
      description: id === 0 ? 'Go straight through to the reception desk' : `Go to Waiting area ${id}`,
    };
  }

  makeLocations(params) {
    const items = [];
    for (let i = 0; i < params.baseParams.numberOfLocations; i++) {
      items.push(this.makeLocation(i));
    }
    return items;
  }

  randomFirstName(params, offset) {
    const randomGender = offset % 2 === 0 ? 'male' : 'female';
    return params.chance.first({ gender: randomGender, nationality: 'en' });
  }

  randomLastName(params) {
    return params.chance.last({ nationality: 'en' });
  }

  makeAgent(id, params, locations) {
    const agent = {
      id,
      firstName: this.randomFirstName(params, id),
      lastName: this.randomLastName(params, id),
      location: locations[params.chance.integer({ min: 0, max: locations.length - 1 })].id,
      actualFirstName: '',
      actualLastName: '',
      instruction: '',
    };

    agent.lastInitial = `${agent.lastName.substring(0, 1)}`;
    agent.agentUcName = `${agent.firstName} ${agent.lastInitial}.`;

    if ((id > 0) && (id % 5 === 0)) {
      agent.instruction = `Wait in reception and your work coach ${agent.firstName} will come and collect you.`;
    }

    return agent;
  }

  makeAgents(params, locations) {
    const items = [];
    while (items.length < params.baseParams.numberOfAgents) {
      const agent = this.makeAgent(items.length + 1, params, locations);
      if (!items.find(a => a.firstName === agent.firstName
        && a.lastInitial === agent.lastInitial)) {
        items.push(agent);
      }
    }
    return items;
  }

  makeTimeslot(hour, slot, params, slotsInHour) {
    const mins = (hour * 60) + slotsInHour[slot];

    const tm = moment(params.derivedParams.firstAppt).add(mins, 'm');

    const timeSlot = {
      time: tm,
      ucTime: tm.format('h:mma'),
      ucDateTime: tm.format('YYYY-MM-DD h:mma'),
      appointments: [],
    };

    return timeSlot;
  }


  makeTimeslots(params) {
    const items = [];
    const slotsInHour = [];

    for (let s = 0; s < params.baseParams.timeSlotsPerHour; s++) {
      if (s < 6) {
        slotsInHour.push(s * 10);
      } else {
        slotsInHour.push(((s - 6) * 10) + 5);
      }
    }
    const sortedSlotsInHour = slotsInHour.sort((a, b) => a > b);


    for (let i = 0; i < params.baseParams.workingHoursPerDay; i++) {
      for (let j = 0; j < params.baseParams.timeSlotsPerHour; j++) {
        items.push(this.makeTimeslot(i, j, params, sortedSlotsInHour));
      }
    }
    return items;
  }

  findATimeSlot(params, model) {
    let timeSlot = model.timeSlots.find(t => t.appointments.length === 0);

    if (typeof timeSlot === 'undefined') {
      timeSlot = null;
      while (timeSlot === null) {
        timeSlot = model.timeSlots[
          params.chance.integer({ min: 0, max: model.timeSlots.length - 1 })];
        if (timeSlot.appointments.length >= params.baseParams.numberOfAgents) {
          timeSlot = null;
        }
      }
    }

    return timeSlot;
  }


  makeAppointment(id, params, model) {
    const appointment = {
      id,
      customerFirstName: this.randomFirstName(params, id),
      customerLastName: this.randomLastName(params, id),
      timeSlot: this.findATimeSlot(params, model),
      agent: model.agents[params.chance.integer({ min: 0, max: model.agents.length - 1 })],
    };

    appointment.customerFirstInitial = `${appointment.customerFirstName.substring(0, 1)}`;
    appointment.customerLastInitial = `${appointment.customerLastName.substring(0, 1)}`;

    appointment.ucTime = appointment.timeSlot.ucTime;
    appointment.agentFirstNameAndInitial = appointment.agent.agentUcName;

    return appointment;
  }

  makeAppointments(params, model) {
    const items = [];
    let numAppts = 0;
    while (numAppts < params.derivedParams.numCustomersWithAppts) {
      const appointment = this.makeAppointment(numAppts + 1, params, model);

      if ((appointment.timeSlot.appointments.length < params.baseParams.numberOfAgents - 1)
         && (!appointment.timeSlot.appointments.find(app => app.agent.id === appointment.agent.id))) {
        appointment.timeSlot.appointments.push(appointment);
        numAppts += 1;
      } else {
        // console.log('found duplicate');
      }
    }

    let apptId = 0;
    let timeSlotOffset = 0;
    model.timeSlots.forEach((s) => {
      // console.log(`${s.ucTime} appts: ${s.appointments.length}`);

      s.appointments.forEach((e) => {
        // console.log(`${e.ucTime}, ${e.customerFirstName}, ${e.customerLastName}, ${e.agentFirstNameAndInitial}`);
        apptId += 1;
        e.id = apptId;
        e.timeSlotOffset = timeSlotOffset;
        items.push(e);
      });

      timeSlotOffset += 1;
    });

    return items;
  }

  makeStats(params, model) {
    const stats = {
      totalAppts: model.appointments.length,
      totalDuplicatesInDay: 0,
      totalDuplicatesInATimeSlot: 0,
    };

    const dupInitialCount = new Map();
    const dupTimeInitialCount = new Map();

    model.appointments.forEach((a) => {
      const combined = a.customerFirstInitial + a.customerLastInitial;
      if (!dupInitialCount.has(combined)) {
        dupInitialCount.set(combined, 1);
      } else {
        dupInitialCount.set(combined, dupInitialCount.get(combined) + 1);
      }

      const combinedTime = a.ucTime + combined;

      if (!dupTimeInitialCount.has(combinedTime)) {
        dupTimeInitialCount.set(combinedTime, 1);
      } else {
        dupTimeInitialCount.set(combinedTime, dupTimeInitialCount.get(combinedTime) + 1);
      }

      // console.log(combinedTime);
    });

    dupInitialCount.forEach((value, key) => {
      if (value > 1) {
        stats.totalDuplicatesInDay += value;
      }
    });

    dupTimeInitialCount.forEach((value, key) => {
      if (value > 1) {
        stats.totalDuplicatesInATimeSlot += value;
      }
    });


    return stats;
  }

  buildModel(coreParams) {
    const params = this.calcDerivedParams(coreParams);

    const model = {
      params,
      jobCentre: params.baseParams.jobCentreName,
      locations: [],
      agents: [],
      timeSlots: [],
      appointments: [],
      stats: {},
    };

    model.locations = this.makeLocations(params);
    model.agents = this.makeAgents(params, model.locations);
    model.timeSlots = this.makeTimeslots(params);
    model.appointments = this.makeAppointments(params, model);
    model.stats = this.makeStats(params, model);


    return model;
  }

  exportLocations(model, testDir, baseTestFileName) {
    const filePath = `${path.join(testDir, baseTestFileName)}locations.csv`;
    const writeStream = fs.createWriteStream(filePath);
    model.locations.forEach((a) => {
      writeStream.write(`"${a.id}","${a.title}","${a.description}"\n`, 'utf8');
    });
    writeStream.end();
  }

  exportAgents(model, testDir, baseTestFileName) {
    const filePath = `${path.join(testDir, baseTestFileName)}agents.csv`;
    const writeStream = fs.createWriteStream(filePath);
    model.agents.forEach((a) => {
      writeStream.write(`"${a.firstName}","${a.lastName}","${a.actualFirstName}","${a.actualLastName}","${a.location}","${a.instruction}"\n`, 'utf8');
    });
    writeStream.end();
  }

  exportAppointments(model, testDir, baseTestFileName) {
    const filePath = `${path.join(testDir, baseTestFileName)}appointments.csv`;
    const writeStream = fs.createWriteStream(filePath);
    model.appointments.forEach((a) => {
      writeStream.write(`"${a.ucTime}","${a.customerFirstName}","${a.customerLastName}","${a.agentFirstNameAndInitial}"\n`, 'utf8');
    });
    writeStream.end();
  }


  export(model, testDir, baseTestFileName) {
    fs.ensureDirSync(testDir);

    this.exportLocations(model, testDir, baseTestFileName);
    this.exportAgents(model, testDir, baseTestFileName);
    this.exportAppointments(model, testDir, baseTestFileName);
  }
}

module.exports = SimulatedAppointmentsModelBuilder;
