const path = require('path');
const fs = require('fs-extra');
const express = require('express');
const nunjucks = require('nunjucks');
const expressSession = require('express-session');
const FileStore = require('session-file-store')(expressSession);
const ValidationUtil = require('./utils/validationutil');
const AuthenticationService = require('./services/authenticationservice');
const BodyParser = require('body-parser');

const AdminController = require('./controllers/adminmenucontroller');
const AuthenticationController = require('./controllers/authenticationcontroller');

const CustomerCheckinControllerv1 = require('./controllers/customercheckincontrollerv1');
const CustomerCheckinControllerv2 = require('./controllers/customercheckincontrollerv2');
const CustomerCheckinControllerv3 = require('./controllers/customercheckincontrollerv3');
const CustomerCheckinControllerv6 = require('./controllers/customercheckincontrollerv6');

const onehour = 3600000;

class CheckInServer {
  constructor(sharedServices, apiFacadeService, responseService) {
    this.apiFacadeService = apiFacadeService;
    this.responseService = responseService;
    this.authenticationService = new AuthenticationService(sharedServices.config);
    this.context = this.makeAppContext(sharedServices);
  }

  makeAppContext(sharedServices) {
    return {
      sharedServices,
      authenticationService: this.authenticationService,
      validationUtil: new ValidationUtil(sharedServices.config),
      middleware: {
        noCache: this.noCache.bind(this),
        isAuthenticated: this.authenticationService.isAuthenticated.bind(
          this.authenticationService,
        ),
        isAdmin: this.authenticationService.isAdmin.bind(
          this.authenticationService,
        ),
      },
    };
  }

  startUp() {
    
    this.context.sharedServices.logger.info(`API Server: ${this.context.sharedServices.config.dataApiProtocol}://${this.context.sharedServices.config.dataApiDomain}:${this.context.sharedServices.config.dataApiPort}`);
    return Promise.resolve();
  }

  noCache(req, res, next) {
    res.set({
      'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
      Expires: '0',
      Pragma: 'no-cache',
      'Surrogate-Control': 'no-store',
    });
    this.context.sharedServices.logger.logHTTPStartOfRequest(req, res);
    return next();
  }

  globalMiddleware(req, res, next) {
    res.locals.appVersion = this.context.sharedServices.config.appVersion;
    res.locals.serviceName = this.context.sharedServices.config.serviceName;
    res.locals.projectName = this.context.sharedServices.config.projectName;
    next();
  }

  makeApp() {
    const app = this.context.sharedServices.createApp(apppath => apppath);

    app.set('view engine', 'html');

    app.set('strict routing', true);
    app.set('x-powered-by', false);
    app.set('etag', false);

    this.nunjuctsEnv = nunjucks.configure(
      [
        'node_modules/govuk-frontend/govuk/',
        'node_modules/govuk-frontend/govuk/components/',
        'views',
      ],
      {
        autoescape: true,
        watch: false,
        noCache: false,
        express: app,
      },
    );

    this.createSessionStore(app);

    return app;
  }

  addRoutesToApp(app) {
    // static routes
    app.use('/assets', this.defineStatic(app));

    // body parsing

    // Support for parsing data in POSTs
    app.use(
      BodyParser.json({
        limit: '1mb',
      }),
    );
    app.use(
      BodyParser.urlencoded({
        extended: true,
        limit: '1mb',
        parameterLimit: 15000,
      }),
    );

    // global
    app.use(this.globalMiddleware.bind(this));

    // customer routes
    this.customerCheckinController1 = this.addController(
      app,
      '/check-in-v1/',
      CustomerCheckinControllerv1,
    );
    this.customerCheckinController2A = this.addController(
      app,
      '/check-in-v2/A/',
      CustomerCheckinControllerv2,
      { variant: 'A' },
    );
    this.customerCheckinController2B = this.addController(
      app,
      '/check-in-v2/B/',
      CustomerCheckinControllerv2,
      { variant: 'B' },
    );
    this.customerCheckinController3A = this.addController(
      app,
      '/check-in-v3/A/',
      CustomerCheckinControllerv3,
      { variant: 'A' },
    );
    this.customerCheckinController3B = this.addController(
      app,
      '/check-in-v3/B/',
      CustomerCheckinControllerv3,
      { variant: 'B' },
    );
    this.customerCheckinController6 = this.addController(
      app,
      '/check-in-v6/',
      CustomerCheckinControllerv6,
      { variant: 'A' },
    );

    // admin routes
    this.adminController = this.addController(app, '/admin/', AdminController);

    // authorisation
    this.authenticationController = this.addController(app, '/', AuthenticationController);

    this.authenticationController.adminHomeUrl = '/admin/';
    this.authenticationController.checkinHomeUrl = '/check-in-v6/';


    /*
        // redirect root to latest prototype
        app.use(/^\/$/, (req, res) => {
            res.redirect('/check-in-v2/A/');
        });
        */

    app.get('/menu', this.context.middleware.noCache, this.onWelcome.bind(this));

    this.defineErrors(app);
  }

  onWelcome(req, res) {
    const view = 'prototypemenu';
    this.responseService.render(req, res, view);
  }

  addController(app, controllerPath, ControllerClass, params = {}) {
    const controller = new ControllerClass(
      this.context,
      this.apiFacadeService,
      this.responseService,
      params,
    );

    if (controllerPath.match(/\/$/) && controllerPath.length > 1) {
      const escapedPath = `^${controllerPath
        .substring(0, controllerPath.length - 1)
        // eslint-disable-next-line
        .replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')}$`;
      const pathRegEx = new RegExp(escapedPath);
      app.use(pathRegEx, (req, res) => {
        res.redirect(controllerPath);
      });
    }

    app.use(controllerPath, controller.getRoutes());
    return controller;
  }

  defineStatic(app) {
    const router = express.Router({ strict: true });

    const staticOptions = {
      etag: true,
      lastModified: false,
      maxage: onehour,
    };

    // Middleware to serve static assets
    router.use('/', express.static(path.join(__dirname, '../static'), staticOptions));
    router.use(
      '/',
      express.static(
        path.join(__dirname, '../node_modules/govuk-frontend/govuk/assets'),
        staticOptions,
      ),
    );
    router.use(
      '/js/all.js',
      express.static(
        path.join(__dirname, '../node_modules/govuk-frontend/govuk/all.js'),
        staticOptions,
      ),
    );

    // Add variables that are available in all views
    const localsParam = app.locals;
    localsParam.asset_path = '/assets/';

    return router;
  }

  defineErrors(app) {
    // Handle 404
    app.use((req, res) => {
      res.status(404).send('404: Page not Found');
    });

    // Handle 500
    app.use((error, req, res) => {
      res.status(500).send('500: Internal Server Error');
      this.context.sharedServices.logger.error(`Internal Error: ${error.toString()}`);
    });
  }

  createSessionStore(app) {
    if (
      this.context.sharedServices.config.REDIS_PORT &&
      this.context.sharedServices.config.REDIS_HOST
    ) {
      this.createRedisSessionStore(app);
    } else {
      this.createLocalSessionStore(app);
    }
  }

  createRedisSessionStore(app) {
    throw new Error(`Not yet implemented ${app}`);
  }

  createLocalSessionStore(app) {
    fs.ensureDir(this.context.sharedServices.config.sessionPath);

    const fileStoreOptions = {
      path: this.context.sharedServices.config.sessionPath,
      secret: this.context.sharedServices.config.sessionSecret,
      // clean up stale session every 12 hours
      reapInterval: 3600 * 12,
    };

    app.use(
      expressSession({
        store: new FileStore(fileStoreOptions),
        secret: this.context.sharedServices.config.sessionSecret,
        resave: true,
        // cookie: { secure: true },
      }),
    );
  }
}

module.exports = CheckInServer;
