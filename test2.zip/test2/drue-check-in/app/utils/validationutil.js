
const regexEmail = /^[a-z0-9._%'+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i;

class ValidationUtil {
  constructor(config) {
    this.config = config;
    this.localEmailDomain = config.localEmailDomain ? config.localEmailDomain : 'dwp.gov.uk';
    this.localEmailDomainString = `@${this.localEmailDomain.toLowerCase().trim()}`;
    this.validDomainStrings = [this.localEmailDomain];

    if (config.acceptedEmailDomains) {
      this.validDomainStrings = config.acceptedEmailDomains.map(d => `@${d.toLowerCase().trim()}`);
    }
  }

  checkValueInArray(itemToCheck, arrayValues) {
    let itemMatched = false;

    for (const value of arrayValues) {
      if (value === itemToCheck) {
        itemMatched = true;
      }
    }
    return itemMatched;
  }

  cleanEmailString(value) {
    let rv = '';
    if ((typeof value !== 'undefined') && (value !== null)) {
      rv = value.trim().toLowerCase();
    }
    rv = rv.replace(/[‘’]/g, "'");
    return rv;
  }

  addStandardDomainIfNoDomain(value) {
    let rv = this.cleanEmailString(value);
    if (!rv.includes('@')) {
      rv += this.localEmailDomainString;
    }
    return rv;
  }

  extractEmailDomain(value) {
    if ((typeof value === 'undefined') || (value === null)) {
      return '';
    }

    const ampPosition = value.indexOf('@');
    if ((ampPosition < 0) || (ampPosition >= value.length - 1)) {
      return '';
    }

    return value.substring(ampPosition + 1);
  }

  extractEmailName(value) {
    if ((typeof value === 'undefined') || (value === null)) {
      return '';
    }

    const ampPosition = value.indexOf('@');
    if (ampPosition == 0) {
      return '';
    }

    if (ampPosition < 0) {
      return value;
    }

    return value.substring(0, ampPosition);
  }

  removeStandardDomainIfPresent(value) {
    let rv = '';
    if ((typeof value !== 'undefined') && (value !== null)) {
      rv = value.trim().toLowerCase();
    }
    if (rv.endsWith(this.localEmailDomainString)) {
      return rv.substring(0, rv.length - this.localEmailDomainString.length);
    }
    return rv;
  }

  emailValidator(emailAddress, allowLocalEmails = true) {
    const fullEmail = allowLocalEmails ? this.addStandardDomainIfNoDomain(emailAddress)
      : this.cleanEmailString(emailAddress);

    if (!regexEmail.test(fullEmail)) {
      // must be a valid email address
      return '';
    }

    if (this.validDomainStrings.every(s => (!fullEmail.endsWith(s)))) {
      // must be a standard email
      return '';
    }

    return fullEmail;
  }

  emailAndDomainValidator(emailAddress, emailDomain) {
    let rv = this.cleanEmailString(emailAddress);
    if (!rv.includes('@')) {
      rv += `@${emailDomain}`;
    }
    return this.emailValidator(rv, false);
  }
}

module.exports = ValidationUtil;
