const express = require('express');

class CustomerCheckinControllerv1 {
  constructor(context, apiFacadeService, responseService) {
    this.context = context;
    this.apiFacadeService = apiFacadeService;
    this.responseService = responseService;
  }

  getRoutes() {
    const router = express.Router({ strict: true });

    router.get('/failure', this.context.middleware.isAuthenticated, this.context.middleware.noCache, this.onFailure.bind(this));
    router.get('/', this.context.middleware.isAuthenticated, this.context.middleware.noCache, this.onWelcome.bind(this));

    router.get('/journey/:pageId', this.context.middleware.isAuthenticated, this.context.middleware.noCache, this.onJourney.bind(this));
    router.get('/thankyou', this.context.middleware.isAuthenticated, this.context.middleware.noCache, this.onThankyou.bind(this));

    return router;
  }

  onFailure(req, res) {
    this.responseService.render(req, res, 'failure', {});
  }

  onWelcome(req, res) {
    this.responseService.render(req, res, 'check-in-v1/welcome', {});
  }

  onThankyou(req, res) {
    this.responseService.render(req, res, 'check-in-v1/thankyou', {});
  }

  onJourney(req, res) {
    let currentPage = 1;

    if (req.params.pageId) {
      currentPage = Number.parseInt(req.params.pageId, 10);
      if (Number.isNaN(currentPage)) {
        currentPage = 1;
      }
    }

    let view = 'thankyou';
    switch (currentPage) {
    case 1:
      view = 'appt-time.html';
      break;

    case 2:
      view = 'first-name.html';
      break;

    case 3:
      view = 'last-name.html';
      break;

    case 4:
      view = 'month-of-birth.html';
      break;

    case 5:
      view = 'day-of-birth.html';
      break;

    default:
      view = 'thankyou';
      break;
    }

    this.responseService.render(req, res, `check-in-v1/${view}`, {
      currentPage,
      nextPage: currentPage + 1,
    });
  }
}

module.exports = CustomerCheckinControllerv1;
