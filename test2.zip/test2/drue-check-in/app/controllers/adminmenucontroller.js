const express = require('express');
const multer = require('multer');
const moment = require('moment-timezone');
const UploaderModelBuilder = require('../model_builders/uploadermodelbuilder');

class AdminController {
  constructor(context, apiFacadeService, responseService) {
    this.context = context;
    this.apiFacadeService = apiFacadeService;
    this.responseService = responseService;
    this.uploadHandler = multer({ dest: this.context.sharedServices.config.uploadPath });
    this.uploaderModelBuilder = new UploaderModelBuilder(context, this.apiFacadeService);
  }

  getRoutes() {
    const router = express.Router({ strict: true });

    router.get('/', this.context.middleware.isAuthenticated, this.context.middleware.isAdmin, this.context.middleware.noCache, this.onAdminMenu.bind(this));

    router.get('/upload/', this.context.middleware.isAuthenticated, this.context.middleware.isAdmin, this.context.middleware.noCache, this.onApptUpload.bind(this));
    router.post('/upload/', this.context.middleware.isAuthenticated, this.context.middleware.isAdmin, this.context.middleware.noCache, this.uploadHandler.single('qqfile'), this.onApptUploadAction.bind(this));
    router.post('/uploadconfirm/', this.context.middleware.isAuthenticated, this.context.middleware.isAdmin, this.context.middleware.noCache, this.onApptUploadConfirmAction.bind(this));

    return router;
  }

  onAdminMenu(req, res) {
    // this.responseService.setSuccessMessage(req, 'value');
    this.responseService.render(req, res, 'admin/menu', {});
  }

  showApptUpload(req, res, paramModel = {}) {
    // AdminBreadcrumbs.add(req, this.responseService,
    // 'Create and assign multiple users to a plan', '/admin/user/upload/');
    const model = paramModel;
    const now = moment().tz('Europe/London');
    model.today = now.tz('Europe/London');
    model.day = model.today.date();
    model.month = model.today.month() + 1;
    model.year = model.today.year();

    this.responseService.render(req, res, 'admin/apptUpload', model);
  }


  showApptUploadSummary(req, res, model) {
    // AdminBreadcrumbs.add(req, this.resp,
    // 'Create and assign multiple users to a plan', '/admin/user/upload/');
    const viewmodel = {
      dateOfAppointments: model.dateOfAppointmentsString,
      jobCentreName: model.jobCentreName,
      totalUserActions: model.totalUserActions,
      appts: model.appointments.map(a => [
        {
          text: a.source,
        },
        {
          text: a.timeOnly,
        },
        {
          text: `${a.customerFirstName} ${a.customerLastName}`,
        },
        {
          text: `${a.agentFirstName} ${a.agentLastName}`,
        },
      ]),
      locations: model.locations.map(l => [
        {
          text: l.id,
        },
        {
          text: l.title,
        },
        {
          text: l.instruction,
        },
      ]),
      agents: model.agents.map(a => [
        {
          text: `${a.apptAgentFirstName} ${a.apptAgentLastName}`,
        },
        {
          text: `${a.actualAgentFirstName} ${a.actualAgentLastName}`,
        },
        {
          text: a.locationId,
        },
        {
          text: a.instruction,
        },
      ]),
    };


    this.responseService.render(req, res, 'admin/apptUploadSummary', viewmodel);
  }

  onApptUpload(req, res) {
    this.showApptUpload(req, res);
  }

  onApptUploadAction(req, res) {
    let model = {};
    const errMess = this.responseService.makeEmptyMessage();
    let parsedDate = null;

    if (!errMess.isError) {
      const day = this.responseService.getNumericField(req, 'appointment-date-day');
      const month = this.responseService.getNumericField(req, 'appointment-date-month') - 1;
      const year = this.responseService.getNumericField(req, 'appointment-date-year');

      parsedDate = moment({
        year,
        month,
        day,
      });

      if (!parsedDate.isValid()) {
        errMess.addFieldValidationError('appointment-date-day', 'Enter a valid date');
      }
    }


    if ((!errMess.isError) && (!('file' in req))) {
      errMess.addFieldValidationError('file-upload', 'Select a file to upload');
    }

    if (!errMess.isError) {
      model = this.uploaderModelBuilder.buildUploadModel(req.file, parsedDate, errMess);
    }

    if (errMess.isError) {
      this.responseService.addStatusMessage(req, errMess);
      this.showApptUpload(req, res);
    } else {
      this.responseService.storeInUserSession(req, 'userUpload', model);
      errMess.setSuccessMessage('Warning');
      this.responseService.addStatusMessage(req, errMess);
      this.showApptUploadSummary(req, res, model);
    }
  }

  onApptUploadConfirmAction(req, res) {
    const model = this.responseService.retrieveObjectFromUserSession(req, 'userUpload');
    if (model == null) {
      this.responseService.redirectErrorMessage(req, res, '/admin/', 'The uploaded user details were not found');
      return;
    }
    this.responseService.storeInUserSession(req, 'userUpload', '');

    this.uploaderModelBuilder.implementActionsOfUploadModel(model, req.session.accessToken).then(() => {
      this.responseService.redirectSuccessMessage(req, res, '/admin/', 'The Jobcentre appointments have been uploaded');
    }).catch((err) => {
      this.responseService.handleError(req, res, err);
    });
  }
}

module.exports = AdminController;
