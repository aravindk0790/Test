const express = require('express');
const moment = require('moment');
const timezone = require('moment');
const MarkdownIt = require('markdown-it');
const AppointmentsModelBuilder = require('../model_builders/appointmentsmodelbuilder');
const StatusMessage = require('../models/statusmessage');

class CustomerCheckinControllerv6 {
  constructor(context, apiFacadeService, responseService, params) {
    this.variant = params.variant ? params.variant : 'A';
    this.context = context;
    this.apiFacadeService = apiFacadeService;
    this.responseService = responseService;
    this.appointmentsModelBuilder = new AppointmentsModelBuilder(context, this.apiFacadeService);
    this.minsForTooEarly = 30;
    this.estimatedPageDuration = 5000;
  }

  getRoutes() {
    const router = express.Router({ strict: true });

    router.get(
      '/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onWelcome.bind(this),
    );

    router.get(
      '/timed-out/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onTimedOut.bind(this),
    );

    router.get(
      '/what-are-you-here-for/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onWhatAreYouHereFor.bind(this),
    );
    router.get(
      '/use-the-computers/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onUseTheComputers.bind(this),
    );
    router.get(
      '/other-reason/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onOtherReason.bind(this),
    );

    router.get(
      '/question-appt-time/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onQuestionApptTime.bind(this),
    );
    router.get(
      '/question-first-name/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onQuestionFirstName.bind(this),
    );
    router.get(
      '/question-last-name/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onQuestionLastName.bind(this),
    );
    router.get(
      '/final-question/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onQuestionFinal.bind(this),
    );

    router.get(
      '/customer-identified/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onCustomerIdentified.bind(this),
    );

    router.get(
      '/instruction-dont-know-time/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onInstructionDontKnowTime.bind(this),
    );

    router.get(
      '/instruction-checked-in/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onInstructionCheckedIn.bind(this),
    );

    router.get(
      '/instruction-checked-in-too-late/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onInstructionCheckedInTooLate.bind(this),
    );

    router.get(
      '/instruction-checked-in-too-early/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onInstructionCheckedInTooEarly.bind(this),
    );

    router.get(
      '/cannot-id/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.onCustomerNotIdentified.bind(this),
    );

    return router;
  }

  //----------------------------------------------------------------------

  tryAgainUrl() {
    return '../question-appt-time/?tryAgain=true';
  }

  homeUrl() {
    return '../';
  }

  //----------------------------------------------------------------------

  closeUserJourney(req, timedOut) {
    if (req.session) {
      if (req.session.customerSession) {
        // update the journey
        req.session.customerSession.endState = timedOut ? '$' : '.';
        this.addPageToUserJourney(
          req.session.customerSession,
          req.session.customerSession.endState,
          timedOut,
          false,
        );

        // log record user journey
        this.context.sharedServices.logger.info(
          this.userJourneyAsText(req.session.customerSession),
        );

        // destroy the journey data
        delete req.session.customerSession;
      }
    }
  }

  userJourneyAsText(cs) {
    const startTime = moment(cs.startTime);

    // USER-JOURNEY; startTime; lastPage; endState; journeyDuration; journeyPages; journeyPagesDurations; numIdAttempts; earlyDuration; earlyDurationMins;
    return `USER-JOURNEY; ${startTime.format('YYYY-MM-DD h:mma')}; ${cs.lastPage}; ${
      cs.endState
    }; ${cs.journeyDuration}; ${cs.journeyPages.join('')}; ${cs.journeyPagesDurations.join()}; ${
      cs.numIdAttempts
    }; ${cs.earlyDuration} ${cs.earlyDurationMins}`;
  }

  addPageToUserJourney(customerSession, pageCode, useEstimatedPageDuration, updateLastPage) {
    const now = Date.now();

    if (useEstimatedPageDuration) {
      customerSession.journeyDuration += this.estimatedPageDuration;
    } else {
      customerSession.journeyDuration = now - customerSession.startTime;
    }

    customerSession.journeyPagesDurations.push(now - customerSession.lastPageTime);
    customerSession.journeyPages.push(pageCode);
    customerSession.endTime = now;

    if (updateLastPage) {
      customerSession.lastPage = pageCode;
      customerSession.lastPageTime = now;
    }
  }

  addToUserJourney(req, pageCode, isStart = false) {
    if (req.session) {
      if (typeof req.session.customerSession === 'undefined' || isStart) {
        req.session.customerSession = this.createCustomerSession(pageCode);
      } else {
        this.addPageToUserJourney(req.session.customerSession, pageCode, false, true);

        this.context.sharedServices.logger.debug(
          this.userJourneyAsText(req.session.customerSession),
        );
      }
    }

    return pageCode;
  }

  addIdAttemptToUserJourney(req) {
    if (req.session && req.session.customerSession) {
      req.session.customerSession.numIdAttempts += 1;
    }
  }

  calcEarlyDuration(req, timeslot) {
    if (req.session && req.session.customerSession) {
      req.session.customerSession.earlyDuration = Math.round(
        (timeslot - req.session.customerSession.startTime) / 1000,
      );
      req.session.customerSession.earlyDurationMins =
        Math.round(req.session.customerSession.earlyDuration / 6) / 10;
    }
  }

  createCustomerSession(pageCode) {
    const now = Date.now();
    return {
      startTime: now,
      lastPageTime: now,
      endTime: now,
      lastPage: pageCode,
      endState: '_',
      journeyPages: [pageCode],
      journeyDuration: 0,
      journeyPagesDurations: [],
      numIdAttempts: 0,
      earlyDuration: 0,
      earlyDurationMins: 0,
    };
  }

  checkValidCustomerSession(req) {
    if (
      typeof req.session === 'undefined' ||
      typeof req.session.customerSession === 'undefined' ||
      typeof req.session.customerSession.startTime === 'undefined'
    ) {
      return Promise.reject(StatusMessage.createError('Invalid or missing customer session', 500));
    }
    return Promise.resolve();
  }

  //----------------------------------------------------------------------

  handleSelectionFromQuestionApptTime(req) {
    return this.checkValidCustomerSession(req).then(() => {
      const timeslot = req.query.timeslot ? req.query.timeslot.toString() : '';

      if ((timeslot.length === 0 || timeslot.length > 7) && timeslot !== 'dontknow') {
        if (!req.session.customerSession.timeslot) {
          return Promise.reject(StatusMessage.createError('Invalid appt time', 500));
        }
      } else {
        req.session.customerSession.timeslot = timeslot;
      }
      return Promise.resolve(timeslot);
    });
  }

  handleSelectionFromQuestionLetter(req) {
    return this.checkValidCustomerSession(req).then(() => {
      const letter = req.query.letter ? req.query.letter.toString() : '';
      if (letter.length === 0 || letter.length > 1) {
        return Promise.reject(StatusMessage.createError('Invalid letter', 500));
      }
      return Promise.resolve(letter);
    });
  }

  handleSelectionFromQuestionFirstName(req) {
    return this.checkValidCustomerSession(req).then(() =>
      this.handleSelectionFromQuestionLetter(req).then(letter => {
        req.session.customerSession.FirstNameInitial = letter;
        return Promise.resolve(letter);
      }),
    );
  }

  handleSelectionFromQuestionLastName(req) {
    return this.checkValidCustomerSession(req).then(() =>
      this.handleSelectionFromQuestionLetter(req).then(letter => {
        req.session.customerSession.LastNameInitial = letter;
        return Promise.resolve(letter);
      }),
    );
  }

  identifyCustomerFromInput(req) {
    req.session.customerSession.identified = false;

    const timeslot = this.appointmentsModelBuilder.stringToTime(
      req.session.customerSession.timeslot,
    );
    const timeslotString = this.appointmentsModelBuilder.timeToFullString(timeslot);
    const jobCentreId = req.session.userInfo.jobCentreId;

    return this.apiFacadeService
      .get(`/drue/api/appointment/appointments/${timeslotString}/${jobCentreId}`, req.session.accessToken)
      .then(values => {
        const customer = values.find(c => {
          return (
            req.session.customerSession.FirstNameInitial.toUpperCase() ===
              c.customerFirstName.substring(0, 1).toUpperCase() &&
            req.session.customerSession.LastNameInitial.toUpperCase() ===
              c.customerLastName.substring(0, 1).toUpperCase()
          );
        });

        if (customer) {
          req.session.customerSession.identified = true;
          req.session.customerSession.customerFirstName = customer.customerFirstName;
          req.session.customerSession.customerLastName = customer.customerLastName;
          req.session.customerSession.appointmentTime = req.session.customerSession.timeslot;
          req.session.customerSession.appointmentTimeDate = timeslotString;
          req.session.customerSession.instruction = '';
          req.session.customerSession.agentName = '';

          this.calcEarlyDuration(req, timeslot.valueOf());

          if (customer.agent && customer.agent.firstName) {
            req.session.customerSession.agentName = `${
              customer.agent.firstName
            } ${customer.agent.lastName.substring(0, 1).toUpperCase()}.`;
            if (customer.agent.instruction) {
              req.session.customerSession.instruction = customer.agent.instruction;
            } else if (customer.agent.location && customer.agent.location.instruction) {
              req.session.customerSession.instruction = customer.agent.location.instruction;
            }
          }
        }

        return Promise.resolve(req.session.customerSession);
      });
  }

  generateInstruction(model, markDownTemplate) {
    const markdown = new MarkdownIt();
    const html = markdown.render(markDownTemplate);

    return html;
  }

  handleCustomerIdentified(req) {
    return this.checkValidCustomerSession(req).then(() => {
      // look up best instruction

      const model = {
        redirectUrl: null,
      };

      const now = moment();
      this.context.sharedServices.logger.info(`Actual Time now is: ${now}`);
      const apptTime = moment(req.session.customerSession.appointmentTimeDate);
      this.context.sharedServices.logger.info(`Appointment time is: ${apptTime}`);
      const tooLateTime = moment(apptTime);
      tooLateTime.add(1,'m');
      const tooEarlyTime = moment(apptTime);
      this.context.sharedServices.logger.info(`Too Late time: ${tooLateTime}`);
      

      tooEarlyTime.subtract(this.minsForTooEarly, 'm');
      this.context.sharedServices.logger.info(`Too Early time: ${tooEarlyTime}`);

      if (now.isAfter(tooLateTime)) {
        model.redirectUrl = '../instruction-checked-in-too-late/';
      } else if (now.isSameOrBefore(tooEarlyTime)) {
        model.redirectUrl = '../instruction-checked-in-too-early/';
      } else {
        model.redirectUrl = '../instruction-checked-in/';
      }

      return Promise.resolve(model);
    });
  }

  handleCustomerCheckedIn(req) {
    return this.checkValidCustomerSession(req).then(() => {
      // look up best instruction

      const instruction = req.session.customerSession.instruction
        ? req.session.customerSession.instruction
        : 'instruction not found';

      const model = {};

      model.appointmentTime = req.session.customerSession.appointmentTime;
      model.appointmentWith = req.session.customerSession.agentName;

      model.instructionHtml = this.generateInstruction(model, instruction);

      return Promise.resolve(model);
    });
  }

  //----------------------------------------------------------------------

  onWelcome(req, res) {
    this.closeUserJourney(req, false);
    this.responseService.redirect(req, res, './what-are-you-here-for/');

    /*
    const view = 'check-in-v6/welcome';
    const model = {
      nextPage: './what-are-you-here-for/',
      bodyClasses: 'welcomeBody',
      htmlClasses: 'welcomeHtml',
    };

    this.responseService.render(req, res, view, model);
  */
  }

  onTimedOut(req, res) {
    this.closeUserJourney(req, true);
    this.responseService.redirect(req, res, '../what-are-you-here-for/');
  }

  onWhatAreYouHereFor(req, res) {
    this.addToUserJourney(req, 'w', true);
    const view = 'check-in-v6/what-are-you-here-for';
    const model = {
      option1: '../question-appt-time/',
      option2: '../use-the-computers/',
      option3: '../other-reason/',
      bodyClasses: 'startScreen',
    };

    this.responseService.render(req, res, view, model);
  }

  onUseTheComputers(req, res) {
    this.addToUserJourney(req, 'm', true);
    const view = 'check-in-v6/use-the-computers';
    const model = {
      nextPage: this.homeUrl(),
    };

    this.responseService.render(req, res, view, model);
  }

  onOtherReason(req, res) {
    this.addToUserJourney(req, 'o', true);
    const view = 'check-in-v6/other-reason';
    const model = {
      nextPage: this.homeUrl(),
    };

    this.responseService.render(req, res, view, model);
  }

  // Questions
  onQuestionApptTime(req, res) {
    let tryAgain = req.query.tryAgain ? req.query.tryAgain === 'true' : false;

    const view = 'check-in-v6/question-appt-time.html';
    const nextAppts = req.query.nextappts ? req.query.nextappts : '';
    const prevAppts = req.query.prevappts ? req.query.prevappts : '';

    const changeApptTime = nextAppts !== '' && prevAppts !== '';

    const startOfJourney = !tryAgain && !changeApptTime;

    this.addToUserJourney(req, 'T', startOfJourney);

    if (tryAgain) {
      this.addIdAttemptToUserJourney(req);
    }

    this.appointmentsModelBuilder
      .buildAppointmentSlots(
        req.session.userInfo.jobCentreId,
        req.session.accessToken,
        nextAppts,
        prevAppts,
      )
      .then(appts => {
        const model = {
          appts,
          nextPage: '../question-first-name/',
          startAgainUrl: this.homeUrl(),
          backLinkUrl: this.homeUrl(),
        };
        this.responseService.render(req, res, view, model);
      })
      .catch(err => {
        this.responseService.handleError(req, res, err);
      });
  }

  onQuestionFirstName(req, res) {
    this.handleSelectionFromQuestionApptTime(req)
      .then(timeslot => {
        if (timeslot === 'dontknow') {
          this.responseService.redirect(req, res, '../instruction-dont-know-time/');
        } else {
          this.addToUserJourney(req, 'F');
          const view = 'check-in-v6/question-first-name.html';
          const model = {
            nextPage: '../question-last-name/',
            startAgainUrl: this.homeUrl(),
            backLinkUrl: this.tryAgainUrl(),
          };
          this.responseService.render(req, res, view, model);
        }
      })
      .catch(err => {
        this.responseService.handleError(req, res, err, {
          homeUrl: this.homeUrl(),
        });
      });
  }

  onQuestionLastName(req, res) {
    this.addToUserJourney(req, 'L');
    this.handleSelectionFromQuestionFirstName(req)
      .then(() => {
        const view = 'check-in-v6/question-last-name.html';
        const model = {
          nextPage: '../final-question/',
          startAgainUrl: this.homeUrl(),
          backLinkUrl: '../question-first-name/',
        };
        this.responseService.render(req, res, view, model);
      })
      .catch(err => {
        this.responseService.handleError(req, res, err, {
          homeUrl: this.homeUrl(),
        });
      });
  }

  onQuestionFinal(req, res) {
    this.handleSelectionFromQuestionLastName(req)
      .then(() => this.identifyCustomerFromInput(req))
      .then(model => {
        if (model.identified) {
          this.addToUserJourney(req, 'C');
          model.tryAgainPage = this.tryAgainUrl();
          model.checkedInPage = '../customer-identified/';
          const view = 'check-in-v6/confirm-id';
          this.responseService.render(req, res, view, model);
        } else {
          this.responseService.redirect(req, res, '../cannot-id/');
        }
      })
      .catch(err => {
        this.responseService.handleError(req, res, err, {
          homeUrl: this.homeUrl(),
        });
      });
  }

  onCustomerNotIdentified(req, res) {
    this.addToUserJourney(req, 'X');
    const view = 'check-in-v6/cannot-id';
    const model = {
      firstNameInitial: req.session.customerSession.FirstNameInitial
        ? req.session.customerSession.FirstNameInitial.toUpperCase()
        : '_',
      lastNameInitial: req.session.customerSession.LastNameInitial
        ? req.session.customerSession.LastNameInitial.toUpperCase()
        : '_',
      timeslot: req.session.customerSession.timeslot || '_',
      tryAgainPage: this.tryAgainUrl(),
      homeUrl: this.homeUrl(),
    };

    this.responseService.render(req, res, view, model);
  }

  onCustomerIdentified(req, res) {
    this.handleCustomerIdentified(req)
      .then(model => {
        this.responseService.redirect(req, res, model.redirectUrl);
      })
      .catch(err => {
        this.responseService.handleError(req, res, err, {
          homeUrl: this.homeUrl(),
        });
      });
  }

  onInstructionCheckedIn(req, res) {
    this.addToUserJourney(req, 'I');
    this.handleCustomerCheckedIn(req)
      .then(model => {
        const view = 'check-in-v6/instruction-checked-in';
        model.nextPage = this.homeUrl();
        this.responseService.render(req, res, view, model);
      })
      .catch(err => {
        this.responseService.handleError(req, res, err, {
          homeUrl: this.homeUrl(),
        });
      });
  }

  onInstructionCheckedInTooEarly(req, res) {
    this.addToUserJourney(req, 'E');
    this.handleCustomerCheckedIn(req)
      .then(model => {
        const view = 'check-in-v6/instruction-checked-in-too-early';
        model.nextPage = this.homeUrl();
        this.responseService.render(req, res, view, model);
      })
      .catch(err => {
        this.responseService.handleError(req, res, err, {
          homeUrl: this.homeUrl(),
        });
      });
  }

  onInstructionCheckedInTooLate(req, res) {
    this.addToUserJourney(req, 'A');
    const view = 'check-in-v6/instruction-checked-in-too-late';
    const model = {
      nextPage: this.homeUrl(),
    };

    this.responseService.render(req, res, view, model);
  }

  onInstructionDontKnowTime(req, res) {
    this.addToUserJourney(req, 'D');
    const view = 'check-in-v6/instruction-dont-know-time';
    const model = {
      nextPage: this.homeUrl(),
    };

    this.responseService.render(req, res, view, model);
  }
}
module.exports = CustomerCheckinControllerv6;
