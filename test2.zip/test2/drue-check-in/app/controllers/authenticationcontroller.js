const express = require('express');
const uuidv5 = require('uuid/v5');

class AuthenticationController {
  constructor(context, apiFacadeService, responseService) {
    this.context = context;
    this.apiFacadeService = apiFacadeService;
    this.responseService = responseService;

    this.adminUserName = context.sharedServices.config.adminUserName;
    this.adminUserPassword = context.sharedServices.config.adminUserPassword;

    this.checkinUserName = context.sharedServices.config.checkinUserName;
    this.checkinUserPassword = context.sharedServices.config.checkinUserPassword;
  }

  getRoutes() {
    const router = express.Router({ strict: true });

    router.get('/', this.context.middleware.noCache, this.onSignin.bind(this));
    router.post('/', this.context.middleware.noCache, this.onSigninAction.bind(this));

    router.get(
      '/selectjobcentre/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.selectJobCentre.bind(this),
    );

    router.post(
      '/selectjobcentre/',
      this.context.middleware.isAuthenticated,
      this.context.middleware.noCache,
      this.selectJobCentreAction.bind(this),
    );

    return router;
  }

  onSignin(req, res) {
    this.context.authenticationService.removeAccessToken(req);
    this.responseService.render(req, res, 'authentication/signin', {});
  }

  callLogin(email, password) {
    const signInDetails = {
      accessToken: uuidv5('alpha.drue-wa-digital.uk', uuidv5.DNS),
      userInfo: {
        email,
        isAdmin: false,
        jobCentreId: 0,
      },
    };

    if (email === this.adminUserName && password === this.adminUserPassword) {
      signInDetails.userInfo.isAdmin = true;
      return Promise.resolve(signInDetails);
    }

    if (email === this.checkinUserName && password === this.checkinUserPassword) {
      signInDetails.userInfo.isAdmin = false;
      return Promise.resolve(signInDetails);
    }

    return Promise.reject(new Error('Cannot find user'));
  }

  onSigninAction(req, res) {
    this.context.authenticationService.removeAccessToken(req);

    const model = {
      email: req.body.email ? req.body.email.toString().toLowerCase() : '',
      password: req.body.password ? req.body.password : '',
    };

    let userIsAdmin = false;
    this.context.sharedServices.logger.debug('User login callLogin: ' + model.email);
    this.callLogin(model.email, model.password)
      .then(value => {
        this.context.sharedServices.logger.debug('User login save_access_token: ' + model.email);
        userIsAdmin = value.userInfo.isAdmin;
        return this.context.authenticationService.saveAccessToken(
          req,
          value.accessToken,
          value.userInfo,
        );
      })
      .then(() => {
        this.context.sharedServices.logger.debug('User login callLogin: ' + model.email);
        //        this.responseService.redirect(req, res, userIsAdmin ? this.adminHomeUrl : this.checkinHomeUrl);
        this.responseService.redirect(
          req,
          res,
          userIsAdmin ? this.adminHomeUrl : '/selectjobcentre/',
        );
        //          this.responseService.redirect(req, res, '/selectjobcentre/');
      })
      .catch(err => {
        err.statusCode = 401;
        this.responseService.handleError(
          req,
          res,
          err,
          {
            s401: {
              message: 'The email address or password is incorrect. ',
              errorLinkUrl: '/',
            },
          },
          model,
        );
      });
  }

  selectJobCentre(req, res) {
    this.apiFacadeService
      .get('/drue/api/jobcentre/all', req.session.accessToken)
      .then(values => {
        const model = {
          jobCentres: values.map(v => {
            return {
              value: v.id,
              text: v.name,
            };
          }),
        };
        this.responseService.render(req, res, 'authentication/selectjobcentre', model);
      })
      .catch(err => {
        this.responseService.handleError(req, res, err);
      });

    //    curl -X GET "http://localhost:3100/drue/api/jobcentre/all" -H "accept: */*"
  }

  selectJobCentreAction(req, res) {
    const jobCentreId =
      req.body.jobcentres && req.body.jobcentres !== '' ? parseInt(req.body.jobcentres) : 0;

    if (Number.isNaN(jobCentreId) || jobCentreId <= 0) {
      this.responseService.redirectErrorMessage(
        req,
        res,
        '/selectjobcentre/',
        'A jobcentre must be selected',
      );
    } else {
      req.session.userInfo.jobCentreId = jobCentreId;
      this.responseService.redirect(req, res, this.checkinHomeUrl);
    }
  }
}

module.exports = AuthenticationController;
