const express = require('express');
const SimpleAppointmentsModelBuilder = require('../model_builders/simpleappointmentsmodelbuilder');

class CustomerCheckinControllerv1 {
  constructor(context, apiFacadeService, responseService, params) {
    this.variant = params.variant ? params.variant : 'A';
    this.context = context;
    this.apiFacadeService = apiFacadeService;
    this.responseService = responseService;
    this.appointmentsModelBuilder = new SimpleAppointmentsModelBuilder(context, this.variant);
  }

  getRoutes() {
    const router = express.Router({ strict: true });

    router.get('/', this.context.middleware.isAuthenticated, this.context.middleware.noCache, this.onWelcome.bind(this));
    router.get('/question-appt-time/', this.context.middleware.isAuthenticated, this.context.middleware.noCache, this.onQuestionApptTime.bind(this));
    router.get('/question-first-name/', this.context.middleware.isAuthenticated, this.context.middleware.noCache, this.onQuestionFirstName.bind(this));
    router.get('/question-last-name/', this.context.middleware.isAuthenticated, this.context.middleware.noCache, this.onQuestionLastName.bind(this));
    router.get('/question-month-of-birth/', this.context.middleware.isAuthenticated, this.context.middleware.noCache, this.onQuestionMonthOfBirth.bind(this));
    router.get('/question-day-of-birth/', this.context.middleware.isAuthenticated, this.context.middleware.noCache, this.onQuestionDayOfBirth.bind(this));
    router.get('/instruction-checked-in/', this.context.middleware.isAuthenticated, this.context.middleware.noCache, this.onInstructionCheckedIn.bind(this));

    return router;
  }

  onWelcome(req, res) {
    const view = 'check-in-v3/welcome';
    const model = {
      nextPage: './question-appt-time/',
      appts: this.appointmentsModelBuilder.build(),
    };
    this.responseService.render(req, res, view, model);
  }

  onInstructionCheckedIn(req, res) {
    const view = 'check-in-v3/instruction-checked-in';
    const model = {
      nextPage: '../',
      isVariantA: this.variant === 'A',
      isVariantB: this.variant === 'B',
      isVariantC: this.variant === 'C',
      isVariantD: this.variant === 'D',
      isVariantE: this.variant === 'E',
    };
    this.responseService.render(req, res, view, model);
  }

  // Questions
  onQuestionApptTime(req, res) {
    const view = 'check-in-v3/question-appt-time.html';

    const nextAppts = req.query.nextappts ? req.query.nextappts : '';
    const prevAppts = req.query.prevappts ? req.query.prevappts : '';

    const model = {
      nextPage: '../question-first-name/',
      appts: this.appointmentsModelBuilder.build(nextAppts, prevAppts),
    };

    this.responseService.render(req, res, view, model);
  }

  onQuestionFirstName(req, res) {
    const view = 'check-in-v3/question-first-name.html';
    const model = {
      nextPage: '../question-last-name/',
      appts: this.appointmentsModelBuilder.build(),
    };
    this.responseService.render(req, res, view, model);
  }

  onQuestionLastName(req, res) {
    const view = 'check-in-v3/question-last-name.html';
    const model = {
      nextPage: '../question-month-of-birth/',
      appts: this.appointmentsModelBuilder.build(),
    };
    this.responseService.render(req, res, view, model);
  }

  onQuestionMonthOfBirth(req, res) {
    const view = 'check-in-v3/question-month-of-birth.html';
    const model = {
      nextPage: '../question-day-of-birth/',
      appts: this.appointmentsModelBuilder.build(),
    };
    this.responseService.render(req, res, view, model);
  }

  onQuestionDayOfBirth(req, res) {
    const view = 'check-in-v3/question-day-of-birth.html';
    const model = {
      nextPage: '../instruction-checked-in/',
      appts: this.appointmentsModelBuilder.build(),
    };
    this.responseService.render(req, res, view, model);
  }
}

module.exports = CustomerCheckinControllerv1;
