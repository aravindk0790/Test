const gulp = require('gulp');
const npath = require('path');
const sass = require('gulp-sass');

const srcdir = './src/';
const dstdir = './static/';

/* ---------------------------------------------------------------------- CSS */

// Build application.css
gulp.task('sass', () => gulp
  .src(npath.resolve(srcdir, 'css/application*.scss'))
  .pipe(
    sass({
      errLogToConsole: true,
      outputStyle: 'compressed',
      includePaths: ['node_modules/govuk-frontend/govuk'],
    }).on('error', sass.logError),
  )
  .pipe(gulp.dest(npath.resolve(dstdir, 'css/'))));

/* ----------------------------------------------------------------------- images */

gulp.task('copy-img-assets', () => gulp.src(npath.resolve(srcdir, 'img/*')).pipe(gulp.dest(npath.resolve(dstdir, 'img/'))));

/* ----------------------------------------------------------------------- js */

gulp.task('copy-js', () => gulp.src(npath.resolve('node_modules/jquery/dist', 'jquery.js')).pipe(gulp.dest(npath.resolve(dstdir, 'js/'))));

gulp.task('copy-local-js', () => gulp.src(npath.resolve(srcdir, 'js/*')).pipe(gulp.dest(npath.resolve(dstdir, 'js/'))));

/* -------------------------------------------------------------------- Tasks */

gulp.task('default', gulp.series('sass', 'copy-img-assets', 'copy-js', 'copy-local-js'));
