#!/bin/ash
set -e

# Script just takes the base64 encoded and gzipped scripts from chamber and writes the files as node expects
# More detail is available in the node configuration app/node.js

readfromchamber() {
sleep 2
chamber -r 1 read ${ENV}_${SERVICE_NAME} ${1}_pem |awk 'NR==2 { FS="[ \t+]"; print($2); }' |base64 -d |gunzip > ${1}.pem
}

if [ "$ENV_ENABLE_CHAMBER" = "1" ]; then
  echo "Starting chamber"
  readfromchamber server_cert
  readfromchamber server_key
  readfromchamber client_cabundle

  export SESSION_SECRET=`chamber -r 1 read ${ENV}_${SERVICE_NAME} elc_session_secret |awk 'NR==2 { FS="[ \t+]"; print($2); }'`


  export DATA_API_DOMAIN=`chamber -r 1 read ${ENV}_${SERVICE_NAME} data_api_domain |awk 'NR==2 { FS="[ \t+]"; print($2); }'`
  
  export DATA_API_PORT=`chamber -r 1 read ${ENV}_${SERVICE_NAME} data_api_port |awk 'NR==2 { FS="[ \t+]"; print($2); }'`

  export ADMIN_USER_NAME=`chamber -r 1 read ${ENV}_${SERVICE_NAME} admin_user_name |awk 'NR==2 { FS="[ \t+]"; print($2); }'`
  export ADMIN_USER_PASSWORD=`chamber -r 1 read ${ENV}_${SERVICE_NAME} admin_user_password |awk 'NR==2 { FS="[ \t+]"; print($2); }'`

  export CHECKIN_USER_NAME=`chamber -r 1 read ${ENV}_${SERVICE_NAME} checkin_user_name |awk 'NR==2 { FS="[ \t+]"; print($2); }'`
  export CHECKIN_USER_PASSWORD=`chamber -r 1 read ${ENV}_${SERVICE_NAME} checkin_user_password |awk 'NR==2 { FS="[ \t+]"; print($2); }'`

  export CACHE_SALT=`chamber -r 1 read ${ENV}_${SERVICE_NAME} cache_salt |awk 'NR==2 { FS="[ \t+]"; print($2); }'`
  export SESSION_SECRET=`chamber -r 1 read ${ENV}_${SERVICE_NAME} session_secret |awk 'NR==2 { FS="[ \t+]"; print($2); }'`
  export HEALTH_CHECK_SECRET=`chamber -r 1 read ${ENV}_${SERVICE_NAME} session_secret |awk 'NR==2 { FS="[ \t+]"; print($2); }'`

  export PORT=`chamber -r 1 read ${ENV}_${SERVICE_NAME} port |awk 'NR==2 { FS="[ \t+]"; print($2); }'`
  export PORT_HEALTH=`chamber -r 1 read ${ENV}_${SERVICE_NAME} portHealth |awk 'NR==2 { FS="[ \t+]"; print($2); }'`

  echo "DATA_API_DOMAIN $DATA_API_DOMAIN"
  echo "DATA_API_PORT $DATA_API_PORT"
  echo "CHECKIN_USER_NAME $CHECKIN_USER_NAME"



fi


echo "Starting drue-check-in"

exec $@

# tail -f /dev/null

