module.exports = {
  "extends": ["@dwp/eslint-config-base"],
  "parserOptions": {
      "ecmaVersion": 2017
    },
    "env" : {
      "node": true,
      "mocha": true,
      "es6": true
  },
  "rules": {
    "class-methods-use-this": "off",
    "max-len": ["error", 220, 2, {
            ignoreUrls: true,
            ignoreComments: false,
            ignoreRegExpLiterals: true,
            ignoreStrings: false,
            ignoreTemplateLiterals: false,
            }],  }  
}
