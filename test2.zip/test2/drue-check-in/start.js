const Application = require('./app/application');

const application = new Application();
application.startUp();
