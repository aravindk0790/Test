# drue-check-in

nodejs based front-end web server for the drue alpha system


## Config settings

Set the following evironment variables to control the configurtation of the service.

### PORT
The web site
default: 3000

### PORT_HEALTH
Health check http service. Also does metrics and version info
default: 4000

### CACHE_SALT
default: 'CHANGE-ME'

### SESSION_SECRET
default: 'CHANGE-ME'

### NODE_ENV
default: production
set to 'development' for dev mode.

### CERTIFICATE_PATH
default: '.'

### SERVER_KEY
default: 'server_key.pem'

### SERVER_CERTIFICATE
default: 'server_cert.pem'

### SERVER_CA_BUNDLE
default: ''

### CLIENT_CA_BUNDLE
default: 'client_cabundle.pem'

### DATA_API_DOMAIN
default: 'localhost'

### DATA_API_PORT
default: 3100

### DATA_API_PROTOCOL 
default: 'https'

### ADMIN_USER_NAME
default: 'admin@dwp.gov.uk'

### ADMIN_USER_PASSWORD
default: 'changethis1066'

### CHECKIN_USER_NAME
default: 'checkin@dwp.gov.uk'

### CHECKIN_USER_PASSWORD
default: 'notsecure1970'



## Health Information

The following urls are provided on the health port

http://localhost:4200/healthz
Health check, used to auto scaling groups and load balancers

http://localhost:4200/infoz
Useful for devops to determine which version of the service is running

http://localhost:4200/metricsz
Metrics in Prometheus format


