--
-- PostgreSQL database dump
--

-- Dumped from database version 10.9 (Debian 10.9-1.pgdg90+1)
-- Dumped by pg_dump version 10.9 (Debian 10.9-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: agent; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.agent (
    id bigint NOT NULL,
    first_name character varying(100) NOT NULL,
    instruction character varying(255),
    last_name character varying(100) NOT NULL,
    job_centre_id bigint,
    location_id bigint
);


ALTER TABLE public.agent OWNER TO drue;

--
-- Name: agent_appointments; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.agent_appointments (
    agent_id bigint NOT NULL,
    appointments_id bigint NOT NULL
);


ALTER TABLE public.agent_appointments OWNER TO drue;

--
-- Name: agent_id_seq; Type: SEQUENCE; Schema: public; Owner: drue
--

CREATE SEQUENCE public.agent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agent_id_seq OWNER TO drue;

--
-- Name: agent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drue
--

ALTER SEQUENCE public.agent_id_seq OWNED BY public.agent.id;


--
-- Name: agent_instruction; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.agent_instruction (
    agent_id bigint NOT NULL,
    instruction_id bigint NOT NULL
);


ALTER TABLE public.agent_instruction OWNER TO drue;

--
-- Name: agent_instructions; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.agent_instructions (
    agent_id bigint NOT NULL,
    instructions_id bigint NOT NULL
);


ALTER TABLE public.agent_instructions OWNER TO drue;

--
-- Name: appointment; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.appointment (
    id bigint NOT NULL,
    customer_first_name character varying(255),
    customer_last_name character varying(255),
    "time" timestamp without time zone,
    agent_id bigint,
    job_centre_id bigint
);


ALTER TABLE public.appointment OWNER TO drue;

--
-- Name: appointment_id_seq; Type: SEQUENCE; Schema: public; Owner: drue
--

CREATE SEQUENCE public.appointment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.appointment_id_seq OWNER TO drue;

--
-- Name: appointment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drue
--

ALTER SEQUENCE public.appointment_id_seq OWNED BY public.appointment.id;


--
-- Name: instruction; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.instruction (
    id bigint NOT NULL,
    instruction_text character varying(255) NOT NULL,
    location_id bigint
);


ALTER TABLE public.instruction OWNER TO drue;

--
-- Name: instruction_id_seq; Type: SEQUENCE; Schema: public; Owner: drue
--

CREATE SEQUENCE public.instruction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.instruction_id_seq OWNER TO drue;

--
-- Name: instruction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drue
--

ALTER SEQUENCE public.instruction_id_seq OWNED BY public.instruction.id;


--
-- Name: job_centre; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.job_centre (
    id bigint NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.job_centre OWNER TO drue;

--
-- Name: job_centre_agent; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.job_centre_agent (
    job_centre_id bigint NOT NULL,
    agent_id bigint NOT NULL
);


ALTER TABLE public.job_centre_agent OWNER TO drue;

--
-- Name: job_centre_id_seq; Type: SEQUENCE; Schema: public; Owner: drue
--

CREATE SEQUENCE public.job_centre_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.job_centre_id_seq OWNER TO drue;

--
-- Name: job_centre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drue
--

ALTER SEQUENCE public.job_centre_id_seq OWNED BY public.job_centre.id;


--
-- Name: job_centre_location; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.job_centre_location (
    job_centre_id bigint NOT NULL,
    location_id bigint NOT NULL
);


ALTER TABLE public.job_centre_location OWNER TO drue;

--
-- Name: location; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.location (
    id bigint NOT NULL,
    code character varying(255),
    instruction character varying(255),
    title character varying(255),
    job_centre_id bigint
);


ALTER TABLE public.location OWNER TO drue;

--
-- Name: location_id_seq; Type: SEQUENCE; Schema: public; Owner: drue
--

CREATE SEQUENCE public.location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.location_id_seq OWNER TO drue;

--
-- Name: location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drue
--

ALTER SEQUENCE public.location_id_seq OWNED BY public.location.id;


--
-- Name: location_instruction; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.location_instruction (
    location_id bigint NOT NULL,
    instruction_id bigint NOT NULL
);


ALTER TABLE public.location_instruction OWNER TO drue;

--
-- Name: source_system; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.source_system (
    id bigint NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.source_system OWNER TO drue;

--
-- Name: source_system_appointments; Type: TABLE; Schema: public; Owner: drue
--

CREATE TABLE public.source_system_appointments (
    source_system_id bigint NOT NULL,
    appointments_id bigint NOT NULL
);


ALTER TABLE public.source_system_appointments OWNER TO drue;

--
-- Name: source_system_id_seq; Type: SEQUENCE; Schema: public; Owner: drue
--

CREATE SEQUENCE public.source_system_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.source_system_id_seq OWNER TO drue;

--
-- Name: source_system_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drue
--

ALTER SEQUENCE public.source_system_id_seq OWNED BY public.source_system.id;


--
-- Name: agent id; Type: DEFAULT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.agent ALTER COLUMN id SET DEFAULT nextval('public.agent_id_seq'::regclass);


--
-- Name: appointment id; Type: DEFAULT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.appointment ALTER COLUMN id SET DEFAULT nextval('public.appointment_id_seq'::regclass);


--
-- Name: instruction id; Type: DEFAULT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.instruction ALTER COLUMN id SET DEFAULT nextval('public.instruction_id_seq'::regclass);


--
-- Name: job_centre id; Type: DEFAULT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.job_centre ALTER COLUMN id SET DEFAULT nextval('public.job_centre_id_seq'::regclass);


--
-- Name: location id; Type: DEFAULT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.location ALTER COLUMN id SET DEFAULT nextval('public.location_id_seq'::regclass);


--
-- Name: source_system id; Type: DEFAULT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.source_system ALTER COLUMN id SET DEFAULT nextval('public.source_system_id_seq'::regclass);


--
-- Name: agent agent_pkey; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.agent
    ADD CONSTRAINT agent_pkey PRIMARY KEY (id);


--
-- Name: appointment appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_pkey PRIMARY KEY (id);


--
-- Name: instruction instruction_pkey; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.instruction
    ADD CONSTRAINT instruction_pkey PRIMARY KEY (id);


--
-- Name: job_centre job_centre_pkey; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.job_centre
    ADD CONSTRAINT job_centre_pkey PRIMARY KEY (id);


--
-- Name: location location_pkey; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.location
    ADD CONSTRAINT location_pkey PRIMARY KEY (id);


--
-- Name: source_system source_system_pkey; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.source_system
    ADD CONSTRAINT source_system_pkey PRIMARY KEY (id);


--
-- Name: source_system_appointments uk_2mwau5tef03dy1jrp3nwuadnx; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.source_system_appointments
    ADD CONSTRAINT uk_2mwau5tef03dy1jrp3nwuadnx UNIQUE (appointments_id);


--
-- Name: job_centre_location uk_3ms33tgmqr0pbh1606g1dmgbh; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.job_centre_location
    ADD CONSTRAINT uk_3ms33tgmqr0pbh1606g1dmgbh UNIQUE (location_id);


--
-- Name: location_instruction uk_94yjoclrm9w4lh9yi3lvx71cg; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.location_instruction
    ADD CONSTRAINT uk_94yjoclrm9w4lh9yi3lvx71cg UNIQUE (instruction_id);


--
-- Name: job_centre_agent uk_ffsrsh7irbjn3u4jv0jgm8ne2; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.job_centre_agent
    ADD CONSTRAINT uk_ffsrsh7irbjn3u4jv0jgm8ne2 UNIQUE (agent_id);


--
-- Name: agent_instruction uk_jr5s0pwhmhum7mtfqs6obtihc; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.agent_instruction
    ADD CONSTRAINT uk_jr5s0pwhmhum7mtfqs6obtihc UNIQUE (instruction_id);


--
-- Name: agent_instructions uk_k1ajwcftuea042wg0a9t5i7ej; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.agent_instructions
    ADD CONSTRAINT uk_k1ajwcftuea042wg0a9t5i7ej UNIQUE (instructions_id);


--
-- Name: agent_appointments uk_qndnpb4k8my6r2vitt0c5qwgn; Type: CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.agent_appointments
    ADD CONSTRAINT uk_qndnpb4k8my6r2vitt0c5qwgn UNIQUE (appointments_id);


--
-- Name: agent fk5639h4rm7dg5iivxokesw5v6a; Type: FK CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.agent
    ADD CONSTRAINT fk5639h4rm7dg5iivxokesw5v6a FOREIGN KEY (location_id) REFERENCES public.location(id);


--
-- Name: instruction fk5ya3c0w3rkcnstchnsdecmoue; Type: FK CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.instruction
    ADD CONSTRAINT fk5ya3c0w3rkcnstchnsdecmoue FOREIGN KEY (location_id) REFERENCES public.location(id);


--
-- Name: appointment fkf6busdeg67bte6awqqlglkrjd; Type: FK CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT fkf6busdeg67bte6awqqlglkrjd FOREIGN KEY (job_centre_id) REFERENCES public.job_centre(id);


--
-- Name: source_system_appointments fkiae3i4g3xcloyrpi4v31mahcg; Type: FK CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.source_system_appointments
    ADD CONSTRAINT fkiae3i4g3xcloyrpi4v31mahcg FOREIGN KEY (source_system_id) REFERENCES public.source_system(id);


--
-- Name: location fkj0w15j6g8chfgwb22c6oxpeju; Type: FK CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.location
    ADD CONSTRAINT fkj0w15j6g8chfgwb22c6oxpeju FOREIGN KEY (job_centre_id) REFERENCES public.job_centre(id);


--
-- Name: source_system_appointments fkk9r12e1298y1vcoyq9lpp8swf; Type: FK CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.source_system_appointments
    ADD CONSTRAINT fkk9r12e1298y1vcoyq9lpp8swf FOREIGN KEY (appointments_id) REFERENCES public.appointment(id);


--
-- Name: agent fkomec7sdhv0x0fog5o9dfhl866; Type: FK CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.agent
    ADD CONSTRAINT fkomec7sdhv0x0fog5o9dfhl866 FOREIGN KEY (job_centre_id) REFERENCES public.job_centre(id);


--
-- Name: appointment fkt8h5q7sd2gw3axnsv2burb920; Type: FK CONSTRAINT; Schema: public; Owner: drue
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT fkt8h5q7sd2gw3axnsv2burb920 FOREIGN KEY (agent_id) REFERENCES public.agent(id);


--
-- PostgreSQL database dump complete
--

