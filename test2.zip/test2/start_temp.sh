#a temp way to start database and api

docker-compose up -d

cd drue-api

mvn -Dspring.profiles.active=dev spring-boot:run
