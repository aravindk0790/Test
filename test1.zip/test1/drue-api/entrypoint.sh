#!/bin/ash
set -e

# Creates a keystore.jks file from the keys and certificates in chamber.
# Installs a trusted root to the cacerts file assuming that the file is
# in the location expected and that the password for that file is changeit
# this is true for the default install of OpenJDK and Oracle JDK.
# IMPORTANT  : Relies on keytool from OpenJDK
#              and openssl command line utility

echo $ENV_ENABLE_CHAMBER

sleep 5

if [[ "X$LOCAL_DEV" == "Xtrue" ]] ; then
	exec $@
fi



if [ "$ENV_ENABLE_CHAMBER" = "1" ]; then
    readfromchamber() {
        chamber -r 1 read ${ENV}_${SERVICE_NAME} ${1}_pem |awk 'NR==2 { FS="[ \t+]"; print($2); }' |base64 -d |gunzip > ${1}.pem
    }


    readfromchamber server_cert
    readfromchamber server_key
    readfromchamber client_cabundle

    [[ -f keystore.p12 ]] && rm keystore.p12
    KEYSTORE_PASSWORD=`head -c 12 /dev/urandom |base64 |awk -F= -v OFS='=' '{ gsub("[^a-zA-Z0-9]", "", $1); } 1'`

    openssl pkcs12 -export -in server_cert.pem -inkey server_key.pem -name ${SERVICE_NAME} -caname root -password pass:${KEYSTORE_PASSWORD} -out keystore.p12

    chmod +w ${JAVA_HOME}/jre/lib/security/cacerts
    keytool -import -noprompt -file client_cabundle.pem -alias druerootca1 -keystore ${JAVA_HOME}/jre/lib/security/cacerts -storepass changeit
    chmod -w ${JAVA_HOME}/jre/lib/security/cacerts


    rm server_cert.pem server_key.pem client_cabundle.pem
    export JAVA_KEYSTORE_PATH=keystore.p12
    export JAVA_KEYSTORE_PASSWORD=${KEYSTORE_PASSWORD}
    export JAVA_KEYSTORE_ALIAS=${SERVICE_NAME}


fi

exec $@
