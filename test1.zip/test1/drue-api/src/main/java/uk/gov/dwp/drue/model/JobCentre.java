package uk.gov.dwp.drue.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.Cascade;
import org.hibernate.persister.walking.spi.EntityIdentifierDefinition;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import java.util.List;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
@Data
@NoArgsConstructor
public class JobCentre {

    @Id
    @GeneratedValue(strategy = IDENTITY)
    private Long id;
    @NotNull
    @NotBlank
    @Column(length = 100)
    private String name;

    @OneToMany( mappedBy = "jobCentre", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Agent> agents;


    @OneToMany(mappedBy = "jobCentre", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Location> locations;

    @OneToMany(mappedBy = "jobCentre", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Appointment> appointments;


    public JobCentre(@NotNull @NotBlank String name) {
        this.name = name;
    }
}