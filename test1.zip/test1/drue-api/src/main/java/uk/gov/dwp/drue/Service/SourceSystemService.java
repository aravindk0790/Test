package uk.gov.dwp.drue.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.gov.dwp.drue.model.SourceSystem;
import uk.gov.dwp.drue.repository.SourceSystemRepository;

@Service
public class SourceSystemService {

    private final SourceSystemRepository sourceSystemRepository;
    @Autowired
    public SourceSystemService(SourceSystemRepository sourceSystemRepository){
        this.sourceSystemRepository = sourceSystemRepository;
    }

    public void createSourceSystem(SourceSystem sourceSystem) {
        sourceSystemRepository.save(sourceSystem);
    }
}
