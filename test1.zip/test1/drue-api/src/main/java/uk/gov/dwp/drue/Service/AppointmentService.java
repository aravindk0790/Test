package uk.gov.dwp.drue.Service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uk.gov.dwp.drue.model.Appointment;
import uk.gov.dwp.drue.model.JobCentre;
import uk.gov.dwp.drue.repository.AppointmentRepository;
import uk.gov.dwp.drue.repository.JobCentreRepository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final JobCentreRepository jobCentreRepository;

    public AppointmentService(AppointmentRepository appointmentRepository, JobCentreRepository jobCentreRepository) {
        this.appointmentRepository = appointmentRepository;
        this.jobCentreRepository = jobCentreRepository;
    }

    public void create(Appointment appointment) {
        appointmentRepository.save(appointment);
    }
    public List<Appointment> getAppointmentsBySlotTime(ZonedDateTime slotTime) {
        return appointmentRepository.findAppointmentByTime(slotTime);
    }

    public List<ZonedDateTime> getAppointmentSlots(Long id) {
        log.info("Obtaining todays appointments for jobcentre id {}",id);
        List<Timestamp> timestamps = appointmentRepository.getAppointmentTimes(id);
        return timestamps
                .stream()
                .map(t -> t.toInstant().atZone(ZoneId.of("GB")))
                .collect(Collectors.toList());
    }

    public List<Appointment> findAppointmentByTimeAndJobCentre(ZonedDateTime slotTime, Long jobCentreId) {
        log.info("Obtaining appointments for slot time: {} for jobcentre id {}", slotTime, jobCentreId);
        return appointmentRepository.findAppointmentByTimeAndJobCentre(slotTime, jobCentreRepository.findById(jobCentreId).get());
    }
}