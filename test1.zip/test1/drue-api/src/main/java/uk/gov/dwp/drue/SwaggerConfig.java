package uk.gov.dwp.drue;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Arrays;
import java.util.Collections;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

    @Value("$(drue.settings.build.version)")
    private String applicationVersion;

    @Bean
    public Docket productApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("uk.gov.dwp.drue.Controller"))
                .paths(PathSelectors.any())
                .build()
                .apiInfo(new ApiInfo("DRUE API",
                        "This Api contains all the endpoints for the DRUE application ", applicationVersion,
                        "", ApiInfo.DEFAULT_CONTACT, "", "",
                        Collections.emptyList()));


    }

    private Tag[] tags(){
        return new Tag[]{new Tag("Agent Controller  ","End points to manage jobcentre agents" )};
    }

    private Tag appInfoTag() {
        return new Tag("Application Info", "Anything relating to the running of the service rather than the data within.");
    }
}
