package uk.gov.dwp.drue.Controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import uk.gov.dwp.drue.Controller.util.ControllerMappings;
import uk.gov.dwp.drue.Service.InstructionService;
import uk.gov.dwp.drue.model.Instruction;

@RestController()
@RequestMapping(value = ControllerMappings.INSTRUCTION)
@Api(value = ControllerMappings.INSTRUCTION,
        consumes = "application/json",
        produces = "application/json",
        description = "Endpoints for managing instructions")
public class InstructionController {

    private final InstructionService instructionService;

    @Autowired
    public InstructionController(InstructionService instructionService){
        this.instructionService = instructionService;
    }

    @RequestMapping(method = RequestMethod.POST)
    @ApiOperation(value = "Creates a single Instruction")
    public void createInstruction(@RequestBody Instruction instruction){
        instructionService.createInstruction(instruction);
    }
}
