package uk.gov.dwp.drue.Controller.util;

public class ControllerMappings {

    public static final String JOB_CENTRE = "/api/jobcentre";
    public static final String APPOINTMENT = "/api/appointment";
    public static final String AGENT = "/api/agent";
    public static final String SOURCE_SYSTEM = "/api/source_system";
    public static final String INSTRUCTION = "/api/instruction";
    public static final String LOCATION = "/api/location";
    public static final String UPLOAD ="/api/upload";

    private  ControllerMappings(){throw new AssertionError();}
}
