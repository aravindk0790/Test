package uk.gov.dwp.drue.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
@Data
@NoArgsConstructor
public class Instruction {


    @Id
    @GeneratedValue(strategy = IDENTITY)
    private Long id;
    @NotNull
    private String instructionText;
    @ManyToOne
    private Location location;


    public Instruction(@NotNull String instructionText) {
        this.instructionText = instructionText;
    }
}
