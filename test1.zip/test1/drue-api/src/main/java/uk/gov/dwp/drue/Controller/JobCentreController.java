package uk.gov.dwp.drue.Controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;
import uk.gov.dwp.drue.Controller.util.ControllerMappings;
import uk.gov.dwp.drue.Service.JobCentreService;
import uk.gov.dwp.drue.model.JobCentre;
import uk.gov.dwp.drue.small.SmallJobCentre;

import java.util.List;

@RestController()
@RequestMapping(value = ControllerMappings.JOB_CENTRE)
@Api(value = ControllerMappings.JOB_CENTRE,
        produces = "application/json",
        consumes = "application/json",
        description = "Endpoints for managing jobcentres")
public class JobCentreController {

    private final JobCentreService jobCentreService;

    @Autowired
    public JobCentreController(JobCentreService jobCentreService){
        this.jobCentreService = jobCentreService;
    }

    @RequestMapping(value = "/greeting", method = RequestMethod.GET)
    @ApiIgnore
    private String greeting() {
        return "Hello World!\n";
    }

    @RequestMapping(value = "", method = RequestMethod.POST)
    @ApiOperation(value = "Creates a jobcentre")
    private void createJobCentre(@RequestBody JobCentre jobCentre){
        jobCentreService.createJobCentre(jobCentre);
    }

    @RequestMapping(value = "/{name}/find", method = RequestMethod.GET)
    @ApiOperation(value = "Find a jobcentre by name")
    @ApiParam(value = "The name of the jobcentre to find")
    private JobCentre findByName(@PathVariable(value="name") String name){
        return jobCentreService.findJobCentreByName(name);
    }

    @RequestMapping(value = "/all", method = RequestMethod.GET)
    @ApiOperation(value = "The full list of job centres with ids")
    private Iterable<SmallJobCentre> findAllJobCentres(){
        return jobCentreService.findAllJobCentres();
    }

}
