package uk.gov.dwp.drue.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.gov.dwp.drue.model.Agent;
import uk.gov.dwp.drue.repository.AgentRepository;

@Service
public class AgentService {

    private final AgentRepository agentRepository;

    @Autowired
    public AgentService(AgentRepository agentRepository){
        this.agentRepository = agentRepository;
    }

    public void createAgent(Agent agent) {
        agentRepository.save(agent);

    }


}
