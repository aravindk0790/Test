package uk.gov.dwp.drue.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.gov.dwp.drue.model.Location;
import uk.gov.dwp.drue.repository.LocationRepository;

@Service
public class LocationService {

    private LocationRepository locationRepository;

    @Autowired
    public LocationService(LocationRepository locationRerpository){
        this.locationRepository = locationRerpository;
    }

    public void createLocation(Location location) {
        locationRepository.save(location);
    }
}
