package uk.gov.dwp.drue.json;

import lombok.Data;

@Data
public class JobCentre {
    private String name;
}
