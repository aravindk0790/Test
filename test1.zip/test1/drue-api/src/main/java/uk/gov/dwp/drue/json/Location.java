package uk.gov.dwp.drue.json;

import lombok.Data;

@Data
public class Location {

    public String code;
    public String title;
    public String instruction;

}
