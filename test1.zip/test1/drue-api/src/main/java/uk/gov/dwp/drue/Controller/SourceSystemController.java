package uk.gov.dwp.drue.Controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import uk.gov.dwp.drue.Controller.util.ControllerMappings;
import uk.gov.dwp.drue.Service.SourceSystemService;
import uk.gov.dwp.drue.model.SourceSystem;

@RestController()
@RequestMapping(value = ControllerMappings.SOURCE_SYSTEM)
@Api(value = ControllerMappings.SOURCE_SYSTEM,
        produces = "application/json",
        consumes = "application/json",
        description = "Endpoints for managing appointment sources")
public class SourceSystemController {

    private final SourceSystemService sourceSystemService;

    public SourceSystemController(SourceSystemService sourceSystemService) {
        this.sourceSystemService = sourceSystemService;
    }

    @RequestMapping(method = RequestMethod.POST)
    @ApiOperation(value = "Create s ingle appointment source")
    public void createSourceSystem(@RequestBody SourceSystem sourceSystem){
        sourceSystemService.createSourceSystem(sourceSystem);
    }
}
