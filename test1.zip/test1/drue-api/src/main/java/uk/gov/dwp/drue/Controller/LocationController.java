package uk.gov.dwp.drue.Controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import uk.gov.dwp.drue.Controller.util.ControllerMappings;
import uk.gov.dwp.drue.Service.LocationService;
import uk.gov.dwp.drue.model.Location;

@RestController
@RequestMapping(value = ControllerMappings.LOCATION)
@Api(value = ControllerMappings.LOCATION,
        produces = "application/json",
        consumes = "application/json",
        description = "Endpoints for managing locations")
public class LocationController {

    @Autowired
    private LocationService locationService;

    public LocationController(LocationService locationService){
        this.locationService = locationService;
    }

    @RequestMapping(method = RequestMethod.POST)
    @ApiOperation(value = "Create a single location")
    public void createLocation(@RequestBody Location location){
        locationService.createLocation(location);
    }
}
