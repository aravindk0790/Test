package uk.gov.dwp.drue.Controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import uk.gov.dwp.drue.Controller.util.ControllerMappings;
import uk.gov.dwp.drue.Service.AgentService;
import uk.gov.dwp.drue.model.Agent;

@RestController()
@RequestMapping(value = ControllerMappings.AGENT)
@Api(value = ControllerMappings.AGENT,  consumes = "application/json", description = "Endpoints for the management of jobcentre agents")
public class AgentController {

    private final AgentService agentService;

    @Autowired
    public AgentController(AgentService agentService) {
        this.agentService = agentService;
    }

    @ApiOperation(value = "Creates a single agent")
    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public void createAgent(@RequestBody() Agent agent){
        agentService.createAgent(agent);
    }



}
