package uk.gov.dwp.drue.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.ColumnTransformer;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static javax.persistence.CascadeType.*;
import static javax.persistence.GenerationType.IDENTITY;

@Entity
@Data
@NoArgsConstructor
public class Agent {

    @Id
    @GeneratedValue(strategy = IDENTITY)
    private Long id;
    @ColumnTransformer(read = "FLES_D(first_name, 'PGKEY#101')", write = "FLES_E(?, 'PGKEY#101')")
    private String firstName;
    @ColumnTransformer(read = "FLES_D(last_name, 'PGKEY#102')", write = "FLES_E(?, 'PGKEY#102')")
    private String lastName;
    @ManyToOne
    @JsonIgnore
    private JobCentre jobCentre;
    @ManyToOne
    private Location location;
    @Nullable
    private String instruction;
    @OneToMany(mappedBy = "agent")
    @Nullable
    @JsonIgnore
    private List<Appointment> appointments;

    public Agent(@NotNull @NotBlank String firstName, @NotNull @NotBlank String lastName, JobCentre jobCentre, Location location) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.jobCentre = jobCentre;
        this.location = location;
    }

    public Agent(@NotNull @NotBlank String firstName, @NotNull @NotBlank String lastName, JobCentre jobCentre, String instruction) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.jobCentre = jobCentre;
        this.instruction = instruction;
    }

    public Agent(@NotNull @NotBlank String firstName, @NotNull @NotBlank String lastName, JobCentre jobCentre) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.jobCentre = jobCentre;
    }
}
