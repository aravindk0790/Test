package uk.gov.dwp.drue;

import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import uk.gov.dwp.common.fles.FLESConfig;
import uk.gov.dwp.common.fles.FLESInit;
import uk.gov.dwp.common.fles.Interceptor;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import static uk.gov.dwp.drue.util.Util.dereferenceEnvironmentVariables;

@SpringBootApplication
@EntityScan("uk.gov.dwp.drue.model")
@Log4j2
public class App {


    public static void main(String[] args){
        initFLES();
        SpringApplication.run(App.class, args);
    }



    private static void initFLES() {
        Properties env = new Properties();

        try {
            log.info("Collecting the env variables in V13.0.0");
            InputStream input = App.class.getClassLoader().getResourceAsStream("application-" + System.getProperty("spring.profiles.active", "local") + ".properties");
            env.load(input);
            input.close();

            boolean dontEncrypt = "true".equals(dereferenceEnvironmentVariables(env.getProperty("fles.db.dont.encrypt","")));
            String awskms = dereferenceEnvironmentVariables(env.getProperty("fles.aws.kms",""));
            String awsRegion = dereferenceEnvironmentVariables(env.getProperty("fles.aws.region",""));
            String cacheTimeoutText = dereferenceEnvironmentVariables(env.getProperty("fles.key.cachetime", ""));
            int cacheTimeout = cacheTimeoutText.isEmpty() ? 30000 : Integer.valueOf(cacheTimeoutText);

            log.info("dontEncrypt: {} awskms:{} awsRegion: {} cacheTimeoutText: {} cacheTimeout: {} "
                    ,dontEncrypt,awskms,awsRegion,cacheTimeoutText,cacheTimeout);
            FLESConfig.KeyStrategy keyStrategy;
            if (dontEncrypt) {
                log.info("Running with no encryption under the FAKE_STRATEGY");
                keyStrategy = FLESConfig.KeyStrategy.FAKE_STRATEGY;
            } else if (awskms.isEmpty()) {
                log.info("Trying database encryption under the SQL_STRATEGY. Reason awskms is empty ");
                keyStrategy = FLESConfig.KeyStrategy.SQL_STRATEGY;
            } else {
                log.info("Trying  encryption under the AWS_KMS_STRATEGY. Reason awskms is defined ");
                keyStrategy = FLESConfig.KeyStrategy.AWS_KMS_STRATEGY;
            }

            log.info("Driver: {} Source: {} User: {} pass: {}",
                    dereferenceEnvironmentVariables(env.getProperty("fles.db.driver","")),
                    dereferenceEnvironmentVariables(env.getProperty("fles.db.source","")),
                    dereferenceEnvironmentVariables(env.getProperty("fles.db.user","")),
                    dereferenceEnvironmentVariables(env.getProperty("fles.db.password",""))
                    );
            FLESInit.init(FLESConfig.newBuilder()
                    .keyCacheTime(cacheTimeout)
                    .keyCacheCheckInterval(10000)
                    .keyStrategy(keyStrategy)
                    .awskmsArn(awskms)
                    .awsRegion(awsRegion)
                    .keyDbDriver(env.getProperty("fles.db.driver","org.postgresql.Driver"))
                    .keyDbUrl(dereferenceEnvironmentVariables(env.getProperty("fles.db.source","")))
                    .keyDbUser(dereferenceEnvironmentVariables(env.getProperty("fles.db.user","")))
                    .keyDbPass(dereferenceEnvironmentVariables(env.getProperty("fles.db.password","")))
                    .dbEngine(dontEncrypt ? FLESConfig.DbEngine.NOCRYPT : FLESConfig.DbEngine.POSTGRESQL)
                    .build()
            );

            // Force key generation / decryption
            Interceptor interceptor = new Interceptor();
            interceptor.getKey(1);
        } catch (IOException ex) {
            log.error("Not able to find application properties.", ex);
        }
    }



    @Bean
    public CommandLineRunner commandLineRunner(ApplicationContext ctx) {

        return args -> {
            log.info("DRUE API started");
        };
    }
}
