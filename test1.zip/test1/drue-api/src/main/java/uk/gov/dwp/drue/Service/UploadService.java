package uk.gov.dwp.drue.Service;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.gov.dwp.drue.json.JobCentreDailyUpload;
import uk.gov.dwp.drue.model.Agent;
import uk.gov.dwp.drue.model.Appointment;
import uk.gov.dwp.drue.model.JobCentre;
import uk.gov.dwp.drue.model.Location;
import uk.gov.dwp.drue.repository.*;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Log4j2
public class UploadService {

    private final AgentRepository agentRepository;
    private final AppointmentRepository appointmentRepository;
    private final JobCentreRepository jobCentreRepository;
    private final LocationRepository locationRepository;
    private final InstructionRepository instructionRepository;

    @Autowired
    public UploadService(AgentRepository agentRepository,
                         AppointmentRepository appointmentRepository,
                         JobCentreRepository jobCentreRepository,
                         LocationRepository locationRepository,
                         InstructionRepository instructionRepository) {
        this.agentRepository = agentRepository;
        this.appointmentRepository = appointmentRepository;
        this.jobCentreRepository = jobCentreRepository;
        this.locationRepository = locationRepository;
        this.instructionRepository = instructionRepository;
    }

    /**
     * Takes the upload json and convets it to 
     * @param upload
     */
    public void uploadHandler(JobCentreDailyUpload upload) {

        JobCentre jobCentre = jobCentreRepository.save(new JobCentre(upload.getJobCentre().getName()));

        List<Location> locations = upload.getLocations()
                .stream()
                .map(l -> new Location(l.getCode(), l.getTitle(), jobCentre, l.getInstruction()))
                .collect(Collectors.toList());
        jobCentre.setLocations(locations);

        jobCentreRepository.save(jobCentre);

        List<Agent> agents = upload.getAgents()
                .stream()
                .filter(a -> !a.getLocationCode().isEmpty())
                .map(a -> new Agent(a.getFirstName(), a.getLastName(), jobCentre, locationRepository.findByCodeAndJobCentre(a.getLocationCode(), jobCentre)))
                .collect(Collectors.toList());
        jobCentre.setAgents(agents);

        List<Agent> agentsWithInsgtructions = upload.getAgents()
                .stream()
                .filter(a -> a.getLocationCode().isEmpty())
                .map(a -> new Agent(a.getFirstName(), a.getLastName(), jobCentre, a.getInstruction()))
                .collect(Collectors.toList());
        jobCentre.getAgents().addAll(agentsWithInsgtructions);

        jobCentreRepository.save(jobCentre);

        List<Appointment> appointments = upload.getAppointments()
                .stream()
                .map(a -> new Appointment(a.getTime(), a.getCustomerFirstName(), a.getCustomerLastName(),jobCentre,
                        agentRepository.findByFirstNameAndLastNameAndJobCentre(a.getAgentFirstName(),a.getAgentLastName(),jobCentre)))
                .collect(Collectors.toList());
        jobCentre.setAppointments(appointments);

        jobCentreRepository.save(jobCentre);

        log.info("Data upload complete");

    }


}
