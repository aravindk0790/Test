package uk.gov.dwp.drue.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import uk.gov.dwp.drue.model.Agent;
import uk.gov.dwp.drue.model.JobCentre;

@Repository
public interface AgentRepository extends CrudRepository<Agent, Long> {

    public Agent findByFirstNameAndLastNameAndJobCentre(String firstName, String lastName, JobCentre jobCentre);
}