package uk.gov.dwp.drue.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.gov.dwp.drue.model.Instruction;
import uk.gov.dwp.drue.repository.InstructionRepository;

@Service
public class InstructionService {

    private final InstructionRepository instructionRepository;

    @Autowired
    public InstructionService(InstructionRepository instructionRepository){
        this.instructionRepository = instructionRepository;
    }

    public void createInstruction(Instruction instruction) {
        instructionRepository.save(instruction);
    }
}
