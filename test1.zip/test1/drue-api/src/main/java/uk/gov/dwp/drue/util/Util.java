package uk.gov.dwp.drue.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {

    private Util(){}

    public static String dereferenceEnvironmentVariables(String in) {
        String out = in;
        Matcher matcher = Pattern.compile("\\$\\{([a-z0-9A-Z_]*)}").matcher(in);
        while (matcher.find()) {
            String env = System.getenv(matcher.group(1));
            out = out.replace(matcher.group(), env == null ? "" : env);
        }
        return out;
    }


}
