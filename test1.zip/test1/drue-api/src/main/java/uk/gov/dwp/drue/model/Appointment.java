package uk.gov.dwp.drue.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.ColumnTransformer;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import java.time.ZonedDateTime;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
@Data
@NoArgsConstructor
public class Appointment {

    @Id
    @GeneratedValue(strategy = IDENTITY)
    private Long id;
    private ZonedDateTime time;
    @ColumnTransformer(read = "FLES_D(customer_first_name, 'PGKEY#1')", write = "FLES_E(?, 'PGKEY#1')")
    private String customerFirstName;
    @ColumnTransformer(read = "FLES_D(customer_last_name, 'PGKEY#2')", write = "FLES_E(?, 'PGKEY#2')")
    private String customerLastName;
    @ManyToOne
    private Agent agent;
    @ManyToOne
    @JsonIgnore
    private JobCentre jobCentre;

    public Appointment(ZonedDateTime time, String customerFirstName, String customerLastName, JobCentre jobCentre, Agent agent) {
        this.time = time;
        this.customerFirstName = customerFirstName;
        this.customerLastName = customerLastName;
        this.jobCentre = jobCentre;
        this.agent = agent;
    }
}
