package uk.gov.dwp.drue.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import uk.gov.dwp.drue.model.SourceSystem;

@Repository
public interface SourceSystemRepository extends CrudRepository<SourceSystem, Long> {
}
