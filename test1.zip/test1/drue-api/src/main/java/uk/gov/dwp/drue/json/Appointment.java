package uk.gov.dwp.drue.json;

import lombok.Data;

import java.time.ZonedDateTime;

@Data
public class Appointment {

    private String source;
    private ZonedDateTime time;
    private String customerFirstName;
    private String customerLastName;
    private String agentFirstName;
    private String agentLastName;
    private Long jobCentreId;
}
