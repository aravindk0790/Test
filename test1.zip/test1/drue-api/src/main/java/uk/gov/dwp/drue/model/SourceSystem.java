package uk.gov.dwp.drue.model;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import java.util.List;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
@Data
public class SourceSystem {

    @Id
    @GeneratedValue(strategy = IDENTITY)
    private Long id;
    @NotNull
    @NotBlank
    @Column(length = 100)
    private String name;
    @OneToMany
    private List<Appointment> appointments;
}
