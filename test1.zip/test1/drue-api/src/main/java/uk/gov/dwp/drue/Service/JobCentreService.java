package uk.gov.dwp.drue.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.gov.dwp.drue.model.JobCentre;
import uk.gov.dwp.drue.repository.JobCentreRepository;
import uk.gov.dwp.drue.small.SmallJobCentre;

import java.util.List;

@Service
public class JobCentreService {

    private final JobCentreRepository jobCentreRepository;

    @Autowired
    public JobCentreService(JobCentreRepository jobCentreRepository){
        super();
        this.jobCentreRepository = jobCentreRepository;
    }

    public void createJobCentre(JobCentre jobCentre){
        jobCentreRepository.save(jobCentre);
    }

    public JobCentre findJobCentreByName(String name){
        return jobCentreRepository.findJobCentreByName(name);
    }

    public Iterable<SmallJobCentre> findAllJobCentres() {
        return jobCentreRepository.findIdAndNAme();
    }
}
