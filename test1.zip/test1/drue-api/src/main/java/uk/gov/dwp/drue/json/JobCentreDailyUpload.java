package uk.gov.dwp.drue.json;

import lombok.Data;

import java.util.List;

@Data
public class JobCentreDailyUpload {

    private JobCentre jobCentre;
    private List<Location> locations;
    private List<Agent> agents;
    private List<Appointment> appointments;

}
