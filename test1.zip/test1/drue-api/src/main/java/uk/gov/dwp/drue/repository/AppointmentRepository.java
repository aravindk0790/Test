package uk.gov.dwp.drue.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import uk.gov.dwp.drue.model.Appointment;
import uk.gov.dwp.drue.model.JobCentre;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.util.List;

@Repository
public interface AppointmentRepository extends CrudRepository<Appointment, Long> {

    @Query(value = "SELECT time FROM appointment WHERE job_centre_id = ?#{[0]} AND time > CURRENT_DATE GROUP BY time ORDER BY time ASC", nativeQuery = true)
    public List<Timestamp> getAppointmentTimes(long id);

    public List<Appointment>  findAppointmentByTime(ZonedDateTime zonedDateTime);

    public List<Appointment> findAppointmentByTimeAndJobCentre(ZonedDateTime zonedDateTime, JobCentre jobCentre);
}
