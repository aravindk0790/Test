package uk.gov.dwp.drue.small;

import lombok.Data;

@Data
public class SmallJobCentre {

    private Long id;
    private String name;

    public SmallJobCentre(Long id, String name) {
        this.id = id;
        this.name = name;
    }
}
