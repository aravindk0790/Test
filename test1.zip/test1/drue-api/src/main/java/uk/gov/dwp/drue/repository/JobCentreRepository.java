package uk.gov.dwp.drue.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import uk.gov.dwp.drue.small.SmallJobCentre;
import uk.gov.dwp.drue.model.JobCentre;

import java.util.List;

@Repository
public interface JobCentreRepository extends CrudRepository<JobCentre, Long> {

    public JobCentre findJobCentreByName(String name);

    @Query("SELECT new uk.gov.dwp.drue.small.SmallJobCentre(j.id, j.name) FROM JobCentre  j ORDER by j.id")
    public List<SmallJobCentre> findIdAndNAme();


}
