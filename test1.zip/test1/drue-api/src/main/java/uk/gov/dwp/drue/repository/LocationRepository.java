package uk.gov.dwp.drue.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import uk.gov.dwp.drue.model.JobCentre;
import uk.gov.dwp.drue.model.Location;

@Repository
public interface LocationRepository extends CrudRepository<Location, Long> {

    public Location findByCodeAndJobCentre(String code, JobCentre jobCentre);
}
