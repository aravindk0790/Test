package uk.gov.dwp.drue.Controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import uk.gov.dwp.drue.Controller.util.ControllerMappings;
import uk.gov.dwp.drue.Service.AppointmentService;
import uk.gov.dwp.drue.model.Appointment;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.util.List;

@RestController
@RequestMapping(value = ControllerMappings.APPOINTMENT)
@Api(value = ControllerMappings.APPOINTMENT,
        consumes = "applicatin/json",
        produces = "application/json",
        description = "Endpoints for the management of appointments")
public class AppointmentController {

    private final AppointmentService appointmentService;

    @Autowired
    public AppointmentController(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }


    @RequestMapping(method = RequestMethod.POST)
    @ApiOperation(value = "Creates a single appointment")
    public void createAppointment(@RequestBody Appointment appointment){
        appointmentService.create(appointment);
    }

    @RequestMapping(value= "/slots/{jobCentreId}", method = RequestMethod.GET)
    @ApiOperation(value = "Get todays apponitment slots for a specified job centre")
    public List<ZonedDateTime> getTodaysAppointmentSlots(@PathVariable("jobCentreId") Long id){
        return appointmentService.getAppointmentSlots(id);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/appointments/{slotTime}")
    @ApiOperation(value = "Find all appointments for a given time")
    public List<Appointment> getAppointmentsBySlotTime(@PathVariable("slotTime") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) ZonedDateTime slotTime){
        return appointmentService.getAppointmentsBySlotTime(slotTime);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/appointments/{slotTime}/{jobCentreId}")
    @ApiOperation(value = "Find all appointments for a given time")
    public List<Appointment> getAppointmentsBySlotTimeAndJobCentreId(@PathVariable("slotTime") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) ZonedDateTime slotTime, @PathVariable("jobCentreId") Long id){
        return appointmentService.findAppointmentByTimeAndJobCentre(slotTime, id);
    }
}
