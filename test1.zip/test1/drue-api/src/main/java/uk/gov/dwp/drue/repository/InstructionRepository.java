package uk.gov.dwp.drue.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import uk.gov.dwp.drue.model.Instruction;

@Repository
public interface InstructionRepository extends CrudRepository<Instruction, Long> {


}
