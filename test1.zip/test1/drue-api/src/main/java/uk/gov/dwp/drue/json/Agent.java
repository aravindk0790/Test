package uk.gov.dwp.drue.json;

import lombok.Data;
import uk.gov.dwp.drue.model.*;

import java.util.List;
@Data
public class Agent {


    private String firstName;
    private String lastName;
    private String locationCode;
    private String instruction;
}
