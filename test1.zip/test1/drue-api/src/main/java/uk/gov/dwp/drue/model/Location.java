package uk.gov.dwp.drue.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import java.util.Arrays;
import java.util.List;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
@Data
@NoArgsConstructor
public class Location {

    @Id
    @GeneratedValue(strategy = IDENTITY)
    private Long id;
    private String code;
    private String title;
    private String instruction;
    @OneToMany(mappedBy = "location")
    @JsonIgnore
    private List<Agent> agent;
    @ManyToOne
    @JsonIgnore
    private JobCentre jobCentre;

    public Location(String code, String title, JobCentre jobCentre, String instruction) {
        this.code = code;
        this.title = title;
        this.jobCentre = jobCentre;
        this.instruction = instruction;
    }
}
