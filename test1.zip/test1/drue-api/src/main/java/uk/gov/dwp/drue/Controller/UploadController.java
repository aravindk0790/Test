package uk.gov.dwp.drue.Controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import uk.gov.dwp.drue.Controller.util.ControllerMappings;
import uk.gov.dwp.drue.Service.UploadService;
import uk.gov.dwp.drue.json.JobCentreDailyUpload;

@RestController()
@RequestMapping(value = ControllerMappings.UPLOAD)
@Api(value = ControllerMappings.UPLOAD,
        produces = "application/json",
        consumes = "application/json",
        description = "Endpoints for managing the upload of appointment data")
public class UploadController {

    private UploadService uploadService;

    @Autowired
    public UploadController(UploadService uploadService){
        this.uploadService = uploadService;
    }

    @RequestMapping(value = "", method = RequestMethod.POST)
    @ApiOperation(value = "Uploads the data map into the database")
    public void loadData(@RequestBody JobCentreDailyUpload upload){
        uploadService.uploadHandler(upload);
    }

}
